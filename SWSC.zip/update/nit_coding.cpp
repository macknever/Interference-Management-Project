#include "nit_coding.h"



/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/




int lte_search_k(const int n, const double R)
{

	int i, index;
	double k;
	int actual_k;

	ivec block_lengths("40 48 56 64 72 80 88 96 104 112 120 128 136 144 152 160 168 176 184 192 200 208 216 224 232 240 248 256 264 272 280 288 296 304 312 320 328 336 344 352 360 368 376 384 392 400 408 416 424 432 440 448 456 464 472 480 488 496 504 512 528 544 560 576 592 608 624 640 656 672 688 704 720 736 752 768 784 800 816 832 848 864 880 896 912 928 944 960 976 992 1008 1024 1056 1088 1120 1152 1184 1216 1248 1280 1312 1344 1376 1408 1440 1472 1504 1536 1568 1600 1632 1664 1696 1728 1760 1792 1824 1856 1888 1920 1952 1984 2016 2048 2112 2176 2240 2304 2368 2432 2496 2560 2624 2688 2752 2816 2880 2944 3008 3072 3136 3200 3264 3328 3392 3456 3520 3584 3648 3712 3776 3840 3904 3968 4032 4096 4160 4224 4288 4352 4416 4480 4544 4608 4672 4736 4800 4864 4928 4992 5056 5120 5184 5248 5312 5376 5440 5504 5568 5632 5696 5760 5824 5888 5952 6016 6080 6144");
	const int MAX_INTERLEAVER_SIZE = 6144;
	const int MIN_INTERLEAVER_SIZE = 40;


	k = (double)n * R;

	// Check the range of the interleaver size:
	it_assert(k <= MAX_INTERLEAVER_SIZE, "The current k is too large. Rate has to be rearranged!");
	it_assert(k >= MIN_INTERLEAVER_SIZE, "The current k is too small. Rate has to be rearranged!");

	// Search for the closest block length to k
	for (i=0; i< block_lengths.length()-1; i++)
	{
		if ((block_lengths(i) <= k) && (k < block_lengths(i+1)))
		{
			index = i;
		}
	}

	if ((k-(double)(block_lengths(index))) <= ((double)(block_lengths(index+1))-k))
	{
		actual_k = block_lengths(index);
	}
	else
	{
		actual_k = block_lengths(index+1);
	}

	return actual_k;
}



double pdf_gaussian(const double y, const double mean, const double sigma2)
{
	double result;

	result = 1.0 / sqrt(2.0*pi*sigma2) * exp(-1.0*sqr(y-mean) / (2.0*sigma2));

	return result;

}

vec pdf_gaussian(const vec y, const double mean, const double sigma2)
{
	vec result;

	result = 1.0 / sqrt(2.0*pi*sigma2) * exp(-1.0*sqr(y-mean) / (2.0*sigma2));

	return result;

}



/*
vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P1)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}


vec sw_calc_LLR_single(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(P)*sqrt(alpha) + sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(P)*sqrt(alpha) - sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(P)*sqrt(alpha) + sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(P)*sqrt(alpha) - sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}


vec sw_calc_LLR_single_temp(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(P)*sqrt(alpha) + sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(P)*sqrt(alpha) - sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(P)*sqrt(alpha) + sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(P)*sqrt(alpha) - sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2))));
	}

	return concat(rxc, rxp);
	//return concat(rxp, rxc);
}



/*
vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) - g)) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) - g12*sqrt(P))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P1)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*g11*sqrt(P1)*sqrt(1.0-alpha)*y / sigma^2 

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) - g12*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) - g12*sqrt(P2))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}


vec sw_calc_LLR_single_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(P)*sqrt(1.0-alpha)*y / sigma^2 
	rxc = 2.0 * sqrt(P)*sqrt(alpha) * rx_curr / sigma2;	// HPARK: LLR = 2*sqrt(P)*sqrt(alpha)*y / sigma^2 

	return concat(rxp, rxc);
}



/*
vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx;			

	// HPARK: calculating LLR
	rx.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g - sqrt(1.0-alpha))) / (2.0*sigma2)) )
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g - sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx;
}

vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx;			

	// HPARK: calculating LLR
	rx.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P) + g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P) - g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) )
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P) + g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P) - g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx;
}
*/

vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx;			

	// HPARK: calculating LLR
	rx.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P2) + g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P2) - g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) )
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P2) + g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P2) - g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx;
}


/*
vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}



/*
vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) - 1.0)) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) - g22*sqrt(P))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) - g22*sqrt(P2))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}

/*
vec sw_calc_LLR_22(const vec &rx_prev, const double sigma2)
{

	int cnt;
	vec rxp;			// HPARK: to store LLR values from rx_prev

	// HPARK: calculating LLR
	rxp = rx_prev * 2.0 / sigma2;

	return rxp;
}

vec sw_calc_LLR_22(const vec &rx_prev, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp;			// HPARK: to store LLR values from rx_prev

	// HPARK: calculating LLR
	rxp = rx_prev * g22 * sqrt(P) * 2.0 / sigma2;

	return rxp;
}
*/

vec sw_calc_LLR_22(const vec &rx_prev, const double P2, const double g22, const double sigma2)
{

	int cnt;
	vec rxp;			// HPARK: to store LLR values from rx_prev

	// HPARK: calculating LLR
	rxp = rx_prev * g22 * sqrt(P2) * 2.0 / sigma2;

	return rxp;
}




vec sc_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2))));
	}

	return rx_LLR;
}

vec sc_calc_LLR_12(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g - sqrt(1.0-alpha))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g - sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx_LLR;
}

vec sc_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log( exp(-1.0*sqr(rx(cnt)-sqrt(1.0-alpha)) / (2.0*sigma2)) / exp(-1.0*sqr(rx(cnt)+sqrt(1.0-alpha)) / (2.0*sigma2)));
	}

	return rx_LLR;
}




vec sc_calc_LLR_2U(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	return rx_LLR;
}



vec sc_calc_LLR_2V(const vec &rx, const double alpha, const double g, const double sigma2)
{
	
	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	return rx_LLR;


}

vec sc_calc_LLR_22(const vec &rx, const double alpha, const double g, const double sigma2)
{
	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log( exp(-1.0*sqr(rx(cnt)-1.0) / (2.0*sigma2)) / exp(-1.0*sqr(rx(cnt)+1.0) / (2.0*sigma2)));
	}

	return rx_LLR;

}






vec ian_calc_LLR_1(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;
	double tx1_11 = -3.0/sqrt(5);
	double tx1_10 = -1.0/sqrt(5);
	double tx1_00 = 1.0/sqrt(5);
	double tx1_01 = 3.0/sqrt(5);
	double tx2_1 = -1.0*g;
	double tx2_0 = g;

	rx_LLR.set_size(2*rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		// for the first bit of 4PAM symbol
		rx_LLR(2*cnt) = log((exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_1)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_1)) / (2.0*sigma2))));
		// for the second bit of 4PAM symbol
		rx_LLR(2*cnt+1) = log((exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_1)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_1)) / (2.0*sigma2))));
	}

	return rx_LLR;
}





vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2))));
	}

	return rx_LLR;
}

vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2))));
	}

	return rx_LLR;
}




vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(1.0-alpha) - g)) / (2.0*sigma2)) ));
	}

	return rx_LLR;
}

vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) ));
	}

	return rx_LLR;
}







vec ian_calc_LLR_2(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;
	double tx1_11 = g*(-3.0)/sqrt(5);
	double tx1_10 = g*(-1.0)/sqrt(5);
	double tx1_00 = g*1.0/sqrt(5);
	double tx1_01 = g*3.0/sqrt(5);
	double tx2_1 = -1.0;
	double tx2_0 = 1.0;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_1)) / (2.0*sigma2))));
	}

	return rx_LLR;
}

/*
vec ian_calc_LLR_2(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(1.0 + g*sqrt(alpha) + g*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(1.0 - g*sqrt(alpha) + g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(1.0 + g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(1.0 - g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(1.0 + g*sqrt(alpha) + g*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(1.0 - g*sqrt(alpha) + g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(1.0 + g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(1.0 - g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2))));
	}

	return rx_LLR;
}
*/



vec ian_calc_LLR_2(const vec &rx, const double alpha, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2))));
	}

	return rx_LLR;
}



vec mlc_calc_LLR_single(const vec &rx, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(alpha)*sqrt(P) + sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha)*sqrt(P) - sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(alpha)*sqrt(P) + sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha)*sqrt(P) - sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2))));
	}

	return rx_LLR;
}



// joint decoding for Y = alpha*U + beta*V + gamma*X2 + Z where U, V, and X2 are BPSK-modulated and Z~(0,sigma^2)

void sd_joint_decode(Punctured_Turbo_Codec_rev codeU, Punctured_Turbo_Codec_rev codeV, Punctured_Turbo_Codec_rev code2, Sequence_Interleaver<double> itlvU, Sequence_Interleaver<double> itlvV, Sequence_Interleaver<double> itlv2, const vec &rx, bvec &decU, bvec &decV, bvec &dec2, const bvec &msgU, const bvec &msgV, const bvec &msg2, const double alpha, const double beta, const double gamma, const double sigma2)
{
/*
	int i, j;
	int outer_iter=8;
	bool stop;

	vec rxU, rxU_itlv, inU, inU_itlv, outU, outU_itlv;
	vec rxV, rxV_itlv, inV, inU_itlv, outV, outV_itlv;
	vec rx2, rx2_itlv, in2, in2_itlv, out2, out2_itlv;
	ivec iter_decU, iter_decV, iter_dec2;

	// initially calculate LLR for U, V, X2 from rx
	rxU_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) + pdf_gaussian(rx,alpha-beta-gamma,sigma2)) /
			(pdf_gaussian(rx,-alpha+beta+gamma,sigma2) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
	rxV_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2)) /
			(pdf_gaussian(rx,alpha-beta+gamma,sigma2) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
	rx2_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2)) /
			(pdf_gaussian(rx,alpha+beta-gamma,sigma2) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );

	// deinterleaving for initial LLR of U, V, X2
	rxU = itlvU.deinterleave(rxU_itlv);
	rxV = itlvV.deinterleave(rxV_itlv);
	rx2 = itlv2.deinterleave(rx2_itlv);

	// initial extrinsic information to the first decoder is zero
	inU_itlv = zeros(rx.length()); inV_itlv = zeros(rx.length()); in2_itlv = zeros(rx.length());

	// outer iteration 8 times?
	stop = false;
	for (i=0; (i<outer_iter) && (!stop); i++)
	{
		// deinterleaving for inU, intV, and in2
		inU = itlvU.deinterleave(inU_itlv);
		inV = itlvV.deinterleave(inV_itlv);
		in2 = itlv2.deinterleave(in2_itlv);

		// SISO decoding of turbo codes
		codeU.lte_turbo_rate_matching_decode_SISO(rxU, inU, outU, decU, iter_decU);	// outU should be Le21 + Le12
		codeV.lte_turbo_rate_matching_decode_SISO(rxV, inV, outV, decV, iter_decV);
		code2.lte_turbo_rate_matching_decode_SISO(rx2, in2, out2, dec2, iter_dec2);

		// all decoded bits are correct, then STOP
		stop = true;
		for (j=0; j< msgU.length(); j++)
		{
			if (decU(j) != msgU(j))
			{
				stop = false;
			}
		}
		for (j=0; j< msgV.length(); j++)
		{
			if (decV(j) != msgV(j))
			{
				stop = false;
			}
		}
		for (j=0; j< msg2.length(); j++)
		{
			if (dec2(j) != msg2(j))
			{
				stop = false;
			}
		}

		if (!stop)
		{
			// interleaver for outU, outV and out2
			outU_itlv = itlvU.interleave(outU);
			outV_itlv = itlvV.interleave(outV);
			out2_itlv = itlv2.interleave(out2);

			// from outU, outV, out2, and rx, calculate inU, inV, in2 again
			inU_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) * exp(outV_itlv) * exp(out2_itlv) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,alpha-beta-gamma,sigma2)) /
					(pdf_gaussian(rx,-alpha+beta+gamma,sigma2) * exp(outV_itlv) * exp(out2_itlv) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
			inV_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) * exp(outU_itlv) * exp(out2_itlv) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2)) /
					(pdf_gaussian(rx,alpha-beta+gamma,sigma2) * exp(outU_itlv) * exp(out2_itlv) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
			in2_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) * exp(outU_itlv) * exp(outV_itlv) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2)) /
					(pdf_gaussian(rx,alpha+beta-gamma,sigma2) * exp(outU_itlv) * exp(outV_itlv) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
		}

	}
*/

}

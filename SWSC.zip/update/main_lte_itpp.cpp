#include "itpp/itcomm.h"
#include "turbo_rev.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;




int main(void)
{


	int i, j;	// for loop
	int ch_mode;	// channel parameter mode
	int t_mode;	// termination mode


	// code parameters
	int k;				// message length per codeword
	int n;
	double R;
	int max_iter;			// 8 is the most popular value when used in academic research
	ivec gen1 = "13 15"; ivec gen2 = "13 15"; // octal form, feedback first
	int constraint_length = 4;
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	// power and channel parameters
	double EbN0;
	double sigma2;
	double P;

	bvec msg, cwd, decoded;
	ivec iter_dec;
	vec received;
	
	int ferr;			// number of frame errors
	double berr = 0;		// number of bit errors
	double tot = 0;			// total number of transmitted bits
	double BER;			// bit error rate
	double FER;			// frame error rate
	BERC berc;		// to count bit errors
	
	int target_ferrors;	// simulate until the number of frame errors reaches 'target'
	int num_frames;		// fixed number of simulated frames


	// intput parameters from console
	if (argc == 7)
	{
		k = atoi(argv[1]);
		max_iter = atoi(argv[2]);
		ch_mode = atoi(argv[3]);
		if (ch_mode==1)
		{
			EbN0 = atof(argv[4]);
			P=1.0;
			sigma2 = (0.5*P*(double)(n)/(double)(k))*pow(inv_dB(EbN0), -1.0);	// N0/2
		}
		else
		{
			P = atof(argv[4]);
			sigma2=1.0;
		}
		t_mode = atoi(argv[5]);
		num_frames = atoi(argv[6]);
		target_ferrors = atoi(argv[6]);
	}
	else
	{
		printf("Incorrect input arguments. Check again.\n");
		printf("[Usage] ./lte_turbo [k] [maximum number of iterations] [channel_mode] [EbN0(dB) or avg tx power] [termination_mode] [# of frames or target frame errors]\n");
		printf("k:\tmessage length. it must have one of the following values\n");
		printf("40 48 56 64 72 80 88 96 104 112 120 128 136 144 152 160 168 176 184 192 200 208 216 224 232 240 248 256 264 272 280 288 296 304 312 320 328 336 344 352 360 368 376 384 392 400 408 416 424 432 440 448 456 464 472 480 488 496 504 512 528 544 560 576 592 608 624 640 656 672 688 704 720 736 752 768 784 800 816 832 848 864 880 896 912 928 944 960 976 992 1008 1024 1056 1088 1120 1152 1184 1216 1248 1280 1312 1344 1376 1408 1440 1472 1504 1536 1568 1600 1632 1664 1696 1728 1760 1792 1824 1856 1888 1920 1952 1984 2016 2048 2112 2176 2240 2304 2368 2432 2496 2560 2624 2688 2752 2816 2880 2944 3008 3072 3136 3200 3264 3328 3392 3456 3520 3584 3648 3712 3776 3840 3904 3968 4032 4096 4160 4224 4288 4352 4416 4480 4544 4608 4672 4736 4800 4864 4928 4992 5056 5120 5184 5248 5312 5376 5440 5504 5568 5632 5696 5760 5824 5888 5952 6016 6080 6144\n");
		printf("channel_mode:\t1 -> EbN0(dB), 2 -> average transmit power when sigma^2 = 1\n");
		printf("termination mode:\t1 -> # of simulated frames, 2 -> target # of frame errors\n");
		exit(0);
	}

		
		
	//Punctured_Turbo_Codec_sw code2;
	

	// initialize
	Turbo_Codec_rev code;
	ivec interleaver_sequence = lte_turbo_interleaver_sequence_rev(k);		// internal interleaver for enc1 / dec1	
	code.set_parameters(gen1, gen2, constraint_length, interleaver_sequence, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
	BPSK bpsk;
	AWGN_Channel channel;
	RNG_randomize();	// random generator

	// cacluate actual code length and rate
	n = 3*k + (constraint_length-1)*4;
	R = (double)k / (double)n;

	// channel initialization
	channel.set_noise(sigma2);

	// main loop
	ferr = 0;
	if (t_mode==1)
	{
		for (i=0; i<num_frames; i++)
		{
			msg = randb(k);						// random message generation
			code.encode(msg,cwd);		// LTE rate-matching encoding
			received = channel(sqrt(P)*bpsk.modulate_bits(cwd));	// channel output
			received = received * 2.0 * sqrt(P) / sigma2;		// to calculate LLR
			code.decode_LLR(received, decoded, iter_dec, msg);	// decoding

			// to count fram and bit errors
			berc.clear();
			berc.count(msg, decoded.left(k));

			berr += berc.get_errors();
			tot += double(k);

			if (int(berc.get_errors()) != 0)
			{
				ferr++;
			}
		}

	}
	else
	{
		while (ferr < target_ferrors)
		{
			msg = randb(k);						// random message generation
			code.encode(msg,cwd);		// LTE rate-matching encoding
			received = channel(sqrt(P)*bpsk.modulate_bits(cwd));	// channel output
			received = received * 2.0 * sqrt(P) / sigma2;		// to calculate LLR
			code.decode_LLR(received, decoded, iter_dec, msg);	// decoding

			// to count frame and bit errors
			berc.clear();
			berc.count(msg, decoded.left(k));

			berr += berc.get_errors();
			tot += double(k);

			if (int(berc.get_errors()) != 0)
			{
				ferr++;
			}
		}
	}

	BER = berr / tot;
	FER = ferr / tot * k;
	cout << "BER = " << BER << "\tFER = " << FER << endl;


	return 0;

}



#include "itpp/itcomm.h"
#include "nit_coding.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;

/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/


int main(int argc, char *argv[])
{

	int i, j;	// for loop
	int frame, target_frame;	// current frame number and target number of simulated blocks
	int ferr11, ferr12, ferr21, ferr22;	// current number of frame errors
	double BER11, BER12, BER21, BER22;
	ivec berr11;		// number of bit errors
	ivec berr12;
	ivec berr21;
	ivec berr22;
	vec iterBER11;	// bit error rate 
	vec iterBER12;
	vec iterBER21;
	vec iterBER22;
	char output_name[255];


	bvec msg1_prev, msg1_curr, msg2_prev, msg2_curr;		// binary message vector of length k
	bvec cwd1_prev, cwd1_curr, cwd2_prev, cwd2_curr;		// codeword
	vec tx1, tx2;											// transmitted modulated signals
	vec rx1_prev, rx1_curr, rx2_prev, rx2_curr;				// rx signal from channel
	vec rx1_prev_temp, rx1_curr_temp, rx2_prev_temp1, rx2_prev_temp2, rx2_curr_temp;
	bvec dec11, dec12, dec21, dec22;						// decoded vector
	ivec iter_dec11, iter_dec12, iter_dec21, iter_dec22;	// ?? 


	// code parameters
	int k1, k2;		// message length per codeword
	int n1, n2;
	double targetR1, targetR2;
	double actualR1, actualR2;
	int b;		// frame size
	int max_iter = 8;
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	// power and channel parameters
	double SNR;		// signal to noise power ratio (dB). calculate N0 from this.
	double INR;		// interference to noise power ratio (dB). calculate g from these.i
	double g11, g12, g21, g22;
	double sigma2=1.0;
	double alpha;		// power allocation for U and V in enc1
	double P1, P2;


	// intput parameters from console
	if (argc == 13)
	{
		n2 = atoi(argv[1]);
		b = atoi(argv[2]);
		targetR1 = atof(argv[3]);
		targetR2 = atof(argv[4]);
		P1 = atof(argv[5]);
		P2 = atof(argv[6]);
		alpha = atof(argv[7]);
		g11 = atof(argv[8]);
		g12 = atof(argv[9]);
		g21 = atof(argv[10]);
		g22 = atof(argv[11]);
		target_frame = atoi(argv[12]);
	}
	else
	{
		printf("Incorrect input arguments. Check again.\n");
		printf("[Usage] ./swsc_lte_turbo [n] [b] [R1] [R2] [P1] [P2] [alpha] [g11] [g12] [g21] [g22] [# of simulation frames]\n");
		printf("***********************************************************************************************\n");
		printf("Y1 = g11*sqrt(alpha)*sqrt(P1)*U + g11*sqrt(alpha)*sqrt(P1)*V + g12*sqrt(1-alpha)*sqrt(P2)*W + Z1\n");
		printf("Y2 = g21*sqrt(alpha)*sqrt(P1)*U + g21*sqrt(alpha)*sqrt(P1)*V + g22*sqrt(1-alpha)*sqrt(P2)*W + Z2\n");
		printf("Here, U,V,W are BPSK modulated signals and Zi~N(0,1)\n");
		printf("***********************************************************************************************\n");
		printf("n:\tblock size -> n bits consist of one block for all tx/rx pairs\n");
		printf("b:\tframe size -> b blocks consist of one frame\n");
		printf("R1:\toperating rate of tx1/rx1\n");
		printf("R2:\toperating rate of tx2/rx2\n");
		exit(0);
	}

	//n2 = (int)((double)k2 / R2);		// each codeword length including tail bits
	n1 = 2 * n2;

	// k1 and k2 search
	k1 = lte_search_k(n1, targetR1/2.0);
	k2 = lte_search_k(n2, targetR2);

	actualR1 = (double)(k1) / (double)(n1) * 2.0;		// each codeword length including tail bits
	actualR2 = (double)(k2) / (double)(n2);		// each codeword length including tail bits

	// initialize
	Punctured_Turbo_Codec_rev code1;
	Punctured_Turbo_Codec_rev code2;
	code1.lte_set_parameters(k1, n1, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
	code2.lte_set_parameters(k2, n2, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
	BPSK bpsk;
	AWGN_Channel channel;
	BERC berc11, berc12, berc21, berc22;		// for calculation of bit errors
	RNG_randomize();	// random generator
	channel.set_noise(sigma2);

	berr11 = zeros_i(b);	// number of bit errors
	berr12 = zeros_i(b);
	berr21 = zeros_i(b);
	berr22 = zeros_i(b);
	iterBER11 = zeros(b);	// bit error rate 
	iterBER12 = zeros(b);
	iterBER21 = zeros(b);
	iterBER22 = zeros(b);



	// main loop
	frame=0; ferr11 = 0; ferr12 = 0; ferr21 = 0; ferr22 = 0;
	while (frame < target_frame)
	{
		// initialization at time 0
		msg1_curr = randb(k1);
		msg2_curr = randb(k2);
		code1.lte_turbo_rate_matching_encode(msg1_curr, cwd1_curr);
		code2.lte_turbo_rate_matching_encode(msg2_curr, cwd2_curr);
		rx1_curr = zeros(n2);
		rx2_curr = zeros(n2);

		// within each frame, b blocks are simulated
		for (i=0; i<b; i++)
		{
			msg1_prev = msg1_curr;
			cwd1_prev = cwd1_curr;
			msg2_prev = msg2_curr;
			cwd2_prev = cwd2_curr;
			rx1_prev = rx1_curr;
			rx2_prev = rx2_curr;

			// encoder 1
			msg1_curr = randb(k1);											// random message generation
			code1.lte_turbo_rate_matching_encode(msg1_curr, cwd1_curr);		// rate-matching encoding
			tx1 = sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(cwd1_prev.right(n2)) + sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(cwd1_curr.left(n2));	// tx1(curr) = sqrt(alpha)*sqrt(P1)*U(prev) + sqrt(1-alpha)*sqrt(P1)*V(curr)

			// encoder 2
			msg2_curr = randb(k2);											// random message generation
			code2.lte_turbo_rate_matching_encode(msg2_curr, cwd2_curr);		// rate-matching encoding
			tx2 = sqrt(P2)*bpsk.modulate_bits(cwd2_curr);					// X2(curr) = sqrt(P2)*W(curr)


			// channel
			rx1_curr = channel(g11*tx1 + g12*tx2);
			rx2_curr = channel(g21*tx1 + g22*tx2);

			//////////// decoder 1 ///////////////
			
			if (i==0)				// There is nothing to decode for message 1 and only decode for msg2 at the first block. Assume that decoder 1 already knew the message 1 of time 0.
			{
				// decoding for msg2_curr
				dec11 = msg1_prev;			// Decoder 1 already knew the message 1 of time 0
				rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec11)).right(n2));	// rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*{\hat U}
				code2.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_12(rx1_curr_temp, alpha, P1, P2, g11, g12, sigma2), dec12, iter_dec12, msg2_curr);	// decoding for msg2

				// bit error count for msg2
				berc12.clear();						
				berc12.count(msg2_curr, dec12);
				berr12(i) += berc12.get_errors();
			}
			else if (i==b-1)		// At the last block, decoder 1 is assumed to know msg1(b-1) and need to decode for msg1(b-2).
			{
				// decoding for msg1_prev
				rx1_prev_temp = rx1_prev - g11*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec11)).right(n2)) - g12*sqrt(P2)*bpsk.modulate_bits(code2.lte_turbo_rate_matching_encode(dec12));		// rx1_prev_temp = rx1_prev - g11*sqrt(alpha)*sqrt(P1)*{\hat U} - g12*sqrt(P2)*{\hat W}
				rx1_curr_temp = rx1_curr - g11*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(msg1_curr)).left(n2));			// decoder 1 knows msg1_curr at the last block. rx1_curr_temp = rx1_curr - g11*sqrt(1-alpha)*sqrt(P1)*V
				code1.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_11_last(rx1_prev_temp, rx1_curr_temp, alpha, P1, P2, g11, g12, sigma2), dec11, iter_dec11, msg1_prev);	// decoding for msg1 following LLR calculation based on two rx values

				// bit error count for msg1
				berc11.clear();						
				berc11.count(msg1_prev, dec11);
				berr11(i) += berc11.get_errors();

				// decoding for msg2_curr
				rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec11)).right(n2)) - g11*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(msg1_curr)).left(n2));	// rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*{\hat U} - g11*sqrt(1-alpha)*sqrt(P1)*{\hat V}
				rx1_curr_temp *= 2.0*g12*sqrt(P2) / sigma2;													// LLR calculation
				code2.lte_turbo_rate_matching_decode_LLR(rx1_curr_temp, dec12, iter_dec12, msg2_curr);		// decoding for msg2

				// bit error count for msg2
				berc12.clear();						
				berc12.count(msg2_curr, dec12);
				berr12(i) += berc12.get_errors();
			}
			else
			{
				// decoding for msg1_prev
				rx1_prev_temp = rx1_prev - g11*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec11)).right(n2)) - g12*sqrt(P2)*bpsk.modulate_bits(code2.lte_turbo_rate_matching_encode(dec12));		// rx1_prev_temp = rx1_prev - g11*sqrt(alpha)*sqrt(P1)*{\hat U} - g12*sqrt(P2)*{\hat W}
				code1.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_11(rx1_prev_temp, rx1_curr, alpha, P1, P2, g11, g12, sigma2), dec11, iter_dec11, msg1_prev);	// decoding for msg1

				// bit error count for msg1
				berc11.clear();
				berc11.count(msg1_prev, dec11);
				berr11(i) += berc11.get_errors();

				// decoding for msg2_curr
				rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec11)).right(n2));		// rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*{\hat U}
				code2.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_12(rx1_curr_temp, alpha, P1, P2, g11, g12, sigma2), dec12, iter_dec12, msg2_curr);	// decoding for msg2

				// bit error count for msg2
				berc12.clear();
				berc12.count(msg2_curr, dec12);
				berr12(i) += berc12.get_errors();
			}

			////////////// decoder2 //////////////
			
			if (i==0)				// At the first block, decoder 2 decodes nothing.
			{
				dec21 = msg1_prev;
			}
			else if (i==b-1)		// At the last block, decoder 2 knows msg1_curr and decodes for msg1_prev, msg2_prev, and msg2_curr.
			{
				// decoding for msg1_prev
				rx2_prev_temp1 = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec21)).right(n2));		// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U}
				rx2_curr_temp = rx2_curr - g21*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(msg1_curr)).left(n2));	// rx2_curr_temp = rx2_curr - g21*sqrt(1-alpha)*sqrt(P1)*V
				code1.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_21_last(rx2_prev_temp1, rx2_curr_temp, alpha, P1, P2, g21, g22, sigma2), dec21, iter_dec21, msg1_prev);	// decoding for msg1
				
				// bit error count for msg1
				berc21.clear();
				berc21.count(msg1_prev, dec21);
				berr21(i) += berc21.get_errors();

				// decoding for msg2_prev
				rx2_prev_temp2 = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec21)).right(n2)) - g21*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec21)).left(n2));		// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U} - g21*sqrt(1-alpha)*sqrt(P1)*{\hat V}
				code2.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_22(rx2_prev_temp2,P2,g22,sigma2), dec22, iter_dec22, msg2_prev);		// decoding for msg2_prev

				// bit error count for msg2
				berc22.clear();
				berc22.count(msg2_prev, dec22);
				berr22(i) += berc22.get_errors();

				// decoding for msg2_curr
				rx2_curr_temp = rx2_curr - g21*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec21)).right(n2)) - g21*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(msg1_curr)).left(n2));	// rx2_curr_temp = rx2_curr - g21*sqrt(alpha)*sqrt(P1)*{\hat U} - g21*sqrt(1-alpha)*sqrt(P1)*V
				code2.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_22(rx2_curr_temp,P2,g22,sigma2), dec22, iter_dec22, msg2_curr);		// decoding for msg2_curr

				// bit error count for msg2
				berc22.clear();
				berc22.count(msg2_curr, dec22);
				berr22(i) += berc22.get_errors();

			}
			else
			{
				// decoding for msg1_prev
				rx2_prev_temp1 = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec21)).right(n2));		// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U}
				code1.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_21(rx2_prev_temp1, rx2_curr, alpha, P1, P2, g21, g22, sigma2), dec21, iter_dec21, msg1_prev);	// decoding for msg1

				// bit error count for msg1
				berc21.clear();
				berc21.count(msg1_prev, dec21);
				berr21(i) += berc21.get_errors();

				// decoding for msg2_prev
				rx2_prev_temp2 = rx2_prev_temp1 - g21*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits((code1.lte_turbo_rate_matching_encode(dec21)).left(n2));	// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U} - g21*sqrt(1-alpha)*sqrt(P1)*{\hat V}
				code2.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_22(rx2_prev_temp2,P2,g22,sigma2), dec22, iter_dec22, msg2_prev);

				// bit error count for msg2
				berc22.clear();
				berc22.count(msg2_prev, dec22);
				berr22(i) += berc22.get_errors();

			}

			// block error count for all cases
			if (int(berc11.get_errors()) != 0)
			{
				ferr11++;  //cout << "ferr11 = " << ferr11 << "\t";
			}
			if (int(berc12.get_errors()) != 0)
			{
				ferr12++; //cout << "ferr12 = " << ferr12 << "\t";
			}
			if (int(berc21.get_errors()) != 0)
			{
				ferr21++;  //cout << "ferr21 = " << ferr21 << "\t";
			}
			if (int(berc22.get_errors()) != 0)
			{
				ferr22++;  //cout << "ferr22 = " << ferr22 << "\t";
			}

		}

		frame++;

	}

	// calculate BER per iteration
	iterBER12(0) = (double)berr12(0) / (double)(frame*k2);
	for (i=1; i<b; i++)
	{
		iterBER11(i) = (double)berr11(i) / (double)(frame*k1);
		iterBER12(i) = (double)berr12(i) / (double)(frame*k2);
		iterBER21(i) = (double)berr21(i) / (double)(frame*k1);
		iterBER22(i) = (double)berr22(i) / (double)(frame*k2);
	}
	iterBER22(b-1) = iterBER22(b-1) / 2.0;

	// calculate average BER
	BER11=0; BER12=iterBER12(0); BER21=0; BER22=0;
	for (i=1; i<b; i++)
	{
		BER11 += iterBER11(i);
		BER12 += iterBER12(i);
		BER21 += iterBER21(i);
		BER22 += iterBER22(i);
	}
	BER22 += iterBER22(b-1);

	BER11= BER11 / (double)(b-1);
	BER12= BER12 / (double)(b);
	BER21= BER21 / (double)(b-1);
	BER22= BER22 / (double)(b);

	// print
	cout << "target (R1,R2) = (" << targetR1 << "," << targetR2 << ")" << endl;
	cout << "actual (R1,R2) = (" << actualR1 << "," << actualR2 << ")" << endl;
	cout << "code1\t(" << n1 << "," << k1 << ")\tcode2\t(" << n2 << "," << k2 << ")\tb\t" << b << "\tP1\t" << P1 << "\tP2\t" << P2 << "\talpha\t" << alpha << "\t(g11,g12,g21,g22)\t(" << g11 << "," << g12 << "," << g21 << "," << g22 << ")\tnum_frame\t" << target_frame << endl;
	cout << "BER11 = " << BER11 << "\t" << "BER12 = " << BER12 << "\t" << "BER21 = " << BER21 << "\t" << "BER22 = " << BER22 << endl;
	cout << iterBER11 << endl;
	cout << iterBER12 << endl;
	cout << iterBER21 << endl;
	cout << iterBER22 << endl;

/*
	sprintf(output_name, "SW_%d_%.3f_%.3f_%d_%.3f_%.3f.it",n2,actualR1,actualR2,b,g,sigma2);
	it_file ff(output_name);
	ff << Name("g") << g;
	ff << Name("sigma2") << sigma2;
	ff << Name("R1") << actualR1;
	ff << Name("R2") << actualR2;
	ff << Name("BER11") << BER11;
	ff << Name("BER12") << BER12;
	ff << Name("BER21") << BER21;
	ff << Name("BER22") << BER22;
	ff << Name("iterBER11") << iterBER11;
	ff << Name("iterBER12") << iterBER12;
	ff << Name("iterBER21") << iterBER21;
	ff << Name("iterBER22") << iterBER22;
	ff.close();
*/
	return 0;

}


#include "itpp/itcomm.h"
#include "turbo_rev.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;




int main(void)
{

	int i, j;	// for loop

	// code parameters
	int k = 512;		// message length per codeword
	ivec gen1 = "13 15"; ivec gen2 = "13 15"; // octal form, feedback first
	int constraint_length = 4;
	ivec interleaver_sequence1 = lte_turbo_interleaver_sequence_rev(k);		// internal interleaver for enc1 / dec1
	//ivec interleaver_sequence2 = lte_turbo_interleaver_sequence_rev(k);		// internal interleaver for enc2 / dec2
	//bmat pmatrix2 = "1 1 1 1; 1 0 0 0; 0 0 1 0";		// puncturing pattern for enc2 / dec2
	int max_iter = 8;
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	// power and channel parameters
	double Ec = 1.0;	// coded bit energy
	int target_ferrors = 100;	// simulate until the number of frame errors reaches 'target'


	Turbo_Codec_rev code1;
	//Punctured_Turbo_Codec_sw code2;
	code1.set_parameters(gen1, gen2, constraint_length, interleaver_sequence1, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
	//code2.set_parameters(gen1, gen2, constraint_length, interleaver_sequence2, pmatrix2, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
	BPSK bpsk;
	AWGN_Channel channel;
	RNG_randomize();	// random generator

	int ch;
	int ferr;
	bvec msg, cwd, decoded;
	bvec decoded_polar;
	ivec iter_dec;
	vec received;
	vec EbN01 = "1.25:0.25:1.5";
	//vec EbN02 = "1.0:0.25:3.0";
	double R1 = 1.0 / 3.0;
	//double R2 = 2.0 / 3.0;
	vec berr1 = zeros(EbN01.length());		// number of bit errors for each channel
	vec berr1_polar = zeros(EbN01.length());		// number of bit errors for each channel
	//vec berr2 = zeros(EbN02.length());		// number of bit errors for each channel
	vec tot1 = zeros(EbN01.length());		// total number of transmitted bits for each channel
	//vec tot2 = zeros(EbN02.length());		// total number of transmitted bits for each channel
	vec BER1(EbN01.length());
	vec BER1_polar(EbN01.length());
	//vec BER2(EbN02.length());

	vec sigma2;
	BERC berc;		// for calculation of bit errors



	// main loop
	sigma2 = (0.5*Ec/R1)*pow(inv_dB(EbN01), -1.0);	// N0/2
	for(ch=0; ch < EbN01.length(); ch++)
	{
		cout << "EbN0(dB)_1 = " << EbN01(ch) << "\t";
		channel.set_noise(sigma2(ch));
		code1.set_awgn_channel_parameters(Ec, 2.0*sigma2(ch));

		ferr = 0; 
		while (ferr < target_ferrors)
		{
			//msg = randb(k);
			msg = zeros_b(k);
			code1.encode(msg,cwd);
			received = channel(bpsk.modulate_bits(cwd));
			code1.decode(received, decoded, iter_dec, msg);
			code1.decode_polar(received, decoded_polar, iter_dec, msg);


			berc.clear();
			berc.count(msg, decoded_polar.left(k));

			berr1_polar(ch) += berc.get_errors();


			berc.clear();
			berc.count(msg, decoded.left(k));

			berr1(ch) += berc.get_errors();



			tot1(ch) += double(k);

			if (int(berc.get_errors()) != 0)
			{
				ferr++;
			}
		}

		BER1(ch) = berr1(ch) / tot1(ch);
		BER1_polar(ch) = berr1_polar(ch) / tot1(ch);
		cout << "BER = " << BER1(ch) << endl;
		cout << "BER_polar = " << BER1_polar(ch) << endl;

	}


/*
	   it_file ff("result_512.it");
	   ff << Name("EbN01(dB)") << EbN01;
	   //ff << Name("EbN02(dB)") << EbN02;
	   ff << Name("BER1") << BER1;
	   ff << Name("BER1_polar") << BER1_polar;
	   //ff << Name("BER2") << BER2;
	   ff.close();
*/



	return 0;

}



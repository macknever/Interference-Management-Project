#include "itpp/itcomm.h"
#include "turbo_rev.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;



int main(int argc, char *argv[])
{

	int i, j;	// for loop
	int ch_mode;	// channel parameter mode
	char msg_file_name[255];
	char rx_file_name[255];

	// code parameters
	int k;				// message length per codeword
	int n;
	int max_iter;			// 8 is the most popular value when used in academic research
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	// power and channel parameters
	double EbN0;
	double sigma2;
	double P;

	bmat msg;
	bvec decoded;
	ivec iter_dec;
	mat received;
	vec temp;
	
	int ferr;			// number of frame errors
	double berr = 0;		// number of bit errors
	double tot = 0;			// total number of transmitted bits
	double BER;			// bit error rate
	double FER;			// frame error rate
	BERC berc;		// to count bit errors
	
	int num_frames;		// fixed number of simulated frames


	// intput parameters from console
	if (argc == 9)
	{
		k = atoi(argv[1]);
		n = atoi(argv[2]);
		max_iter = atoi(argv[3]);
		ch_mode = atoi(argv[4]);
		if (ch_mode==1)
		{
			EbN0 = atof(argv[5]);
			P=1.0;
			sigma2 = (0.5*P*(double)(n)/(double)(k))*pow(inv_dB(EbN0), -1.0);	// N0/2
		}
		else
		{
			P = atof(argv[5]);
			sigma2=1.0;
		}
		num_frames = atoi(argv[6]);
		sprintf(msg_file_name, "%s", argv[7]);
		sprintf(rx_file_name, "%s", argv[8]);
	}
	else
	{
		printf("Incorrect input arguments. Check again.\n");
		printf("[Usage] ./lte_turbo [k] [n] [maximum number of iterations] [channel_mode] [EbN0(dB) or avg tx power] [# of frames] [msg_filename] [rx_filename]\n");
		printf("k:\tmessage length. it must have one of the following values\n");
		printf("40 48 56 64 72 80 88 96 104 112 120 128 136 144 152 160 168 176 184 192 200 208 216 224 232 240 248 256 264 272 280 288 296 304 312 320 328 336 344 352 360 368 376 384 392 400 408 416 424 432 440 448 456 464 472 480 488 496 504 512 528 544 560 576 592 608 624 640 656 672 688 704 720 736 752 768 784 800 816 832 848 864 880 896 912 928 944 960 976 992 1008 1024 1056 1088 1120 1152 1184 1216 1248 1280 1312 1344 1376 1408 1440 1472 1504 1536 1568 1600 1632 1664 1696 1728 1760 1792 1824 1856 1888 1920 1952 1984 2016 2048 2112 2176 2240 2304 2368 2432 2496 2560 2624 2688 2752 2816 2880 2944 3008 3072 3136 3200 3264 3328 3392 3456 3520 3584 3648 3712 3776 3840 3904 3968 4032 4096 4160 4224 4288 4352 4416 4480 4544 4608 4672 4736 4800 4864 4928 4992 5056 5120 5184 5248 5312 5376 5440 5504 5568 5632 5696 5760 5824 5888 5952 6016 6080 6144\n");
		printf("n:\tcode length\n");
		printf("channel_mode:\t1 -> EbN0(dB), 2 -> average transmit power when sigma^2 = 1\n");
		exit(0);
	}


	// initialize
	Punctured_Turbo_Codec_rev code;
	code.lte_set_parameters(k, n, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);

	it_file ff(msg_file_name);
	ff >> Name("msg") >> msg;
	ff.close();

	ff.open(rx_file_name);
	ff >> Name("received") >> received;
	ff.close();

	// main loop
	ferr = 0;
	for (i=0; i<num_frames; i++)
	{
		temp = received.get_row(i) * 2.0 * sqrt(P) / sigma2;		// to calculate LLR
		code.lte_turbo_rate_matching_decode_LLR(temp, decoded, iter_dec, msg.get_row(i));	// decoding

		// to count fram and bit errors
		berc.clear();
		berc.count(msg.get_row(i), decoded.left(k));

		berr += berc.get_errors();
		tot += double(k);

		if (int(berc.get_errors()) != 0)
		{
			ferr++;
		}
	}


	BER = berr / tot;
	FER = ferr / tot * k;


	cout << "k=\t" << k << "\tn=\t" << n << "\t";
	if (ch_mode==1)
	{
		cout << "EbN0(dB)=\t" << EbN0 << endl;
	}
	else
	{
		cout << "P=\t" << P << "\tsigma^2=\t" << sigma2 << endl;
	}

	cout << "BER=\t" << BER << "\tFER=\t" << FER << endl;

	return 0;

}




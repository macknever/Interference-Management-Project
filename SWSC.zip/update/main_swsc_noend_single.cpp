#include "itpp/itcomm.h"
#include "nit_coding.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;


int main(int argc, char *argv[])
{

	int i, j;	// for loop
	int frame, target_frame;	// current frame number and target number of simulated blocks
	int blerr;			// current number of block errors
	int blerr_prev;			// to detect the increase of blerr to calculate ferr
	int ferr;			// current number of frame errors
	double BER;
	double BLER;
	double FER;
	ivec berr;		// number of bit errors
	vec iterBER;	// bit error rate 
	char output_name[255];


	bvec msg_prev, msg_curr;		// binary message vector of length k
	bvec cwd_prev, cwd_curr;		// codeword
	vec tx;											// transmitted modulated signals
	vec rx_prev, rx_curr;				// rx signal from channel
	vec rx_prev_temp;
	vec rx_curr_temp;
	bvec dec;						// decoded vector
	ivec iter_dec;	// ?? 


	// code parameters
	int k;		// symbol message length per block
	int kb;		// bit message length per block
	int n;		// block length w.r.t. sysbols
	int nb;		// block length w.r.t. bits
	int b;		// frame size
	int max_iter = 8;
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	// power and channel parameters
	double SNR;		// signal to noise power ratio (dB). calculate N0 from this.
	double sigma2=1.0;
	double alpha;		// power allocation for U and V in enc1
	double P;

	int mode;

	ivec interleaver;
	ivec deinterleaver;


	// intput parameters from console
	if (argc == 8)
	{
		k = atoi(argv[1]);
		n = atoi(argv[2]);
		b = atoi(argv[3]);
		P = atof(argv[4]);
		alpha = atof(argv[5]);
		target_frame = atoi(argv[6]);
		mode = atoi(argv[7]);
	}
	else
	{
		printf("Incorrect input arguments. Check again.\n");
		printf("[Usage] ./exe_swsc_noend_single [k] [n] [b] [P] [alpha] [# of simulation frames] [mode]\n");
		printf("***********************************************************************************************\n");
		printf("Y = sqrt(alpha)*sqrt(P)*U + sqrt(alpha)*sqrt(P)*V + Z\n");
		printf("Here, U,V are BPSK modulated signals and Z~N(0,1)\n");
		printf("and U is generated from the previous message and V from the current message\n");
		printf("***********************************************************************************************\n");
		printf("k:\tsymbol message length per block. 2*k must have one of the following values\n");
		printf("40 48 56 64 72 80 88 96 104 112 120 128 136 144 152 160 168 176 184 192 200 208 216 224 232 240 248 256 264 272 280 288 296 304 312 320 328 336 344 352 360 368 376 384 392 400 408 416 424 432 440 448 456 464 472 480 488 496 504 512 528 544 560 576 592 608 624 640 656 672 688 704 720 736 752 768 784 800 816 832 848 864 880 896 912 928 944 960 976 992 1008 1024 1056 1088 1120 1152 1184 1216 1248 1280 1312 1344 1376 1408 1440 1472 1504 1536 1568 1600 1632 1664 1696 1728 1760 1792 1824 1856 1888 1920 1952 1984 2016 2048 2112 2176 2240 2304 2368 2432 2496 2560 2624 2688 2752 2816 2880 2944 3008 3072 3136 3200 3264 3328 3392 3456 3520 3584 3648 3712 3776 3840 3904 3968 4032 4096 4160 4224 4288 4352 4416 4480 4544 4608 4672 4736 4800 4864 4928 4992 5056 5120 5184 5248 5312 5376 5440 5504 5568 5632 5696 5760 5824 5888 5952 6016 6080 6144\n");
		printf("n:\tblock size -> n symbols consist of one block\n");
		printf("b:\tframe size -> b blocks consist of one frame\n");
		printf("mode:\t1 -> U parity, V message, 2 -> U message, V parity, 3-> interleaver. All for [V|U].\n");
		exit(0);
	}


	// initialize
	Punctured_Turbo_Codec_rev code;
	nb = 2*n;		// code length for [V(j)|U(j+1)]
	kb = 2*k;		// message length for [V(j)|U(j+1)]
	code.lte_set_parameters(kb, nb, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
	BPSK bpsk;
	AWGN_Channel channel;
	BERC berc;		// for calculation of bit errors
	RNG_randomize();	// random generator
	channel.set_noise(sigma2);

	berr = zeros_i(b);	// number of bit errors
	iterBER = zeros(b);	// bit error rate 

	// generate random interleaver
	interleaver = sort_index(randu(nb));
	deinterleaver = sort_index(interleaver);

	if (mode==1)
	{

		// main loop
		frame=0; blerr = 0; blerr_prev = 0; ferr = 0; 
		while (frame < target_frame)
		{
			// initialization at time 0
			msg_curr = randb(kb);
			code.lte_turbo_rate_matching_encode(msg_curr, cwd_curr);
			rx_curr = zeros(nb);

			// within each frame, b blocks are simulated
			for (i=0; i<b; i++)
			{
				msg_prev = msg_curr;
				cwd_prev = cwd_curr;
				rx_prev = rx_curr;

				// encoder
				msg_curr = randb(kb);											// random message generation
				code.lte_turbo_rate_matching_encode(msg_curr, cwd_curr);		// rate-matching encoding
				tx = sqrt(alpha)*sqrt(P)*bpsk.modulate_bits(cwd_prev.right(n)) + sqrt(1.0-alpha)*sqrt(P)*bpsk.modulate_bits(cwd_curr.left(n));	// tx(curr) = sqrt(alpha)*sqrt(P)*U(prev) + sqrt(1-alpha)*sqrt(P)*V(curr)


				// channel
				rx_curr = channel(tx);

				//////////// decoder ///////////////

				if (i==0)				// There is nothing to decode. Assume that decoder already knew the message of time 0.
				{
					dec = msg_prev;			// Decoder 1 already knew the message 1 of time 0

				}
				else
				{
					// decoding for msg1_prev
					rx_prev_temp = rx_prev - sqrt(alpha)*sqrt(P)*bpsk.modulate_bits((code.lte_turbo_rate_matching_encode(dec)).right(n));		// rx_prev_temp = rx_prev - sqrt(alpha)*sqrt(P)*{\hat U}
					code.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_single(rx_prev_temp, rx_curr, alpha, P, sigma2), dec, iter_dec, msg_prev);	// decoding for msg_prev

					// bit error count for msg1
					berc.clear();
					berc.count(msg_prev, dec);
					berr(i) += berc.get_errors();
				}


				// block error count
				if (int(berc.get_errors()) != 0)
				{
					blerr++;  
				}
			}

			// to calculate ferr
			if (blerr > blerr_prev)
			{
				ferr++;
				blerr_prev = blerr;
			}

			frame++;

		}

	}
	else if (mode==2)
	{
		// main loop
		frame=0; blerr = 0; blerr_prev = 0; ferr = 0; 
		while (frame < target_frame)
		{
			// initialization at time 0
			msg_curr = randb(kb);
			code.lte_turbo_rate_matching_encode(msg_curr, cwd_curr);
			rx_curr = zeros(nb);

			// within each frame, b blocks are simulated
			for (i=0; i<b; i++)
			{
				msg_prev = msg_curr;
				cwd_prev = cwd_curr;
				rx_prev = rx_curr;

				// encoder
				msg_curr = randb(kb);											// random message generation
				code.lte_turbo_rate_matching_encode(msg_curr, cwd_curr);		// rate-matching encoding
				tx = sqrt(alpha)*sqrt(P)*bpsk.modulate_bits(cwd_prev.left(n)) + sqrt(1.0-alpha)*sqrt(P)*bpsk.modulate_bits(cwd_curr.right(n));	// tx(curr) = sqrt(alpha)*sqrt(P)*U(prev) + sqrt(1-alpha)*sqrt(P)*V(curr)


				// channel
				rx_curr = channel(tx);

				//////////// decoder ///////////////

				if (i==0)				// There is nothing to decode. Assume that decoder already knew the message of time 0.
				{
					dec = msg_prev;			// Decoder 1 already knew the message 1 of time 0

				}
				else
				{
					// decoding for msg1_prev
					rx_prev_temp = rx_prev - sqrt(alpha)*sqrt(P)*bpsk.modulate_bits((code.lte_turbo_rate_matching_encode(dec)).left(n));		// rx_prev_temp = rx_prev - sqrt(alpha)*sqrt(P)*{\hat U}
					code.lte_turbo_rate_matching_decode_LLR(sw_calc_LLR_single_temp(rx_prev_temp, rx_curr, alpha, P, sigma2), dec, iter_dec, msg_prev);	// decoding for msg_prev

					// bit error count for msg1
					berc.clear();
					berc.count(msg_prev, dec);
					berr(i) += berc.get_errors();
				}


				// block error count
				if (int(berc.get_errors()) != 0)
				{
					blerr++;  
				}
			}

			// to calculate ferr
			if (blerr > blerr_prev)
			{
				ferr++;
				blerr_prev = blerr;
			}

			frame++;

		}

	}
	else if (mode==3)
	{
		// main loop
		frame=0; blerr = 0; blerr_prev = 0; ferr = 0; 
		while (frame < target_frame)
		{
			// initialization at time 0
			msg_curr = randb(kb);
			code.lte_turbo_rate_matching_encode(msg_curr, cwd_curr);
			cwd_curr = cwd_curr(interleaver);
			rx_curr = zeros(nb);

			// within each frame, b blocks are simulated
			for (i=0; i<b; i++)
			{
				msg_prev = msg_curr;
				cwd_prev = cwd_curr;
				rx_prev = rx_curr;

				// encoder
				msg_curr = randb(kb);											// random message generation
				code.lte_turbo_rate_matching_encode(msg_curr, cwd_curr);		// rate-matching encoding
				cwd_curr = cwd_curr(interleaver);
				tx = sqrt(alpha)*sqrt(P)*bpsk.modulate_bits(cwd_prev.right(n)) + sqrt(1.0-alpha)*sqrt(P)*bpsk.modulate_bits(cwd_curr.left(n));	// tx(curr) = sqrt(alpha)*sqrt(P)*U(prev) + sqrt(1-alpha)*sqrt(P)*V(curr)


				// channel
				rx_curr = channel(tx);

				//////////// decoder ///////////////

				if (i==0)				// There is nothing to decode. Assume that decoder already knew the message of time 0.
				{
					dec = msg_prev;			// Decoder 1 already knew the message 1 of time 0

				}
				else
				{
					// decoding for msg1_prev
					rx_prev_temp = rx_prev - sqrt(alpha)*sqrt(P)*bpsk.modulate_bits(((code.lte_turbo_rate_matching_encode(dec))(interleaver)).right(n));		// rx_prev_temp = rx_prev - sqrt(alpha)*sqrt(P)*{\hat U}
					code.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_single(rx_prev_temp, rx_curr, alpha, P, sigma2))(deinterleaver), dec, iter_dec, msg_prev);	// decoding for msg_prev

					// bit error count for msg1
					berc.clear();
					berc.count(msg_prev, dec);
					berr(i) += berc.get_errors();
				}


				// block error count
				if (int(berc.get_errors()) != 0)
				{
					blerr++;  
				}
			}

			// to calculate ferr
			if (blerr > blerr_prev)
			{
				ferr++;
				blerr_prev = blerr;
			}

			frame++;

		}


	}


	// calculate BER per iteration
	for (i=1; i<b; i++)
	{
		iterBER(i) = (double)berr(i) / (double)(target_frame*kb);
	}

	// calculate average BER, BLER, FER
	BER=0; 
	for (i=1; i<b; i++)
	{
		BER += iterBER(i);
	}

	BER= BER / (double)(b-1);

	BLER = blerr / (double)((b-1)*target_frame);
	FER = ferr / (double)target_frame;


	// print
	cout << "k\t" << k << "\tn\t" << n << "\tb\t" << b << "\tP\t" << P << "\talpha\t" << alpha << "\tnum_frame\t" << target_frame << "\tmode\t" << mode << endl;
	cout << "BER\t" << BER << "\tBLER\t" << BLER << "\tFER\t" << FER << endl;
//	cout << "iter_BER\t" << iterBER << endl;

	return 0;

}


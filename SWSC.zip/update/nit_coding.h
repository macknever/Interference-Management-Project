#include "itpp/itcomm.h"
#include "turbo_rev.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;


/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/

int lte_search_k(const int n, const double R);

double pdf_gaussian(const double y, const double mean, const double sigma2);

vec pdf_gaussian(const vec y, const double mean, const double sigma2);

//vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_single(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2);
vec sw_calc_LLR_single_temp(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2);

//vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_single_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2);

//vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2);

//vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2);
vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2);

//vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2);
vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2);

//vec sw_calc_LLR_22(const vec &rx_prev, const double sigma2);
//vec sw_calc_LLR_22(const vec &rx_prev, const double P, const double g21, const double g22, const double sigma2);
vec sw_calc_LLR_22(const vec &rx_prev, const double P2, const double g22, const double sigma2);

vec sc_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_12(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_2U(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_2V(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_22(const vec &rx, const double alpha, const double g, const double sigma2);

vec ian_calc_LLR_1(const vec &rx, const double alpha, const double g, const double sigma2);

vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2);
vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2);

vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2);
vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2);

vec ian_calc_LLR_2(const vec &rx, const double alpha, const double g, const double sigma2);
vec ian_calc_LLR_2(const vec &rx, const double alpha, const double P, const double g21, const double g22, const double sigma2);


vec mlc_calc_LLR_single(const vec &rx, const double alpha, const double P, const double sigma2);

void sd_joint_decode(Punctured_Turbo_Codec_rev codeU, Punctured_Turbo_Codec_rev codeV, Punctured_Turbo_Codec_rev code2, Sequence_Interleaver<double> itlvU, Sequence_Interleaver<double> itlvV, Sequence_Interleaver<double> itlv2, const vec &rx, bvec &decU, bvec &decV, bvec &dec2, const bvec &msgU, const bvec &msgV, const bvec &msg2, const double alpha, const double beta, const double gamma, const double sigma2);

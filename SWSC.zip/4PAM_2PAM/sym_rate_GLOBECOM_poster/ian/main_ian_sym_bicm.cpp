#include "itpp/itcomm.h"
#include "nit_coding.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;

/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/


int main(int argc, char *argv[])
{

	int i, j;	// for loop
	int block, num_block;	// current block number and target number of simulated blocks
	int ch, num_ch;
	int seed;

	int blerr1, blerr2;
	int berr1, berr2;		// number of bit errors
	
	double BLER1, BLER2;
	double BER1, BER2;
	double target_BLER;

	bvec msg1, msg2;
	bvec cwd1, cwd2, cwdU, cwdV;		// codeword
	vec tx1, tx2;											// transmitted modulated signals
	vec rx1, rx2;
	vec LLR1, LLR2, LLRU, LLRV;
	bvec dec1, dec2;						// decoded vector
	ivec iter_dec1, iter_dec2;	// ?? 


	// code parameters
	int k1, k2;		// message length per codeword
	int n, n1, n2;
	double R, R_lower, R_upper, R_avg, R_SWSC;
	double R_SWSC_avg, R_SND_avg, R_SD_avg, R_IAN_avg;
	double R_SND, R_SD, R_IAN;
	int R_iter, R_cnt;
	double actualR1, actualR2;
	int max_iter = 8;
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	const int MAX_INTERLEAVER_SIZE = 6144;
	const int MIN_INTERLEAVER_SIZE = 40;

	// power and channel parameters
	double SNR_dB;		// signal to noise power ratio (dB). calculate N0 from this.
	double INR_dB;		// interference to noise power ratio (dB). calculate g from these.i
	double g11, g12, g21, g22;
	double sigma2;
	double alpha;		// power allocation for U and V in enc1
	double P1, P2;

	ivec interleaver1, deinterleaver1;
	ivec interleaver2, deinterleaver2;


	// intput parameters from console
	if (argc == 10)
	{
		n = atoi(argv[1]);
		R_iter = atoi(argv[2]);
		SNR_dB = atof(argv[3]);
		INR_dB = atof(argv[4]);
		alpha = atof(argv[5]);
		target_BLER = atof(argv[6]);
		num_ch = atoi(argv[7]);
		num_block = atoi(argv[8]);
		seed = atoi(argv[9]);
	}
	else
	{
		printf("Incorrect input arguments. Check again.\n");
		printf("[Usage] ./ian_fading_turbo [n] [R_iter] [SNR(dB)] [INR(dB)] [alpha] [target BLER] [# of channel instances] [# of blocks] [seed]\n");
		printf("***********************************************************************************************\n");
		printf("Y1 = g11*X1 + g12*X2 + Z1\n");
		printf("Y2 = g21*X1 + g21*X2 + Z2\n");
		printf("Here, X1 is 4-PAM and X2 is BPSK signals with average power P1 and P2, and Zi~N(0,1).\n");
		printf("g_{ij} are Gaussian r.v.'s.\n");
		printf("X1 = sqrt(P1)*sqrt(alpha)*U + sqrt(P1)*sqrt(1-alpha)*V\n");
		printf("***********************************************************************************************\n");
		printf("n:\tblock size -> n bits consist of one block for all tx/rx pairs\n");
		printf("R_iter, target BLER:\tTo calculate the maximum rate R to satisfy target BLER, perform binary search R_iter times\n");
		printf("SNR(dB), INR(dB):\tDetermines the variances of g_{ij}\n");
		printf("seed:\tinteger greater than 0\n");
		exit(0);
	}


	// initialize
	n1 = 2 * n;
	n2 = n;

	P1 = 1.0; P2 = 1.0;
	sigma2=1.0;

	Punctured_Turbo_Codec_rev code1;
	Punctured_Turbo_Codec_rev code2;
	AWGN_Channel channel;
	channel.set_noise(sigma2);
	BPSK bpsk;
	BERC berc1, berc2;		// for calculation of bit errors

	cwdU.set_size(n);
	cwdV.set_size(n);
	LLR1.set_size(n1);

	// generate random interleavers
	RNG_reset(1);	// random generator with a fixed seed
	interleaver1 = sort_index(randu(n1));
	interleaver2 = sort_index(randu(n2));
	deinterleaver1 = sort_index(interleaver1);
	deinterleaver2 = sort_index(interleaver2);
	RNG_reset(seed);	// random generator with a given seed by console

	R_avg = 0; R_SWSC_avg=0; R_SND_avg = 0; R_SD_avg = 0; R_IAN_avg = 0;
	for (ch=0; ch<num_ch; ch++)
	{
		R_IAN=0.0;
		while (((double)(R_IAN) * (double)(n) / 4.5) <  MIN_INTERLEAVER_SIZE)		// select channel so that the channel can be overcome by the minimum-rate LTE turbo codes. 4.5 means a margin
		{
			// generate g_{ij}
			g11 = sqrt(pow(10.0,SNR_dB/10.0) / P1 / 2.0 * (sqr(randn()) + sqr(randn())));
			g12 = sqrt(pow(10.0,INR_dB/10.0) / P2 / 2.0 * (sqr(randn()) + sqr(randn())));
			g21 = sqrt(pow(10.0,INR_dB/10.0) / P1 / 2.0 * (sqr(randn()) + sqr(randn())));
			g22 = sqrt(pow(10.0,SNR_dB/10.0) / P2 / 2.0 * (sqr(randn()) + sqr(randn())));
			
			//g11 = sqrt(pow(10.0,SNR_dB/10.0)) / sqrt(P1) * randn();
			//g12 = sqrt(pow(10.0,INR_dB/10.0)) / sqrt(P2) * randn();
			//g21 = sqrt(pow(10.0,INR_dB/10.0)) / sqrt(P1) * randn();
			//g22 = sqrt(pow(10.0,SNR_dB/10.0)) / sqrt(P2) * randn();

			// calculate the maximum achievable rate
			calc_max_sym_rate_4PAM_2PAM(alpha, P1, P2, g11, g12, g21, g22, &R_SWSC, &R_SND, &R_SD, &R_IAN);
		}
		R_SWSC_avg += R_SWSC;
		R_SND_avg+= R_SND;
		R_SD_avg += R_SD;
		R_IAN_avg += R_IAN;

		//cout << g11 << "\t" << g12 << "\t" << g21 << "\t" << g22 << "\t" << R_SWSC << "\t" << R_SND << "\t" << R_SD << "\t" << R_IAN << endl;


		// find a achievable rate as large as possible to guarantee target BLER like 10^{-1} by binary search on R
		R_lower = 0; R_upper = min(R_IAN*1.5,1.0);					// 1.2 means margin
		for (R_cnt=0; R_cnt<R_iter; R_cnt++)
		{
			R = (R_upper + R_lower) / 2.0;

			// k1 search considering rate loss from null messages
			k1 = lte_search_k(n1, R * (double)(n) / (double)(n1));
			actualR1 = (double)(k1) / (double)(n);

			// k2 search
			k2 = lte_search_k(n2, R * (double)(n) / (double)(n2));
			actualR2 = (double)(k2) / (double)(n);

			code1.lte_set_parameters(k1, n1, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
			code2.lte_set_parameters(k2, n2, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);


			berr1 = 0; berr2 = 0;
			blerr1 = 0; blerr2 = 0;
			for (block=0; block<num_block; block++)
			{

				// tx1
				msg1 = randb(k1);
				code1.lte_turbo_rate_matching_encode(msg1, cwd1);	// LTE turbo encoding with rate-matching
				cwd1 = cwd1(interleaver1);				// random interleaving
				for (i=0; i<n; i++)
				{
					cwdU(i) = cwd1(2*i);
					cwdV(i) = cwd1(2*i+1);
				}
				tx1 = sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(cwdU) + sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(cwdV);

				// tx2
				msg2 = randb(k2);
				code2.lte_turbo_rate_matching_encode(msg2, cwd2);	// LTE turbo encoding with rate-matching
				cwd2 = cwd2(interleaver2);
				tx2 = sqrt(P2)*bpsk.modulate_bits(cwd2);

				// channel
				rx1 = channel(g11*tx1 + g12*tx2);
				rx2 = channel(g21*tx1 + g22*tx2);

				// rx1
				LLRU = ian_calc_LLR(rx1,sqrt(alpha)*sqrt(P1)*g11,sqrt(1.0-alpha)*sqrt(P1)*g11,sqrt(P2)*g12,sigma2);
				LLRV = ian_calc_LLR(rx1,sqrt(1.0-alpha)*sqrt(P1)*g11,sqrt(alpha)*sqrt(P1)*g11,sqrt(P2)*g12,sigma2);
				for (i=0; i<n; i++)
				{
					LLR1(2*i) = LLRU(i);
					LLR1(2*i+1) = LLRV(i);
				}
				LLR1 = LLR1(deinterleaver1);
				code1.lte_turbo_rate_matching_decode_LLR(LLR1, dec1, iter_dec1, msg1);	// turbo decoding for msg

				// bit error count for msg1
				berc1.clear();
				berc1.count(msg1, dec1);
				berr1 += berc1.get_errors();

				// block error count
				if (int(berc1.get_errors()) != 0)
				{
					blerr1++;  
				}


				// rx2
				LLR2 = ian_calc_LLR(rx2,sqrt(P2)*g22,sqrt(alpha)*sqrt(P1)*g21,sqrt(1.0-alpha)*sqrt(P1)*g21,sigma2);
				LLR2 = LLR2(deinterleaver2);
				code2.lte_turbo_rate_matching_decode_LLR(LLR2, dec2, iter_dec2, msg2);	// turbo decoding for msg

				// bit error count for msg2
				berc2.clear();
				berc2.count(msg2, dec2);
				berr2 += berc2.get_errors();

				// block error count
				if (int(berc2.get_errors()) != 0)
				{
					blerr2++;  
				}

			}


			// calculate BER, BLER, FER
			BER1 = (double)berr1 / (double)(num_block*k1);
			BER2 = (double)berr2 / (double)(num_block*k2);

			BLER1 = (double)blerr1 / (double)(num_block);
			BLER2 = (double)blerr2 / (double)(num_block);


			// adjust R to achieve BLER around the target for the next iteration
			if ((BLER1 < target_BLER) && (BLER2 < target_BLER))
			{
				R_lower = R;	
			}
			else
			{
				R_upper = R;
			}
		}

		R_avg += R;

		cout << "channel\t" << ch << "\tg11\t" << g11 << "\tg12\t" << g12 << "\tg21\t" << g21 << "\tg22\t" << g22 << "\tR\t" << R << "\tR_SWSC\t" << R_SWSC << "\tR_SND\t" << R_SND << "\tR_SD\t" << R_SD << "\tR_IAN\t" << R_IAN << "\tactual_R1\t" << actualR1 << "\tactual_R2\t" << actualR2 << "\tBLER1\t" << BLER1 << "\t" << "\tBLER2\t" << BLER2 << "\tBER1\t" << BER1 << "\tBER2\t" << BER2 << endl;
	
	}

	R_SWSC_avg /= (double)num_ch;
	R_SND_avg /= (double)num_ch;
	R_SD_avg /= (double)num_ch;
	R_IAN_avg /= (double)num_ch;
	R_avg /= (double)num_ch;

	cout << "R_avg\t" << R_avg << "\tR_SWSC_avg\t" << R_SWSC_avg << "\tR_SND_avg\t" << R_SND_avg << "\tR_SD_avg\t" << R_SD_avg << "\tR_IAN_avg\t" << R_IAN_avg << "\tn\t" << n << "\tR_iter\t" << R_iter << "\tSNR_dB\t" << SNR_dB << "\tINR_dB\t" << INR_dB << "\talpha\t" << alpha << "\ttarget_BLER\t" << target_BLER << "\tnum_ch\t" << num_ch << "\tnum_block\t" << num_block << "\tseed\t" << seed << endl;

	return 0;

}

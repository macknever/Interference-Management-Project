#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int SNR, INR, seed, walltime;
	char filename[255];
	FILE *fp;

	SNR=10;
	walltime = 8;

	for (INR=8; INR<=12; INR++)
	{
		for (seed=1; seed<=40; seed++)
		{
			sprintf(filename, "s%d_%d.qsub",INR,seed);
			fp = fopen(filename,"w");

			fprintf(fp, "#!/bin/csh\n");
			fprintf(fp, "#PBS -l nodes=1:ppn=1\n");
			fprintf(fp, "#PBS -l walltime=%d:00:00\n",walltime);
			fprintf(fp, "#PBS -o result_%d_%d_%d.out\n",SNR,INR,seed);
			fprintf(fp, "#PBS -M hpark1@ucsd.edu\n");			
			fprintf(fp, "#PBS -m ae\n");			
			fprintf(fp, "#PBS -A yhk\n");			
			fprintf(fp, "cd /oasis/tscc/scratch/hpark1\n");			
			fprintf(fp, "mpirun -machinefile $PBS_NODEFILE -np 1 $PBS_O_WORKDIR/exe_swsc_sum_hard 2048 20 7 %d %d 0.8 0.1 10 200 %d\n", SNR, INR, seed);			

			fclose(fp);

		}
	}


	sprintf(filename, "batch_qsub");
	fp = fopen(filename,"w");

	for (INR=8; INR<=12; INR++)
	{
		for (seed=1; seed<=40; seed++)
		{
			fprintf(fp, "qsub s%d_%d.qsub\n", INR, seed);
		}
	}

	fclose(fp);

	return 0;
}



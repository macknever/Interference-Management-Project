#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	int SNR, INR, seed, walltime;
	char filename[255];
	FILE *fp;

	sprintf(filename, "batch_qdel");
	fp = fopen(filename,"w");

	for (INR=2197935; INR<=2198034; INR++)
	{
			fprintf(fp, "qdel %d.tscc-mgr.local\n", INR);
	}

	fclose(fp);

	return 0;
}



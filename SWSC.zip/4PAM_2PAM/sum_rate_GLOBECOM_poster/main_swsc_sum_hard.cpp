#include "itpp/itcomm.h"
#include "nit_coding.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;

/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/


int main(int argc, char *argv[])
{

	int i, j;	// for loop
	int frame, num_frame;	// current frame number and target number of simulated blocks
	int ch, num_ch;
	int seed;

	int ferr11, ferr12, ferr21, ferr22;	// current number of frame errors
	int blerr11, blerr12, blerr21, blerr22;
	int tot_blerr11, tot_blerr12, tot_blerr21, tot_blerr22;
	int berr11, berr12, berr21, berr22;		// number of bit errors
	
	double FER11, FER12, FER21, FER22;
	double BLER11, BLER12, BLER21, BLER22;
	double BER11, BER12, BER21, BER22;
	double target_BLER;

	bvec msg1, msg2;
	bvec msg1_curr, msg2_curr;		// binary message vector of length k
	bvec cwd1_prev, cwd1_curr, cwd2_prev, cwd2_curr;		// codeword
	vec tx1, tx2;											// transmitted modulated signals
	vec rx1, rx2;
	bvec dec11, dec12, dec21, dec22;						// decoded vector
	ivec iter_dec11, iter_dec12, iter_dec21, iter_dec22;	// ?? 


	// code parameters
	int k1, k2;		// message length per codeword
	int n, n1, n2;
	double R1, R1_lower, R1_upper, R1_avg, R1_max;
	double R2, R2_lower, R2_upper, R2_avg, R2_max;
	double R_sum_SND, R_sum_SD, R_sum_IAN;
	double R1_SWSC_avg, R2_SWSC_avg;
	double R_sum_SND_avg, R_sum_SD_avg, R_sum_IAN_avg;
	int R_iter, R_cnt;
	double actualR1, actualR2;
	int b;		// frame size
	int max_iter = 8;
	string dec_metric = "LOGMAP";
	double logmax_scale = 1.0;		// default (not to use)
	bool adaptive_stop = false;
	LLR_calc_unit lcalc;			// default LLR calculation

	const int MAX_INTERLEAVER_SIZE = 6144;
	const int MIN_INTERLEAVER_SIZE = 40;

	// power and channel parameters
	double SNR_dB;		// signal to noise power ratio (dB). calculate N0 from this.
	double INR_dB;		// interference to noise power ratio (dB). calculate g from these.i
	double g11, g12, g21, g22;
	double sigma2;
	double alpha;		// power allocation for U and V in enc1
	double P1, P2;

	ivec interleaver1, deinterleaver1;
	ivec interleaver2, deinterleaver2;


	// intput parameters from console
	if (argc == 11)
	{
		n = atoi(argv[1]);
		b = atoi(argv[2]);
		R_iter = atoi(argv[3]);
		SNR_dB = atof(argv[4]);
		INR_dB = atof(argv[5]);
		alpha = atof(argv[6]);
		target_BLER = atof(argv[7]);
		num_ch = atoi(argv[8]);
		num_frame = atoi(argv[9]);
		seed = atoi(argv[10]);
	}
	else
	{
		printf("Incorrect input arguments. Check again.\n");
		printf("[Usage] ./swsc_fading_turbo [n] [b] [R_iter] [SNR(dB)] [INR(dB)] [alpha] [target BLER] [# of channel instances] [# of frames] [seed]\n");
		printf("***********************************************************************************************\n");
		printf("Y1 = g11*X1 + g12*X2 + Z1\n");
		printf("Y2 = g21*X1 + g21*X2 + Z2\n");
		printf("Here, X1 is 4-PAM and X2 is BPSK signals with average power P1 and P2, and Zi~N(0,1).\n");
		printf("g_{ij} are Gaussian r.v.'s.\n");
		printf("X1 = sqrt(P1)*sqrt(alpha)*U + sqrt(P1)*sqrt(1-alpha)*V\n");
		printf("***********************************************************************************************\n");
		printf("n:\tblock size -> n bits consist of one block for all tx/rx pairs\n");
		printf("b:\tframe size -> b blocks consist of one frame\n");
		printf("R_iter, target BLER:\tTo calculate the maximum rate R to satisfy target BLER, perform binary search R_iter times\n");
		printf("SNR(dB), INR(dB):\tDetermines the variances of g_{ij}\n");
		printf("seed:\tinteger greater than 0\n");
		exit(0);
	}


	// initialize
	n1 = 2 * n;
	n2 = n;

	P1 = 1.0; P2 = 1.0;
	sigma2=1.0;

	Punctured_Turbo_Codec_rev code1;
	Punctured_Turbo_Codec_rev code2;
	AWGN_Channel channel;
	channel.set_noise(sigma2);
	BPSK bpsk;
	BERC berc11, berc12, berc21, berc22;		// for calculation of bit errors


	// generate random interleavers
	RNG_reset(1);	// random generator with a fixed seed
	interleaver1 = sort_index(randu(n1));
	interleaver2 = sort_index(randu(n2));
	deinterleaver1 = sort_index(interleaver1);
	deinterleaver2 = sort_index(interleaver2);
	RNG_reset(seed);	// random generator with a given seed by console

	R1_avg = 0; R1_SWSC_avg=0; 
	R2_avg = 0; R2_SWSC_avg=0;
	R_sum_SND_avg = 0; R_sum_SD_avg = 0; R_sum_IAN_avg = 0;
	for (ch=0; ch<num_ch; ch++)
	{
		R1_max = 0.0; R2_max = 0.0;
		while ((((double)(R1_max) * (double)(n) / 4.5) <  MIN_INTERLEAVER_SIZE) || (((double)(R2_max) * (double)(n) / 4.5) <  MIN_INTERLEAVER_SIZE))		// select channel so that the channel can be overcome by the minimum-rate LTE turbo codes. 4.5 means a margin
		{
			// generate g_{ij}
			g11 = sqrt(pow(10.0,SNR_dB/10.0) / P1 / 2.0 * (sqr(randn()) + sqr(randn())));
			g12 = sqrt(pow(10.0,INR_dB/10.0) / P2 / 2.0 * (sqr(randn()) + sqr(randn())));
			g21 = sqrt(pow(10.0,INR_dB/10.0) / P1 / 2.0 * (sqr(randn()) + sqr(randn())));
			g22 = sqrt(pow(10.0,SNR_dB/10.0) / P2 / 2.0 * (sqr(randn()) + sqr(randn())));
			
			//g11 = sqrt(pow(10.0,SNR_dB/10.0)) / sqrt(P1) * randn();
			//g12 = sqrt(pow(10.0,INR_dB/10.0)) / sqrt(P2) * randn();
			//g21 = sqrt(pow(10.0,INR_dB/10.0)) / sqrt(P1) * randn();
			//g22 = sqrt(pow(10.0,SNR_dB/10.0)) / sqrt(P2) * randn();

			// calculate the maximum achievable rate
			calc_max_sum_rate_4PAM_2PAM(alpha, P1, P2, g11, g12, g21, g22, &R1_max, &R2_max, &R_sum_SND, &R_sum_SD, &R_sum_IAN);
		}
		R1_SWSC_avg += R1_max;
		R2_SWSC_avg += R2_max;
		
		R_sum_SND_avg+= R_sum_SND;
		R_sum_SD_avg += R_sum_SD;
		R_sum_IAN_avg += R_sum_IAN;

		//cout << g11 << "\t" << g12 << "\t" << g21 << "\t" << g22 << "\t" << R_max << "\t" << R_SND << "\t" << R_SD << "\t" << R_IAN << endl;


		// find a achievable rate as large as possible to guarantee target BLER like 10^{-1} by binary search on R
		R1_lower = 0; R1_upper = 1.5*R1_max;					// 1.2 means margin
		R2_lower = 0; R2_upper = 1.5*R2_max;					// 1.2 means margin
		for (R_cnt=0; R_cnt<R_iter; R_cnt++)
		{
			R1 = (R1_upper + R1_lower) / 2.0;
			R2 = (R2_upper + R2_lower) / 2.0;

			// k1 search considering rate loss from null messages
			k1 = lte_search_k(n1, R1 * (double)(n) / (double)(n1) * (double)(b) / (double)(b-1));
			actualR1 = (double)(k1) / (double)(n) * (double)(b-1) / (double)(b);

			// k2 search
			k2 = lte_search_k(n2, R2 * (double)(n) / (double)(n2));
			actualR2 = (double)(k2) / (double)(n);

			code1.lte_set_parameters(k1, n1, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);
			code2.lte_set_parameters(k2, n2, max_iter, dec_metric, logmax_scale, adaptive_stop, lcalc);

			//cout << k1 << "\t" << n1 << endl;
			//cout << k2 << "\t" << n2 << endl;


			msg1.set_size((b+1)*k1); msg1.zeros();
			msg2.set_size(b*k2); msg2.zeros();

			dec11.set_size((b+1)*k1); dec11.zeros();
			dec12.set_size(b*k2); dec12.zeros();
			dec21.set_size((b+1)*k1); dec21.zeros();
			dec22.set_size(b*k2); dec22.zeros();

			rx1.set_size(b*n); rx1.zeros();
			rx2.set_size(b*n); rx2.zeros();

			berr11 = 0; berr12 = 0; berr21 = 0; berr22 = 0;
			ferr11 = 0; ferr12 = 0; ferr21 = 0; ferr22 = 0;
			tot_blerr11 = 0; tot_blerr12 = 0; tot_blerr21 = 0; tot_blerr22 = 0;
			for (frame=0; frame<num_frame; frame++)
			{
				//cout << frame << endl;
				
				// initialization at time 0
				msg1_curr = randb(k1);
				msg1.set_subvector(0*k1, msg1_curr);
				code1.lte_turbo_rate_matching_encode(msg1_curr, cwd1_curr);
				cwd1_curr = cwd1_curr(interleaver1);

				// encoding, transmitting, and channel for one frame
				for (i=0; i<b; i++)
				{
					cwd1_prev = cwd1_curr;

					// encoder 1
					msg1_curr = randb(k1);							// random message generation
					msg1.set_subvector((i+1)*k1,msg1_curr);
					code1.lte_turbo_rate_matching_encode(msg1_curr, cwd1_curr);		// rate-matching encoding
					cwd1_curr = cwd1_curr(interleaver1);
					tx1 = sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(cwd1_prev.right(n)) + sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(cwd1_curr.left(n));

					// encoder 2
					msg2_curr = randb(k2);											// random message generation
					msg2.set_subvector(i*k2,msg2_curr);
					code2.lte_turbo_rate_matching_encode(msg2_curr, cwd2_curr);		// rate-matching encoding
					cwd2_curr = cwd2_curr(interleaver2);
					tx2 = sqrt(P2)*bpsk.modulate_bits(cwd2_curr);

					// channel
					rx1.set_subvector(i*n,channel(g11*tx1 + g12*tx2));
					rx2.set_subvector(i*n,channel(g21*tx1 + g22*tx2));
				}

//				cout << rx1 << endl;
//				cout << rx2 << endl;

				// decoding
				swsc_decoding_4PAM_2PAM_rx1_hard(rx1,msg1,msg2,code1,code2,interleaver1,deinterleaver1,interleaver2,deinterleaver2,bpsk,n,k1,k2,b,alpha,P1,P2,g11,g12,sigma2,dec11,dec12);
				swsc_decoding_4PAM_2PAM_rx2_hard(rx2,msg1,msg2,code1,code2,interleaver1,deinterleaver1,interleaver2,deinterleaver2,bpsk,n,k1,k2,b,alpha,P1,P2,g21,g22,sigma2,dec21,dec22);


				// bit, block, and frame error count
				blerr11 = 0; blerr12 = 0; blerr21 = 0; blerr22 = 0;
				for (i=0; i<b; i++)
				{
					// bit error count
					berc11.clear();
					berc11.count(msg1.mid(i*k1,k1), dec11.mid(i*k1,k1));
					if (int(berc11.get_errors()) > 0)
					{
						berr11 += berc11.get_errors();
						blerr11++;
					}
					//cout << msg1.mid(i*k1,k1) << endl;
					//cout << dec11.mid(i*k1,k1) << endl;
					//cout << berc11.get_errors() << endl;

					berc12.clear();
					berc12.count(msg2.mid(i*k2,k2), dec12.mid(i*k2,k2));
					if (int(berc12.get_errors()) > 0)
					{
						berr12 += berc12.get_errors();
						blerr12++;
					}

					//					cout << msg2.mid(i*k2,k2) << endl;
					//					cout << dec12.mid(i*k2,k2) << endl;
					//					cout << berc12.get_errors() << endl;

					berc21.clear();
					berc21.count(msg1.mid(i*k1,k1), dec21.mid(i*k1,k1));
					if (int(berc21.get_errors()) > 0)
					{
						berr21 += berc21.get_errors();
						blerr21++;
					}
					//					cout << msg1.mid(i*k1,k1) << endl;
					//					cout << dec21.mid(i*k1,k1) << endl;
					//					cout << berc21.get_errors() << endl;

					berc22.clear();
					berc22.count(msg2.mid(i*k2,k2), dec22.mid(i*k2,k2));
					if (int(berc22.get_errors()) > 0)
					{
						berr22 += berc22.get_errors();
						blerr22++;
					}
					//					cout << msg2.mid(i*k2,k2) << endl;
					//					cout << dec22.mid(i*k2,k2) << endl;
					//					cout << berc22.get_errors() << endl;

				}

				if (blerr11 > 0) { ferr11++; tot_blerr11 += blerr11; }
				if (blerr12 > 0) { ferr12++; tot_blerr12 += blerr12; }
				if (blerr21 > 0) { ferr21++; tot_blerr21 += blerr21; }
				if (blerr22 > 0) { ferr22++; tot_blerr22 += blerr22; }

			}

			// calculate BER, BLER, FER
			BER11 = (double)berr11 / (double)(num_frame*(b-1)*k1);
			BER21 = (double)berr21 / (double)(num_frame*(b-1)*k1);

			BLER11 = (double)tot_blerr11 / (double)(num_frame*(b-1));
			BLER21 = (double)tot_blerr21 / (double)(num_frame*(b-1));

			BER12 = (double)berr12 / (double)(num_frame*b*k2);
			BER22 = (double)berr22 / (double)(num_frame*b*k2);

			BLER12 = (double)tot_blerr12 / (double)(num_frame*b);
			BLER22 = (double)tot_blerr22 / (double)(num_frame*b);


			FER11 = (double)ferr11 / (double)num_frame;
			FER12 = (double)ferr12 / (double)num_frame;
			FER21 = (double)ferr21 / (double)num_frame;
			FER22 = (double)ferr22 / (double)num_frame;

			//cout << BLER11 << "\t" << BLER12 << "\t" << BLER21 << "\t" << BLER22 << endl;
			//cout << BER11 << "\t" << BER12 << "\t" << BER21 << "\t" << BER22 << endl;

			// adjust R to achieve BLER around the target for the next iteration
			if ((BLER11 < target_BLER) && (BLER22 < target_BLER))
			{
				R1_lower = R1;	
				R2_lower = R2;	
			}
			else
			{
				R1_upper = R1;
				R2_upper = R2;
			}
		}

		R1_avg += R1;
		R2_avg += R2;

		cout << "channel\t" << ch << "\tg11\t" << g11 << "\tg12\t" << g12 << "\tg21\t" << g21 << "\tg22\t" << g22 << "\tR_sum_max\t" << R1_max + R2_max << "\tR1_max\t" << R1_max << "\tR2_max\t" << R2_max << "\tR_sum\t" << R1 + R2 << "\tR1\t" << R1 << "\tR2\t" << R2 << "\tR_sum_SND\t" << R_sum_SND  << "\tR_sum_SD\t" << R_sum_SD << "\tR_sum_IAN\t" << R_sum_IAN << "\tactual_R1\t" << actualR1 << "\tactual_R2\t" << actualR2 << "\tBLER11\t" << BLER11 << "\t" << "\tBLER12\t" << BLER12 << "\tBLER21\t" << BLER21 << "\tBLER22\t" << BLER22 << "\tBER11\t" << BER11 << "\tBER12\t" << BER12 << "\tBER21\t" << BER21 << "\tBER22\t" << BER22 << "\tFER11\t" << FER11 << "\tFER12\t" << FER12 << "\tFER21\t" << FER21 << "\tFER22\t" << FER22 << endl;
	
	}

	R1_SWSC_avg /= (double)num_ch;
	R2_SWSC_avg /= (double)num_ch;
	R1_avg /= (double)num_ch;
	R2_avg /= (double)num_ch;
	
	R_sum_SND_avg /= (double)num_ch;
	R_sum_SD_avg /= (double)num_ch;
	R_sum_IAN_avg /= (double)num_ch;

	cout << "R_sum_SWSC_avg\t" << R1_SWSC_avg + R2_SWSC_avg <<  "\tR1_SWSC_avg\t" << R1_SWSC_avg << "\tR2_SWSC_avg\t" << R2_SWSC_avg << "\tR_sum_avg\t" << R1_avg + R2_avg << "\tR1_avg\t" << R1_avg << "\tR2_avg\t" << R2_avg << "\tR_sum_SND_avg\t" << R_sum_SND_avg << "\tR_sum_SD_avg\t" << R_sum_SD_avg << "\tR_sum_IAN_avg\t" << R_sum_IAN_avg << "\tn\t" << n << "\tb\t" << b << "\tR_iter\t" << R_iter << "\tSNR_dB\t" << SNR_dB << "\tINR_dB\t" << INR_dB << "\talpha\t" << alpha << "\ttarget_BLER\t" << target_BLER << "\tnum_ch\t" << num_ch << "\tnum_frame\t" << num_frame << "\tseed\t" << seed << endl;

	return 0;

}

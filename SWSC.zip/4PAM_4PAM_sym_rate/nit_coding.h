#include "itpp/itcomm.h"
#include "turbo_rev.h"

using namespace itpp;
using std::cout;
using std::endl;
using std::string;


/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/

const double LLR_max = 200.0;


int lte_search_k(const int n, const double R);

double pdf_gaussian(const double y, const double mean, const double sigma2);

vec pdf_gaussian(const vec y, const double mean, const double sigma2);

//vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_single(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2);

//vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_single_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2);

//vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2);
vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2);

//vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2);
vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2);

//vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2);
//vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2);
vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2);

//vec sw_calc_LLR_22(const vec &rx_prev, const double sigma2);
//vec sw_calc_LLR_22(const vec &rx_prev, const double P, const double g21, const double g22, const double sigma2);
vec sw_calc_LLR_22(const vec &rx_prev, const double P2, const double g22, const double sigma2);

vec sc_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_12(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_2U(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_2V(const vec &rx, const double alpha, const double g, const double sigma2);

vec sc_calc_LLR_22(const vec &rx, const double alpha, const double g, const double sigma2);

vec ian_calc_LLR_1(const vec &rx, const double alpha, const double g, const double sigma2);

vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2);
vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2);

vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2);
vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2);

vec ian_calc_LLR_2(const vec &rx, const double alpha, const double g, const double sigma2);
vec ian_calc_LLR_2(const vec &rx, const double alpha, const double P, const double g21, const double g22, const double sigma2);

vec ian_calc_LLR_4PAM_2PAM(const vec &rx,const double mag_target, const double mag_other1,const double mag_other2,const double sigma2);

vec ian_a_calc_LLR_4PAM_4PAM(const vec &rx, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec ian_b_calc_LLR_4PAM_4PAM(const vec &rx, double g, vec &constellation, ivec &map, double sigma2, double interference_power);

vec mlc_calc_LLR_single(const vec &rx, const double alpha, const double P, const double sigma2);

void sd_joint_decode(Punctured_Turbo_Codec_rev codeU, Punctured_Turbo_Codec_rev codeV, Punctured_Turbo_Codec_rev code2, Sequence_Interleaver<double> itlvU, Sequence_Interleaver<double> itlvV, Sequence_Interleaver<double> itlv2, const vec &rx, bvec &decU, bvec &decV, bvec &dec2, const bvec &msgU, const bvec &msgV, const bvec &msg2, const double alpha, const double beta, const double gamma, const double sigma2);


double min(double a, double b);
double max(double a, double b);
double sel_max(const vec &a, int *b);
vec PAM_signal(int k, double P0);
vec constellation_sum(const vec X1, const vec X2);
double gaussian(double x, int index);
double etrpy(const double x);
void calc_interval();

bvec shuffle_stream(bvec stream1, bvec stream2, int size);


ivec set_map(int type);
void set_type_dec_sym_4PAM_4PAM(const ivec &map1, const ivec &map2, const double P1, const double P2, const double g11, const double g12, const double g21, const double g22, int *type_dec1, int *type_dec2, double *R_max, double *R_SND, double *R_SD, double *R_IAN_a, double *R_IAN_b);
void set_type_dec_sum_4PAM_4PAM(const ivec &map1, const ivec &map2, const double P1, const double P2, const double g11, const double g12, const double g21, const double g22, int *type_dec1, int *type_dec2, double *R1_max, double *R2_max);
void set_num_null_msg_4PAM_4PAM(int type_dec1, int type_dec2, int *num_null_msg1, int *num_null_msg2);

void calc_max_sym_rate_4PAM_2PAM(double alpha, double P1, double P2, double g11, double g12, double g21, double g22, double *R_max, double *R_SND, double *R_SD, double *R_IAN);

void calc_max_sum_rate_4PAM_2PAM(double alpha, double P1, double P2, double g11, double g12, double g21, double g22, double *R1_max, double *R2_max, double *R_sum_SND, double *R_sum_SD, double *R_sum_IAN);
void calc_max_sum_rate_4PAM_2PAM_IAN(double alpha, double P1, double P2, double g11, double g12, double g21, double g22, double *R1_max, double *R2_max, double *R_sum_SND, double *R_sum_SD, double *R1_IAN, double *R2_IAN);

void swsc_decoding_4PAM_2PAM_rx1_soft(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);
void swsc_decoding_4PAM_2PAM_rx2_soft(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);



void swsc_decoding_4PAM_2PAM_rx1_hard(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,BPSK &bpsk,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);
void swsc_decoding_4PAM_2PAM_rx2_hard(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,BPSK &bpsk,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);


vec swsc_4PAM_2PAM_LLR(const vec &rx,const double mag_target, const vec &LLR_other1,const double mag_other1,const vec &LLR_other2,const double mag_other2,const double sigma2);

vec swsc_4PAM_2PAM_LLR_hard(const bvec &cwd);


void swsc_decoding_4PAM_4PAM_hard_block(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,vec &constellation1,vec &constellation2,ivec &map1,ivec &map2,int n,int k1, int k2,int b,int type_dec,int num_null_msg1,int num_null_msg2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);
void swsc_decoding_4PAM_4PAM_hard_bit(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,vec &constellation1,vec &constellation2,ivec &map1,ivec &map2,int n,int k1, int k2,int b,int type_dec,int num_null_msg1,int num_null_msg2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);
void swsc_decoding_4PAM_4PAM_soft(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,vec &constellation1,vec &constellation2,ivec &map1,ivec &map2,int n,int k1, int k2,int b,int type_dec,int num_null_msg1,int num_null_msg2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2);


vec swsc_calc_LLR_U(vec rx, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_U_U(vec rx, bvec cwd_U_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_U_V(vec rx, bvec cwd_V, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_U_UV(vec rx, bvec cwd_U_other, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_U_VV(vec rx, bvec cwd_V, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_U_VUV(vec rx, bvec cwd_V, bvec cwd_U_other, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_V_U(vec rx, bvec cwd_U, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_V_UU(vec rx, bvec cwd_U, bvec cwd_U_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);
vec swsc_calc_LLR_V_UUV(vec rx, bvec cwd_U, bvec cwd_U_other, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other);


#include "nit_coding.h"



/*************************************************/
/* rx1 = tx1 + g*tx2 + z1 */
/* rx2 = g*tx1 + tx2 + z2 */
/* tx1 = sqrt(alpha)*(last half of BPSK(prev_cwd1)) + sqrt(1-alpha)*(first half of BPSK(curr_cwd1)) */
/* tx2 = BPSK(cwd2) */
/*************************************************/



vec mu;
int mu_num;
vec interval_min, interval_max;
double multiple=5.0;
double sigma2=1.0;
double sigma=1.0;


int lte_search_k(const int n, const double R)
{

	int i, index;
	double k;
	int actual_k;

	ivec block_lengths("40 48 56 64 72 80 88 96 104 112 120 128 136 144 152 160 168 176 184 192 200 208 216 224 232 240 248 256 264 272 280 288 296 304 312 320 328 336 344 352 360 368 376 384 392 400 408 416 424 432 440 448 456 464 472 480 488 496 504 512 528 544 560 576 592 608 624 640 656 672 688 704 720 736 752 768 784 800 816 832 848 864 880 896 912 928 944 960 976 992 1008 1024 1056 1088 1120 1152 1184 1216 1248 1280 1312 1344 1376 1408 1440 1472 1504 1536 1568 1600 1632 1664 1696 1728 1760 1792 1824 1856 1888 1920 1952 1984 2016 2048 2112 2176 2240 2304 2368 2432 2496 2560 2624 2688 2752 2816 2880 2944 3008 3072 3136 3200 3264 3328 3392 3456 3520 3584 3648 3712 3776 3840 3904 3968 4032 4096 4160 4224 4288 4352 4416 4480 4544 4608 4672 4736 4800 4864 4928 4992 5056 5120 5184 5248 5312 5376 5440 5504 5568 5632 5696 5760 5824 5888 5952 6016 6080 6144");
	const int MAX_INTERLEAVER_SIZE = 6144;
	const int MIN_INTERLEAVER_SIZE = 40;


	k = (double)n * R;

	// Check the range of the interleaver size:
	it_assert(k <= MAX_INTERLEAVER_SIZE, "The current k is too large. Rate has to be rearranged!");
	it_assert(k >= MIN_INTERLEAVER_SIZE, "The current k is too small. Rate has to be rearranged!");

	// Search for the closest block length to k
	for (i=0; i< block_lengths.length()-1; i++)
	{
		if ((block_lengths(i) <= k) && (k < block_lengths(i+1)))
		{
			index = i;
		}
	}

	if ((k-(double)(block_lengths(index))) <= ((double)(block_lengths(index+1))-k))
	{
		actual_k = block_lengths(index);
	}
	else
	{
		actual_k = block_lengths(index+1);
	}

	return actual_k;
}



double pdf_gaussian(const double y, const double mean, const double sigma2)
{
	double result;

	result = 1.0 / sqrt(2.0*pi*sigma2) * exp(-1.0*sqr(y-mean) / (2.0*sigma2));

	return result;

}

vec pdf_gaussian(const vec y, const double mean, const double sigma2)
{
	vec result;

	result = 1.0 / sqrt(2.0*pi*sigma2) * exp(-1.0*sqr(y-mean) / (2.0*sigma2));

	return result;

}



/*
vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_11(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P1)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) + g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) - g11*sqrt(P1)*sqrt(1.0-alpha) - g12*sqrt(P2))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}



vec sw_calc_LLR_single(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(P)*sqrt(alpha) + sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(P)*sqrt(alpha) - sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(P)*sqrt(alpha) + sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(P)*sqrt(alpha) - sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}



/*
vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(sqrt(alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(sqrt(alpha) - g)) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(1.0-alpha)*y / sigma^2 and Lc = 2 / sigma^2

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P)*sqrt(alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P)*sqrt(alpha) - g12*sqrt(P))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_11_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * g11*sqrt(P1)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*g11*sqrt(P1)*sqrt(1.0-alpha)*y / sigma^2 

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g11*sqrt(P1)*sqrt(alpha) - g12*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) + g12*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g11*sqrt(P1)*sqrt(alpha) - g12*sqrt(P2))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}


vec sw_calc_LLR_single_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp = 2.0 * sqrt(P)*sqrt(1.0-alpha) * rx_prev / sigma2;	// HPARK: LLR = 2*sqrt(P)*sqrt(1.0-alpha)*y / sigma^2 
	rxc = 2.0 * sqrt(P)*sqrt(alpha) * rx_curr / sigma2;	// HPARK: LLR = 2*sqrt(P)*sqrt(alpha)*y / sigma^2 

	return concat(rxp, rxc);
}



/*
vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx;			

	// HPARK: calculating LLR
	rx.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g - sqrt(1.0-alpha))) / (2.0*sigma2)) )
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g - sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx;
}

vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx;			

	// HPARK: calculating LLR
	rx.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P) + g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P) - g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) )
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P) + g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P) - g11*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx;
}
*/

vec sw_calc_LLR_12(const vec &rx_curr, const double alpha, const double P1, const double P2, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx;			

	// HPARK: calculating LLR
	rx.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P2) + g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g12*sqrt(P2) - g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) )
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P2) + g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g12*sqrt(P2) - g11*sqrt(P1)*sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx;
}


/*
vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_21(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) + g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) - g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2))));
	}

	return concat(rxp, rxc);
}



/*
vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g*sqrt(alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g*sqrt(alpha) - 1.0)) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}

vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P)*sqrt(1.0-alpha) - g22*sqrt(P))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P)*sqrt(alpha) - g22*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) + g22*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P)*sqrt(alpha) - g22*sqrt(P))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}
*/

vec sw_calc_LLR_21_last(const vec &rx_prev, const vec &rx_curr, const double alpha, const double P1, const double P2, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp, rxc;			// HPARK: to store LLR values from rx_prev and rx_curr

	// HPARK: calculating LLR
	rxp.set_size(rx_prev.length());
	for (cnt=0; cnt< rx_prev.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxp(cnt) = log((exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)-(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_prev(cnt)+(g21*sqrt(P1)*sqrt(1.0-alpha) - g22*sqrt(P2))) / (2.0*sigma2))));
	}

	rxc.set_size(rx_curr.length());
	for (cnt=0; cnt< rx_curr.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rxc(cnt) = log((exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)-(g21*sqrt(P1)*sqrt(alpha) - g22*sqrt(P2))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) + g22*sqrt(P2))) / (2.0*sigma2)) + exp(-1.0*sqr(rx_curr(cnt)+(g21*sqrt(P1)*sqrt(alpha) - g22*sqrt(P2))) / (2.0*sigma2)) ));
	}

	return concat(rxp, rxc);
}

/*
vec sw_calc_LLR_22(const vec &rx_prev, const double sigma2)
{

	int cnt;
	vec rxp;			// HPARK: to store LLR values from rx_prev

	// HPARK: calculating LLR
	rxp = rx_prev * 2.0 / sigma2;

	return rxp;
}

vec sw_calc_LLR_22(const vec &rx_prev, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rxp;			// HPARK: to store LLR values from rx_prev

	// HPARK: calculating LLR
	rxp = rx_prev * g22 * sqrt(P) * 2.0 / sigma2;

	return rxp;
}
*/

vec sw_calc_LLR_22(const vec &rx_prev, const double P2, const double g22, const double sigma2)
{

	int cnt;
	vec rxp;			// HPARK: to store LLR values from rx_prev

	// HPARK: calculating LLR
	rxp = rx_prev * g22 * sqrt(P2) * 2.0 / sigma2;

	return rxp;
}




vec sc_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2))));
	}

	return rx_LLR;
}

vec sc_calc_LLR_12(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g - sqrt(1.0-alpha))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g + sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g - sqrt(1.0-alpha))) / (2.0*sigma2)) ));
	}

	return rx_LLR;
}

vec sc_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log( exp(-1.0*sqr(rx(cnt)-sqrt(1.0-alpha)) / (2.0*sigma2)) / exp(-1.0*sqr(rx(cnt)+sqrt(1.0-alpha)) / (2.0*sigma2)));
	}

	return rx_LLR;
}




vec sc_calc_LLR_2U(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) + g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(alpha) - g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	return rx_LLR;
}



vec sc_calc_LLR_2V(const vec &rx, const double alpha, const double g, const double sigma2)
{
	
	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g*sqrt(1.0-alpha) + 1.0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g*sqrt(1.0-alpha) - 1.0)) / (2.0*sigma2))));
	}

	return rx_LLR;


}

vec sc_calc_LLR_22(const vec &rx, const double alpha, const double g, const double sigma2)
{
	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log( exp(-1.0*sqr(rx(cnt)-1.0) / (2.0*sigma2)) / exp(-1.0*sqr(rx(cnt)+1.0) / (2.0*sigma2)));
	}

	return rx_LLR;

}






vec ian_calc_LLR_1(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;
	double tx1_11 = -3.0/sqrt(5);
	double tx1_10 = -1.0/sqrt(5);
	double tx1_00 = 1.0/sqrt(5);
	double tx1_01 = 3.0/sqrt(5);
	double tx2_1 = -1.0*g;
	double tx2_0 = g;

	rx_LLR.set_size(2*rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		// for the first bit of 4PAM symbol
		rx_LLR(2*cnt) = log((exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_1)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_1)) / (2.0*sigma2))));
		// for the second bit of 4PAM symbol
		rx_LLR(2*cnt+1) = log((exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_1)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_1)) / (2.0*sigma2))));
	}

	return rx_LLR;
}





vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) + sqrt(1.0-alpha) - g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha) - sqrt(1.0-alpha) - g)) / (2.0*sigma2))));
	}

	return rx_LLR;
}

vec ian_calc_LLR_1U(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) + g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(alpha) - g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2))));
	}

	return rx_LLR;
}




vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(1.0-alpha) - g)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(1.0-alpha) + g)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(1.0-alpha) - g)) / (2.0*sigma2)) ));
	}

	return rx_LLR;
}

vec ian_calc_LLR_1V(const vec &rx, const double alpha, const double P, const double g11, const double g12, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(1.0-alpha) + g12*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g11*sqrt(P)*sqrt(1.0-alpha) - g12*sqrt(P))) / (2.0*sigma2)) ));
	}

	return rx_LLR;
}







vec ian_calc_LLR_2(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;
	double tx1_11 = g*(-3.0)/sqrt(5);
	double tx1_10 = g*(-1.0)/sqrt(5);
	double tx1_00 = g*1.0/sqrt(5);
	double tx1_01 = g*3.0/sqrt(5);
	double tx2_1 = -1.0;
	double tx2_0 = 1.0;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_0)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_0)) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)-(tx1_11 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_10 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_00 + tx2_1)) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(tx1_01 + tx2_1)) / (2.0*sigma2))));
	}

	return rx_LLR;
}

/*
vec ian_calc_LLR_2(const vec &rx, const double alpha, const double g, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(1.0 + g*sqrt(alpha) + g*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(1.0 - g*sqrt(alpha) + g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(1.0 + g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(1.0 - g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(1.0 + g*sqrt(alpha) + g*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(1.0 - g*sqrt(alpha) + g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(1.0 + g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(1.0 - g*sqrt(alpha) - g*sqrt(1.0-alpha) )) / (2.0*sigma2))));
	}

	return rx_LLR;
}
*/



vec ian_calc_LLR_2(const vec &rx, const double alpha, const double P, const double g21, const double g22, const double sigma2)
{

	int cnt;
	vec rx_LLR;

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) + g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) + g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(g22*sqrt(P) - g21*sqrt(P)*sqrt(alpha) - g21*sqrt(P)*sqrt(1.0-alpha) )) / (2.0*sigma2))));
	}

	return rx_LLR;
}



vec ian_calc_LLR_4PAM_2PAM(const vec &rx,const double mag_target, const double mag_other1,const double mag_other2,const double sigma2)
{
	vec LLR_target;

	LLR_target = log( elem_div(pdf_gaussian(rx,mag_target+mag_other1+mag_other2,sigma2) + pdf_gaussian(rx,mag_target+mag_other1-mag_other2,sigma2) + pdf_gaussian(rx,mag_target-mag_other1+mag_other2,sigma2) + pdf_gaussian(rx,mag_target-mag_other1-mag_other2,sigma2),
			pdf_gaussian(rx,-mag_target+mag_other1+mag_other2,sigma2) + pdf_gaussian(rx,-mag_target+mag_other1-mag_other2,sigma2) + pdf_gaussian(rx,-mag_target-mag_other1+mag_other2,sigma2) + pdf_gaussian(rx,-mag_target-mag_other1-mag_other2,sigma2) ) );

	return LLR_target;
}



// LLR calculation for treating interference as noise with constellation information
vec ian_a_calc_LLR_4PAM_4PAM(const vec &rx, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(2*rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		///// LLR calculation for U /////
		pr0=0; pr1=0;

		// calc pr0 for U
		for (i=0; i<map.size()/2; i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}

		// calc pr1 for U
		for (i=map.size()/2; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}

		LLR(2*k) = log(pr0/pr1);

		///// LLR calculation for V /////
		pr0=0; pr1=0;

		// calc pr0 for V
		for (i=0; i<map.size(); i+=2)
		{
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}

		// calc pr1 for V
		for (i=1; i<map.size(); i+=2)
		{
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}

		LLR(2*k+1) = log(pr0/pr1);

	}

	return LLR;
}



// LLR calculation for treating interference as Gaussian noise
vec ian_b_calc_LLR_4PAM_4PAM(const vec &rx, double g, vec &constellation, ivec &map, double sigma2, double interference_power)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(2*rx.size());
	vec metric(map.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			metric(i) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)))/(2.0*(sigma2+interference_power)));
		}

		///// LLR calculation for U /////
		pr0=0; pr1=0;

		// calc pr0 for U
		for (i=0; i<map.size()/2; i++)
		{
			pr0 += metric(i);
		}

		// calc pr1 for U
		for (i=map.size()/2; i<map.size(); i++)
		{
			pr1 += metric(i);
		}

		LLR(2*k) = log(pr0/pr1);

		///// LLR calculation for V /////
		pr0=0; pr1=0;

		// calc pr0 for V
		for (i=0; i<map.size(); i+=2)
		{
			pr0 += metric(i);
		}

		// calc pr1 for V
		for (i=1; i<map.size(); i+=2)
		{
			pr1 += metric(i);
		}

		LLR(2*k+1) = log(pr0/pr1);

	}

	return LLR;
}






vec mlc_calc_LLR_single(const vec &rx, const double alpha, const double P, const double sigma2)
{

	int cnt;
	vec rx_LLR;	

	rx_LLR.set_size(rx.length());
	for (cnt=0; cnt< rx.length(); cnt++)		// HPARK: LLR = ln ()/()
	{
		rx_LLR(cnt) = log((exp(-1.0*sqr(rx(cnt)-(sqrt(alpha)*sqrt(P) + sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)-(sqrt(alpha)*sqrt(P) - sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2)))
				/ (exp(-1.0*sqr(rx(cnt)+(sqrt(alpha)*sqrt(P) + sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2)) + exp(-1.0*sqr(rx(cnt)+(sqrt(alpha)*sqrt(P) - sqrt(1.0-alpha)*sqrt(P))) / (2.0*sigma2))));
	}

	return rx_LLR;
}



// joint decoding for Y = alpha*U + beta*V + gamma*X2 + Z where U, V, and X2 are BPSK-modulated and Z~(0,sigma^2)

void sd_joint_decode(Punctured_Turbo_Codec_rev codeU, Punctured_Turbo_Codec_rev codeV, Punctured_Turbo_Codec_rev code2, Sequence_Interleaver<double> itlvU, Sequence_Interleaver<double> itlvV, Sequence_Interleaver<double> itlv2, const vec &rx, bvec &decU, bvec &decV, bvec &dec2, const bvec &msgU, const bvec &msgV, const bvec &msg2, const double alpha, const double beta, const double gamma, const double sigma2)
{
/*
	int i, j;
	int outer_iter=8;
	bool stop;

	vec rxU, rxU_itlv, inU, inU_itlv, outU, outU_itlv;
	vec rxV, rxV_itlv, inV, inU_itlv, outV, outV_itlv;
	vec rx2, rx2_itlv, in2, in2_itlv, out2, out2_itlv;
	ivec iter_decU, iter_decV, iter_dec2;

	// initially calculate LLR for U, V, X2 from rx
	rxU_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) + pdf_gaussian(rx,alpha-beta-gamma,sigma2)) /
			(pdf_gaussian(rx,-alpha+beta+gamma,sigma2) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
	rxV_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2)) /
			(pdf_gaussian(rx,alpha-beta+gamma,sigma2) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
	rx2_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2)) /
			(pdf_gaussian(rx,alpha+beta-gamma,sigma2) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );

	// deinterleaving for initial LLR of U, V, X2
	rxU = itlvU.deinterleave(rxU_itlv);
	rxV = itlvV.deinterleave(rxV_itlv);
	rx2 = itlv2.deinterleave(rx2_itlv);

	// initial extrinsic information to the first decoder is zero
	inU_itlv = zeros(rx.length()); inV_itlv = zeros(rx.length()); in2_itlv = zeros(rx.length());

	// outer iteration 8 times?
	stop = false;
	for (i=0; (i<outer_iter) && (!stop); i++)
	{
		// deinterleaving for inU, intV, and in2
		inU = itlvU.deinterleave(inU_itlv);
		inV = itlvV.deinterleave(inV_itlv);
		in2 = itlv2.deinterleave(in2_itlv);

		// SISO decoding of turbo codes
		codeU.lte_turbo_rate_matching_decode_SISO(rxU, inU, outU, decU, iter_decU);	// outU should be Le21 + Le12
		codeV.lte_turbo_rate_matching_decode_SISO(rxV, inV, outV, decV, iter_decV);
		code2.lte_turbo_rate_matching_decode_SISO(rx2, in2, out2, dec2, iter_dec2);

		// all decoded bits are correct, then STOP
		stop = true;
		for (j=0; j< msgU.length(); j++)
		{
			if (decU(j) != msgU(j))
			{
				stop = false;
			}
		}
		for (j=0; j< msgV.length(); j++)
		{
			if (decV(j) != msgV(j))
			{
				stop = false;
			}
		}
		for (j=0; j< msg2.length(); j++)
		{
			if (dec2(j) != msg2(j))
			{
				stop = false;
			}
		}

		if (!stop)
		{
			// interleaver for outU, outV and out2
			outU_itlv = itlvU.interleave(outU);
			outV_itlv = itlvV.interleave(outV);
			out2_itlv = itlv2.interleave(out2);

			// from outU, outV, out2, and rx, calculate inU, inV, in2 again
			inU_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) * exp(outV_itlv) * exp(out2_itlv) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,alpha-beta-gamma,sigma2)) /
					(pdf_gaussian(rx,-alpha+beta+gamma,sigma2) * exp(outV_itlv) * exp(out2_itlv) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
			inV_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) * exp(outU_itlv) * exp(out2_itlv) + pdf_gaussian(rx,alpha+beta-gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2)) /
					(pdf_gaussian(rx,alpha-beta+gamma,sigma2) * exp(outU_itlv) * exp(out2_itlv) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2) * exp(out2_itlv) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
			in2_itlv = log( (pdf_gaussian(rx,alpha+beta+gamma,sigma2) * exp(outU_itlv) * exp(outV_itlv) + pdf_gaussian(rx,alpha-beta+gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha+beta+gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,-alpha-beta+gamma,sigma2)) /
					(pdf_gaussian(rx,alpha+beta-gamma,sigma2) * exp(outU_itlv) * exp(outV_itlv) + pdf_gaussian(rx,alpha-beta-gamma,sigma2) * exp(outU_itlv) + pdf_gaussian(rx,-alpha+beta-gamma,sigma2) * exp(outV_itlv) + pdf_gaussian(rx,-alpha-beta-gamma,sigma2)) );
		}

	}
*/

}





// basic functions
double min(double a, double b)
{
	double temp;

	if (a>b)
	{
		temp = b;
	}
	else
	{
		temp = a;
	}

	return temp;
}


double max(double a, double b)
{
	double temp;

	if (a>b)
	{
		temp = a;
	}
	else
	{
		temp = b;
	}

	return temp;
}

double sel_max(const vec &a, int *b)
{
	double temp=0.0;
	int i;

	for (i=0; i<a.size(); i++)
	{
		if (a(i)>temp)
		{
			temp = a(i);
			*b = i;
		}
	}

	return temp;
}

// k-PAM with average power P0
vec PAM_signal(int k, double P0)
{
	int i;
	vec X(k);

	X(i) = -1.0*(double)(k)+1.0;
	for(i=1; i<k; i++)
	{
		X(i) = X(i-1) + 2.0;
	}
	
	X = X / sqrt(sum(sqr(X))/(double)(k))*sqrt(P0);

	return X;
}

// constellation of sum of X1 and X2
vec constellation_sum(const vec X1, const vec X2)
{
	int i, j;
	int k1, k2;

	k1 = X1.size();
	k2 = X2.size();

	vec result(k1*k2);

	for(i=0; i<k1; i++)
	{
		for(j=0; j<k2; j++)
		{
			result(i*k2+j) = X1(i) + X2(j);

		}
	}

	sort(result);

	return result;
}



// make a Gaussian pdf
double gaussian(double x, int index)
{
	double sigma = 1.0;
	double sigma2 = 1.0;

	double result;
	
	if ((x < mu(index) - multiple*sigma) || (x < mu(index) - multiple*sigma))
	{
		result = 0.0;
	}
	else
	{
		result = 1.0 / sqrt(2*pi*sigma2) * exp(-1.0*sqr(x-mu(index))/(2.0*sigma2));
	}

	return result;
}

// make a Gaussian mixture and output its entropy function (actually the version before the integration of entropy function)
double etrpy(const double x)
{

	int i;
	double result = 0.0;

	for(i=0; i<mu_num; i++)
	{
		result += 1.0 / (double)(mu_num) * gaussian(x,i);
	}

	if (result != 0)
	{
		result = -1.0 * result * log2(result);	
	}

	return result;
}


void calc_interval()
{

	int k;

	double sigma = 1.0;
	double sigma2 = 1.0;

	// make the integral intervals
	interval_min = zeros(1); interval_min(0) = mu(0) - multiple*sigma;
	interval_max = zeros(1); interval_max(0) = mu(0) + multiple*sigma;
	for (k=1; k<mu_num; k++)
	{
		if (mu(k-1)+multiple*sigma >= mu(k)-multiple*sigma)
		{
			interval_max(interval_max.size()-1) = mu(k) + multiple*sigma;
		}
		else
		{
			interval_min.ins(interval_min.size(), mu(k) - multiple*sigma);
			interval_max.ins(interval_max.size(), mu(k) + multiple*sigma);
		}
	}

}



void set_type_dec_sym_4PAM_4PAM(const ivec &map1, const ivec &map2, const double P1, const double P2, const double g11, const double g12, const double g21, const double g22, int *type_dec1, int *type_dec2, double *R_max, double *R_SND, double *R_SD, double *R_IAN_a, double *R_IAN_b)
{


	int i,j,k;

	double R_SND_1, R_SND_2, R_SND_3, R_SND_4;
	double R_SD_1, R_SD_2, R_SD_3;

	vec R_SWSC1(6), R_SWSC2(6);

	double I_X1_Y1, I_X2_Y1, I_X1_Y2, I_X2_Y2;
	double I_X1_Y1_IAN, I_X2_Y2_IAN;
	double I_X1_Y1_X2, I_X2_Y2_X1, I_X2_Y1_X1, I_X1_Y2_X2;
	double I_X1X2_Y1, I_X1X2_Y2;
	double I_U1_Y1, I_U2_Y1, I_U1_Y2, I_U2_Y2;
	double I_U1_Y1_U2, I_U2_Y1_U1, I_U1_Y2_U2, I_U2_Y2_U1;
	double I_V1_Y1_U1U2, I_V2_Y1_U1U2, I_V1_Y2_U1U2, I_V2_Y2_U1U2;
	double I_V1_Y1_U1X2, I_V2_Y1_X1U2, I_V1_Y2_U1X2, I_V2_Y2_X1U2;

	double H_Y1, H_Y2;
	double H_Y1_X1, H_Y1_X2, H_Y2_X1, H_Y2_X2;
	double H_Y1_X1_IAN, H_Y2_X2_IAN;
	double H_Y1_X1X2, H_Y2_X1X2;
	double H_Y1_U1, H_Y1_U2, H_Y2_U1, H_Y2_U2;
	double H_Y1_U1U2, H_Y2_U1U2;
	double H_Y1_X1U2, H_Y1_U1X2, H_Y2_X1U2, H_Y2_U1X2;

	ivec index1_0(2);
	ivec index1_1(2);
	ivec index2_0(2);
	ivec index2_1(2);

	int cnt0, cnt1;



	// according to mapping, store the location of '0' and '1' for X1
	cnt0=0; cnt1=0;
	for (i=0; i<4; i++)
	{
		if (i/2==0)
		{
			index1_0(cnt0) = map1(i);
			cnt0++;
		}
		else
		{
			index1_1(cnt1) = map1(i);
			cnt1++;
		}
	}
	sort(index1_0);
	sort(index1_1);

	// according to mapping, store the location of '0' and '1' for X2
	cnt0=0; cnt1=0;
	for (i=0; i<4; i++)
	{
		if (i/2==0)
		{
			index2_0(cnt0) = map2(i);
			cnt0++;
		}
		else
		{
			index2_1(cnt1) = map2(i);
			cnt1++;
		}
	}
	sort(index2_0);
	sort(index2_1);


	// H_Y1
	mu = constellation_sum(PAM_signal(4,sqr(g11)*P1),PAM_signal(4,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2
	mu = constellation_sum(PAM_signal(4,sqr(g21)*P1),PAM_signal(4,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1
	mu = PAM_signal(4,sqr(g12)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_X2
	mu = PAM_signal(4,sqr(g11)*P1);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X1
	mu = PAM_signal(4,sqr(g22)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X2
	mu = PAM_signal(4,sqr(g21)*P1);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1 when treating interference as Gaussian noise
	H_Y1_X1_IAN = 0.5*log2(2.0*pi*exp(1)*(sigma2+sqr(g12)*P2));

	// H_Y2_X2 when treating interference as Gaussian noise
	H_Y2_X2_IAN = 0.5*log2(2.0*pi*exp(1)*(sigma2+sqr(g21)*P1));

	// H_Y1_X1X2
	H_Y1_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);

	// H_Y2_X1X2
	H_Y2_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);



	// H_Y1_U1
	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_0),PAM_signal(4,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_1),PAM_signal(4,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_U2
	mu = constellation_sum(PAM_signal(4,sqr(g11)*P1),(PAM_signal(4,sqr(g12)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum(PAM_signal(4,sqr(g11)*P1),(PAM_signal(4,sqr(g12)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}



	// H_Y2_U1
	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_0),PAM_signal(4,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2_U1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_1),PAM_signal(4,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y2_U2
	mu = constellation_sum(PAM_signal(4,sqr(g21)*P1),(PAM_signal(4,sqr(g22)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y2_U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum(PAM_signal(4,sqr(g21)*P1),(PAM_signal(4,sqr(g22)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}



	// H_Y1_U1U2
	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_0),(PAM_signal(4,sqr(g12)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_1),(PAM_signal(4,sqr(g12)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_0),(PAM_signal(4,sqr(g12)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_1),(PAM_signal(4,sqr(g12)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_U1U2
	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_0),(PAM_signal(4,sqr(g22)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y2_U1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_1),(PAM_signal(4,sqr(g22)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_0),(PAM_signal(4,sqr(g22)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_1),(PAM_signal(4,sqr(g22)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}




	// H_Y1_X1U2
	mu = (PAM_signal(4,sqr(g12)*P2))(index2_0);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g12)*P2))(index2_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_U1X2
	mu = (PAM_signal(4,sqr(g11)*P1))(index1_0);
	mu_num = mu.size();

	calc_interval();

	H_Y1_U1X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g11)*P1))(index1_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y2_X1U2
	mu = (PAM_signal(4,sqr(g22)*P2))(index2_0);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g22)*P2))(index2_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y2_U1X2
	mu = (PAM_signal(4,sqr(g21)*P1))(index1_0);
	mu_num = mu.size();

	calc_interval();

	H_Y2_U1X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g21)*P1))(index1_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// calculation mutual informations we need
	I_X1_Y1 = H_Y1 - H_Y1_X1;
	I_X2_Y1 = H_Y1 - H_Y1_X2;
	I_X1_Y2 = H_Y2 - H_Y2_X1;
	I_X2_Y2 = H_Y2 - H_Y2_X2;

	I_X1_Y1_IAN = H_Y1 - H_Y1_X1_IAN;
	I_X2_Y2_IAN = H_Y2 - H_Y2_X2_IAN;

	I_X1_Y1_X2 = H_Y1_X2 - H_Y1_X1X2;
	I_X2_Y1_X1 = H_Y1_X1 - H_Y1_X1X2;
	I_X1_Y2_X2 = H_Y2_X2 - H_Y2_X1X2;
	I_X2_Y2_X1 = H_Y2_X1 - H_Y2_X1X2;

	I_X1X2_Y1 = H_Y1 - H_Y1_X1X2;
	I_X1X2_Y2 = H_Y2 - H_Y2_X1X2;

	I_U1_Y1 = H_Y1 - H_Y1_U1;
	I_U2_Y1 = H_Y1 - H_Y1_U2;
	I_U1_Y2 = H_Y2 - H_Y2_U1;
	I_U2_Y2 = H_Y2 - H_Y2_U2;

	I_U1_Y1_U2 = H_Y1_U2 - H_Y1_U1U2;
	I_U2_Y1_U1 = H_Y1_U1 - H_Y1_U1U2;
	I_U1_Y2_U2 = H_Y2_U2 - H_Y2_U1U2;
	I_U2_Y2_U1 = H_Y2_U1 - H_Y2_U1U2;

	I_V1_Y1_U1U2 = H_Y1_U1U2 - H_Y1_X1U2;
	I_V2_Y1_U1U2 = H_Y1_U1U2 - H_Y1_U1X2;
	I_V1_Y2_U1U2 = H_Y2_U1U2 - H_Y2_X1U2;
	I_V2_Y2_U1U2 = H_Y2_U1U2 - H_Y2_U1X2;

	I_V1_Y1_U1X2 = H_Y1_U1X2 - H_Y1_X1X2;
	I_V2_Y1_X1U2 = H_Y1_X1U2 - H_Y1_X1X2;
	I_V1_Y2_U1X2 = H_Y2_U1X2 - H_Y2_X1X2;
	I_V2_Y2_X1U2 = H_Y2_X1U2 - H_Y2_X1X2;


	// symmetric rate calculation for every scheme
	R_SND_1 = I_X1_Y1;
	R_SND_2 = min(I_X1_Y1_X2, 0.5*I_X1X2_Y1);
	R_SND_3 = I_X2_Y2;
	R_SND_4 = min(I_X2_Y2_X1, 0.5*I_X1X2_Y2);
	R_SND_1 = max(R_SND_1,R_SND_2);
	R_SND_3 = max(R_SND_3,R_SND_4);
	*R_SND = min(R_SND_1,R_SND_3);

	R_SD_1 = min(I_X1_Y1_X2, I_X1_Y2_X2);
	R_SD_2 = min(I_X2_Y1_X1, I_X2_Y2_X1);
	R_SD_3 = 0.5*min(I_X1X2_Y1,I_X1X2_Y2);
	R_SD_1 = min(R_SD_1,R_SD_2);
	*R_SD = min(R_SD_1,R_SD_3);


	R_SWSC1(0) = I_X1_Y1;
	R_SWSC1(1) = 0;
	R_SWSC1(2) = min(I_U1_Y1+I_V1_Y1_U1U2, I_U2_Y1_U1+I_V2_Y1_X1U2);
	R_SWSC1(3) = min(I_U1_Y1_U2+I_V1_Y1_U1X2, I_U2_Y1+I_V2_Y1_U1U2);
	R_SWSC1(4) = min(I_X1_Y1_X2, I_X2_Y1);
	R_SWSC1(5) = 0;

	R_SWSC2(0) = 0;
	R_SWSC2(1) = min(I_X1_Y2, I_X2_Y2_X1);
	R_SWSC2(2) = min(I_U1_Y2+I_V1_Y2_U1U2, I_U2_Y2_U1+I_V2_Y2_X1U2);
	R_SWSC2(3) = min(I_U1_Y2_U2+I_V1_Y2_U1X2, I_U2_Y2+I_V2_Y2_U1U2);
	R_SWSC2(4) = 0;
	R_SWSC2(5) = I_X2_Y2;

	if ((*type_dec1==6) && (*type_dec2==6))
	{
		*R_max = min(sel_max(R_SWSC1,type_dec1),sel_max(R_SWSC2,type_dec2));
	}
	else if ((*type_dec1!=6) && (*type_dec2==6))
	{
		*R_max = min(R_SWSC1(*type_dec1),sel_max(R_SWSC2,type_dec2));
	}
	else if ((*type_dec1==6) && (*type_dec2!=6))
	{
		*R_max = min(sel_max(R_SWSC1,type_dec1),R_SWSC2(*type_dec2));
	}
	else
	{
		*R_max = min(R_SWSC1(*type_dec1),R_SWSC2(*type_dec2));
	}

	*R_IAN_a = min(I_X1_Y1,I_X2_Y2);
	*R_IAN_b = min(I_X1_Y1_IAN,I_X2_Y2_IAN);

}


void set_type_dec_sum_4PAM_4PAM(const ivec &map1, const ivec &map2, const double P1, const double P2, const double g11, const double g12, const double g21, const double g22, int *type_dec1, int *type_dec2, double *R1_max, double *R2_max)
{


	int i,j,k;
	double sum_max;
	double temp;
//	int cnt;
//	ivec type1_tie;
//	ivec type2_tie;



	vec R1_SWSC1(6), R1_SWSC2(6);
	vec R2_SWSC1(6), R2_SWSC2(6);

	double I_X1_Y1, I_X2_Y1, I_X1_Y2, I_X2_Y2;
	double I_X1_Y1_X2, I_X2_Y2_X1;
	double I_U1_Y1, I_U2_Y1, I_U1_Y2, I_U2_Y2;
	double I_U1_Y1_U2, I_U2_Y1_U1, I_U1_Y2_U2, I_U2_Y2_U1;
	double I_V1_Y1_U1U2, I_V2_Y1_U1U2, I_V1_Y2_U1U2, I_V2_Y2_U1U2;
	double I_V1_Y1_U1X2, I_V2_Y1_X1U2, I_V1_Y2_U1X2, I_V2_Y2_X1U2;

	double H_Y1, H_Y2;
	double H_Y1_X1, H_Y1_X2, H_Y2_X1, H_Y2_X2;
	double H_Y1_X1X2, H_Y2_X1X2;
	double H_Y1_U1, H_Y1_U2, H_Y2_U1, H_Y2_U2;
	double H_Y1_U1U2, H_Y2_U1U2;
	double H_Y1_X1U2, H_Y1_U1X2, H_Y2_X1U2, H_Y2_U1X2;

	ivec index1_0(2);
	ivec index1_1(2);
	ivec index2_0(2);
	ivec index2_1(2);

	int cnt0, cnt1;



	// according to mapping, store the location of '0' and '1' for X1
	cnt0=0; cnt1=0;
	for (i=0; i<4; i++)
	{
		if (i/2==0)
		{
			index1_0(cnt0) = map1(i);
			cnt0++;
		}
		else
		{
			index1_1(cnt1) = map1(i);
			cnt1++;
		}
	}
	sort(index1_0);
	sort(index1_1);

	// according to mapping, store the location of '0' and '1' for X2
	cnt0=0; cnt1=0;
	for (i=0; i<4; i++)
	{
		if (i/2==0)
		{
			index2_0(cnt0) = map2(i);
			cnt0++;
		}
		else
		{
			index2_1(cnt1) = map2(i);
			cnt1++;
		}
	}
	sort(index2_0);
	sort(index2_1);


	// H_Y1
	mu = constellation_sum(PAM_signal(4,sqr(g11)*P1),PAM_signal(4,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2
	mu = constellation_sum(PAM_signal(4,sqr(g21)*P1),PAM_signal(4,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1
	mu = PAM_signal(4,sqr(g12)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_X2
	mu = PAM_signal(4,sqr(g11)*P1);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X1
	mu = PAM_signal(4,sqr(g22)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X2
	mu = PAM_signal(4,sqr(g21)*P1);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1X2
	H_Y1_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);

	// H_Y2_X1X2
	H_Y2_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);



	// H_Y1_U1
	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_0),PAM_signal(4,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_1),PAM_signal(4,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_U2
	mu = constellation_sum(PAM_signal(4,sqr(g11)*P1),(PAM_signal(4,sqr(g12)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum(PAM_signal(4,sqr(g11)*P1),(PAM_signal(4,sqr(g12)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}



	// H_Y2_U1
	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_0),PAM_signal(4,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2_U1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_1),PAM_signal(4,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y2_U2
	mu = constellation_sum(PAM_signal(4,sqr(g21)*P1),(PAM_signal(4,sqr(g22)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y2_U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum(PAM_signal(4,sqr(g21)*P1),(PAM_signal(4,sqr(g22)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}



	// H_Y1_U1U2
	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_0),(PAM_signal(4,sqr(g12)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_1),(PAM_signal(4,sqr(g12)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_0),(PAM_signal(4,sqr(g12)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g11)*P1))(index1_1),(PAM_signal(4,sqr(g12)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_U1U2
	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_0),(PAM_signal(4,sqr(g22)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	H_Y2_U1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_1),(PAM_signal(4,sqr(g22)*P2))(index2_0));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_0),(PAM_signal(4,sqr(g22)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = constellation_sum((PAM_signal(4,sqr(g21)*P1))(index1_1),(PAM_signal(4,sqr(g22)*P2))(index2_1));
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1U2 += 0.25*quad(etrpy,interval_min(k),interval_max(k));
	}




	// H_Y1_X1U2
	mu = (PAM_signal(4,sqr(g12)*P2))(index2_0);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g12)*P2))(index2_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_U1X2
	mu = (PAM_signal(4,sqr(g11)*P1))(index1_0);
	mu_num = mu.size();

	calc_interval();

	H_Y1_U1X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g11)*P1))(index1_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y2_X1U2
	mu = (PAM_signal(4,sqr(g22)*P2))(index2_0);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1U2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g22)*P2))(index2_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1U2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y2_U1X2
	mu = (PAM_signal(4,sqr(g21)*P1))(index1_0);
	mu_num = mu.size();

	calc_interval();

	H_Y2_U1X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}

	mu = (PAM_signal(4,sqr(g21)*P1))(index1_1);
	mu_num = mu.size();

	calc_interval();

	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_U1X2 += 0.5*quad(etrpy,interval_min(k),interval_max(k));
	}


	// calculation mutual informations we need
	I_X1_Y1 = H_Y1 - H_Y1_X1;
	I_X2_Y1 = H_Y1 - H_Y1_X2;
	I_X1_Y2 = H_Y2 - H_Y2_X1;
	I_X2_Y2 = H_Y2 - H_Y2_X2;

	I_X1_Y1_X2 = H_Y1_X2 - H_Y1_X1X2;
	I_X2_Y2_X1 = H_Y2_X1 - H_Y2_X1X2;

	I_U1_Y1 = H_Y1 - H_Y1_U1;
	I_U2_Y1 = H_Y1 - H_Y1_U2;
	I_U1_Y2 = H_Y2 - H_Y2_U1;
	I_U2_Y2 = H_Y2 - H_Y2_U2;

	I_U1_Y1_U2 = H_Y1_U2 - H_Y1_U1U2;
	I_U2_Y1_U1 = H_Y1_U1 - H_Y1_U1U2;
	I_U1_Y2_U2 = H_Y2_U2 - H_Y2_U1U2;
	I_U2_Y2_U1 = H_Y2_U1 - H_Y2_U1U2;

	I_V1_Y1_U1U2 = H_Y1_U1U2 - H_Y1_X1U2;
	I_V2_Y1_U1U2 = H_Y1_U1U2 - H_Y1_U1X2;
	I_V1_Y2_U1U2 = H_Y2_U1U2 - H_Y2_X1U2;
	I_V2_Y2_U1U2 = H_Y2_U1U2 - H_Y2_U1X2;

	I_V1_Y1_U1X2 = H_Y1_U1X2 - H_Y1_X1X2;
	I_V2_Y1_X1U2 = H_Y1_X1U2 - H_Y1_X1X2;
	I_V1_Y2_U1X2 = H_Y2_U1X2 - H_Y2_X1X2;
	I_V2_Y2_X1U2 = H_Y2_X1U2 - H_Y2_X1X2;


	// rate calculation for every scheme
	// for rx1
	R1_SWSC1(0) = I_X1_Y1;
	R1_SWSC1(1) = 0;
	R1_SWSC1(2) = I_U1_Y1+I_V1_Y1_U1U2;
	R1_SWSC1(3) = I_U1_Y1_U2+I_V1_Y1_U1X2;
	R1_SWSC1(4) = I_X1_Y1_X2;
	R1_SWSC1(5) = 0;

	R2_SWSC1(0) = 100000;
	R2_SWSC1(1) = 0;
	R2_SWSC1(2) = I_U2_Y1_U1+I_V2_Y1_X1U2;
	R2_SWSC1(3) = I_U2_Y1+I_V2_Y1_U1U2;
	R2_SWSC1(4) = I_X2_Y1;
	R2_SWSC1(5) = 0;

	// for rx2
	R1_SWSC2(0) = 0;
	R1_SWSC2(1) = I_X1_Y2;
	R1_SWSC2(2) = I_U1_Y2+I_V1_Y2_U1U2;
	R1_SWSC2(3) = I_U1_Y2_U2+I_V1_Y2_U1X2;
	R1_SWSC2(4) = 0;
	R1_SWSC2(5) = 100000;

	R2_SWSC2(0) = 0;
	R2_SWSC2(1) = I_X2_Y2_X1;
	R2_SWSC2(2) = I_U2_Y2_U1+I_V2_Y2_X1U2;
	R2_SWSC2(3) = I_U2_Y2+I_V2_Y2_U1U2;
	R2_SWSC2(4) = 0;
	R2_SWSC2(5) = I_X2_Y2;

	// find maximum sum-rate
	sum_max = 0;
	for (i=0; i<=5; i++)
	{
		for (j=0; j<=5; j++)
		{
			temp = min(R1_SWSC1(i),R1_SWSC2(j)) + min(R2_SWSC1(i),R2_SWSC2(j));	// max sum rate of intersection of achievable rate regions for rx1 with type i and rx2 with type j
			if (temp > sum_max)
			{
				sum_max = temp;
				*R1_max = min(R1_SWSC1(i),R1_SWSC2(j));
				*R2_max = min(R2_SWSC1(i),R2_SWSC2(j));
				*type_dec1 = i;
				*type_dec2 = j;
			}
		}
	}

}


ivec set_map(int type)
{

	ivec map;

	if (type==1)
	{
		//map = "0 0;0 1;1 0;1 1";
		map = "0 1 2 3";
	}
	else if (type==2)
	{
		//map = "0 0;0 1;1 1;1 0";
		map = "0 1 3 2";
	}
	else if (type==3)
	{
		//map = "0 0;1 0;0 1;1 1";
		map = "0 2 1 3";
	}
	else if (type==4)
	{
		//map = "0 0;1 1;0 1;1 0";
		map = "0 2 3 1";
	}
	else if (type==5)
	{
		//map = "0 0;1 0;1 1;0 1";
		map = "0 3 1 2";
	}
	else if (type==6)
	{
		//map = "0 0;1 1;1 0;0 1";
		map = "0 3 2 1";
	}

	return map;

}


bvec shuffle_stream(bvec stream1, bvec stream2, int size)
{
	int i;
	bvec new_stream(2*size);

	for (i=0; i<size; i++)
	{
		new_stream(2*i) = stream1(i);
		new_stream(2*i+1) = stream2(i);
	}

	return new_stream;
}


void set_num_null_msg_4PAM_4PAM(int type_dec1, int type_dec2, int *num_null_msg1, int *num_null_msg2)
{

	bin known1_0, known1_1, known2_0, known2_1;
	bin other1_0, other1_1, other2_0, other2_1;


	switch (type_dec1)
	{
		case 0: known1_0 = 1; known1_1 = 0; known2_0 = 0; known2_1 = 0; break;
		case 1: known1_0 = 1; known1_1 = 1; known2_0 = 1; known2_1 = 0; break;
		case 2: known1_0 = 1; known1_1 = 0; known2_0 = 1; known2_1 = 0; break;
		case 3: known1_0 = 1; known1_1 = 0; known2_0 = 1; known2_1 = 0; break;
		case 4: known1_0 = 1; known1_1 = 0; known2_0 = 1; known2_1 = 1; break;
		case 5: known1_0 = 0; known1_1 = 0; known2_0 = 1; known2_1 = 0; break;
	}

	switch (type_dec2)
	{
		case 0: other1_0 = 1; other1_1 = 0; other2_0 = 0; other2_1 = 0; break;
		case 1: other1_0 = 1; other1_1 = 1; other2_0 = 1; other2_1 = 0; break;
		case 2: other1_0 = 1; other1_1 = 0; other2_0 = 1; other2_1 = 0; break;
		case 3: other1_0 = 1; other1_1 = 0; other2_0 = 1; other2_1 = 0; break;
		case 4: other1_0 = 1; other1_1 = 0; other2_0 = 1; other2_1 = 1; break;
		case 5: other1_0 = 0; other1_1 = 0; other2_0 = 1; other2_1 = 0; break;
	}

	known1_0 = known1_0 / other1_0;		// binary OR operation
	known1_1 = known1_1 / other1_1;
	known2_0 = known2_0 / other2_0;
	known2_1 = known2_1 / other2_1;

	if (known1_1==bin(1))
	{
		*num_null_msg1 = 2;
	}
	else
	{
		*num_null_msg1 = 1;
	}

	if (known2_1==bin(1))
	{
		*num_null_msg2 = 2;
	}
	else
	{
		*num_null_msg2 = 1;
	}

}






void calc_max_sym_rate_4PAM_2PAM(double alpha, double P1, double P2, double g11, double g12, double g21, double g22, double *R_max, double *R_SND, double *R_SD, double *R_IAN)
{

	int k;

	double R_SND_1, R_SND_2, R_SND_3, R_SND_4;
	double R_SD_1, R_SD_2, R_SD_3;
	double R_SWSC_1, R_SWSC_2;

	double I_X1_Y1, I_X2_Y1, I_X1_Y2, I_X2_Y2;
	double I_X1_Y1_X2, I_X2_Y1_X1, I_X1_Y2_X2, I_X2_Y2_X1;
	double I_X1X2_Y1, I_X1X2_Y2;
	double I_U_Y1;
	double I_V_Y1_UX2;
	double I_X2_Y1_U;

	double H_Y1, H_Y2;
	double H_Y1_X1, H_Y1_X2, H_Y2_X1, H_Y2_X2;
	double H_Y1_X1X2, H_Y2_X1X2;
	double H_Y1_U;
	double H_Y1_UX2;


	// H_Y1
	mu = constellation_sum(constellation_sum(PAM_signal(2,sqr(g11)*P1*alpha),PAM_signal(2,sqr(g11)*P1*(1.0-alpha))),PAM_signal(2,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2
	mu = constellation_sum(constellation_sum(PAM_signal(2,sqr(g21)*P1*alpha),PAM_signal(2,sqr(g21)*P1*(1.0-alpha))),PAM_signal(2,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1
	mu = PAM_signal(2,sqr(g12)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_X2
	mu = constellation_sum(PAM_signal(2,sqr(g11)*P1*alpha),PAM_signal(2,sqr(g11)*P1*(1.0-alpha)));
	mu_num = mu.size();

	calc_interval();

	H_Y1_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X1
	mu = PAM_signal(2,sqr(g22)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X2
	mu = constellation_sum(PAM_signal(2,sqr(g21)*P1*alpha),PAM_signal(2,sqr(g21)*P1*(1.0-alpha)));
	mu_num = mu.size();

	calc_interval();

	H_Y2_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1X2
	H_Y1_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);

	// H_Y2_X1X2
	H_Y2_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);


	// H_Y1_U
	mu = constellation_sum(PAM_signal(2,sqr(g11)*P1*(1.0-alpha)),PAM_signal(2,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_UX2
	mu = PAM_signal(2,sqr(g11)*P1*(1.0-alpha));
	mu_num = mu.size();

	calc_interval();

	H_Y1_UX2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_UX2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	I_X1_Y1 = H_Y1 - H_Y1_X1;
	I_X2_Y1 = H_Y1 - H_Y1_X2;
	I_X1_Y2 = H_Y2 - H_Y2_X1;
	I_X2_Y2 = H_Y2 - H_Y2_X2;

	I_X1_Y1_X2 = H_Y1_X2 - H_Y1_X1X2;
	I_X2_Y1_X1 = H_Y1_X1 - H_Y1_X1X2;
	I_X1_Y2_X2 = H_Y2_X2 - H_Y2_X1X2;
	I_X2_Y2_X1 = H_Y2_X1 - H_Y2_X1X2;

	I_X1X2_Y1 = H_Y1 - H_Y1_X1X2;
	I_X1X2_Y2 = H_Y2 - H_Y2_X1X2;

	I_U_Y1 = H_Y1 - H_Y1_U;
	I_X2_Y1_U = H_Y1_U - H_Y1_UX2;
	I_V_Y1_UX2 = H_Y1_UX2 - H_Y1_X1X2;


	R_SND_1 = I_X1_Y1;
	R_SND_2 = min(I_X1_Y1_X2, 0.5*I_X1X2_Y1);
	R_SND_3 = I_X2_Y2;
	R_SND_4 = min(I_X2_Y2_X1, 0.5*I_X1X2_Y2);
	R_SND_1 = max(R_SND_1,R_SND_2);
	R_SND_3 = max(R_SND_3,R_SND_4);
	*R_SND = min(R_SND_1,R_SND_3);

	R_SD_1 = min(I_X1_Y1_X2, I_X1_Y2_X2);
	R_SD_2 = min(I_X2_Y1_X1, I_X2_Y2_X1);
	R_SD_3 = 0.5*min(I_X1X2_Y1,I_X1X2_Y2);
	R_SD_1 = min(R_SD_1,R_SD_2);
	*R_SD = min(R_SD_1,R_SD_3);

	R_SWSC_1 = min(I_U_Y1+I_V_Y1_UX2, I_X2_Y1_U);
	R_SWSC_2 = min(I_X1_Y2, I_X2_Y2_X1);
	*R_max = min(R_SWSC_1, R_SWSC_2);

	*R_IAN = min(I_X1_Y1,I_X2_Y2);

}


void calc_max_sum_rate_4PAM_2PAM(double alpha, double P1, double P2, double g11, double g12, double g21, double g22, double *R1_max, double *R2_max, double *R_sum_SND, double *R_sum_SD, double *R_sum_IAN)
{


	int i,j,k;

	double R1_a1_SND1, R2_b1_SND1, R1_c1_SND1, R2_d1_SND1;
	double R1_a2_SND2, R2_b2_SND2, R1_c2_SND2, R2_d2_SND2;
	double R_sum_SND1, R_sum_SND2;

	double R1_a1_SD1, R2_b1_SD1, R1_c1_SD1, R2_d1_SD1;
	double R1_a2_SD2, R2_b2_SD2, R1_c2_SD2, R2_d2_SD2;
	double R_sum_SD1, R_sum_SD2;

	double I_X1_Y1, I_X2_Y1, I_X1_Y2, I_X2_Y2;
	double I_X1_Y1_X2, I_X2_Y1_X1, I_X1_Y2_X2, I_X2_Y2_X1;
	double I_X1X2_Y1, I_X1X2_Y2;
	double I_U_Y1;
	double I_V_Y1_UX2;
	double I_X2_Y1_U;

	double H_Y1, H_Y2;
	double H_Y1_X1, H_Y1_X2, H_Y2_X1, H_Y2_X2;
	double H_Y1_X1X2, H_Y2_X1X2;
	double H_Y1_U;
	double H_Y1_UX2;


	// H_Y1
	mu = constellation_sum(constellation_sum(PAM_signal(2,sqr(g11)*P1*alpha),PAM_signal(2,sqr(g11)*P1*(1.0-alpha))),PAM_signal(2,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2
	mu = constellation_sum(constellation_sum(PAM_signal(2,sqr(g21)*P1*alpha),PAM_signal(2,sqr(g21)*P1*(1.0-alpha))),PAM_signal(2,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1
	mu = PAM_signal(2,sqr(g12)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_X2
	mu = constellation_sum(PAM_signal(2,sqr(g11)*P1*alpha),PAM_signal(2,sqr(g11)*P1*(1.0-alpha)));
	mu_num = mu.size();

	calc_interval();

	H_Y1_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X1
	mu = PAM_signal(2,sqr(g22)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X2
	mu = constellation_sum(PAM_signal(2,sqr(g21)*P1*alpha),PAM_signal(2,sqr(g21)*P1*(1.0-alpha)));
	mu_num = mu.size();

	calc_interval();

	H_Y2_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1X2
	H_Y1_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);

	// H_Y2_X1X2
	H_Y2_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);


	// H_Y1_U
	mu = constellation_sum(PAM_signal(2,sqr(g11)*P1*(1.0-alpha)),PAM_signal(2,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_UX2
	mu = PAM_signal(2,sqr(g11)*P1*(1.0-alpha));
	mu_num = mu.size();

	calc_interval();

	H_Y1_UX2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_UX2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	I_X1_Y1 = H_Y1 - H_Y1_X1;
	I_X2_Y1 = H_Y1 - H_Y1_X2;
	I_X1_Y2 = H_Y2 - H_Y2_X1;
	I_X2_Y2 = H_Y2 - H_Y2_X2;

	I_X1_Y1_X2 = H_Y1_X2 - H_Y1_X1X2;
	I_X2_Y1_X1 = H_Y1_X1 - H_Y1_X1X2;
	I_X1_Y2_X2 = H_Y2_X2 - H_Y2_X1X2;
	I_X2_Y2_X1 = H_Y2_X1 - H_Y2_X1X2;

	I_X1X2_Y1 = H_Y1 - H_Y1_X1X2;
	I_X1X2_Y2 = H_Y2 - H_Y2_X1X2;

	I_U_Y1 = H_Y1 - H_Y1_U;
	I_X2_Y1_U = H_Y1_U - H_Y1_UX2;
	I_V_Y1_UX2 = H_Y1_UX2 - H_Y1_X1X2;


	// symmetric rate calculation for every scheme
	R1_a1_SND1 = I_X1_Y1;
	R2_b1_SND1 = I_X2_Y1_X1;
	R1_c1_SND1 = I_X1_Y1_X2;	
	R2_d1_SND1 = I_X2_Y1;

	R1_a2_SND2 = I_X1_Y2;
	R2_b2_SND2 = I_X2_Y2_X1;
	R1_c2_SND2 = I_X1_Y2_X2;	
	R2_d2_SND2 = I_X2_Y2;

	R_sum_SND1 = I_X1X2_Y1;
	R_sum_SND2 = I_X1X2_Y2;

	if ((R1_a1_SND1 > R1_c2_SND2) && (R2_d2_SND2 > R2_b1_SND1))
	{
		*R_sum_SND = R1_a1_SND1 + R2_d2_SND2;
	}
	else if ((R1_a2_SND2 > R1_c1_SND1) && (R2_d1_SND1 > R2_b2_SND2))
	{
		*R_sum_SND = R1_c1_SND1 + R2_b2_SND2;
	}
	else if (R_sum_SND1 > R_sum_SND2)
	{
		if (R1_c2_SND2 > R1_c1_SND1)
		{
			*R_sum_SND = R_sum_SND2;
		}
		else if (R2_d1_SND1 > R2_d2_SND2)
		{
			*R_sum_SND = R1_c1_SND1 + R2_d2_SND2;
		}
		else
		{
			*R_sum_SND = R_sum_SND1;
		}
	}
	else if (R_sum_SND2 >= R_sum_SND1)
	{
		if (R2_b1_SND1 > R2_b2_SND2)
		{
			*R_sum_SND = R_sum_SND1;
		}
		else if (R1_a2_SND2 > R1_a1_SND1)
		{
			*R_sum_SND = R1_a1_SND1 + R2_b2_SND2;
		}
		else
		{
			*R_sum_SND = R_sum_SND2;
		}
	}

	R1_a1_SD1 = I_X1_Y1;
	R2_b1_SD1 = I_X2_Y1_X1;
	R1_c1_SD1 = I_X1_Y1_X2;	
	R2_d1_SD1 = I_X2_Y1;

	R1_a2_SD2 = I_X1_Y2;
	R2_b2_SD2 = I_X2_Y2_X1;
	R1_c2_SD2 = I_X1_Y2_X2;	
	R2_d2_SD2 = I_X2_Y2;

	R_sum_SD1 = I_X1X2_Y1;
	R_sum_SD2 = I_X1X2_Y2;

	if ((R1_a1_SD1 > R1_c2_SD2) && (R2_d2_SD2 > R2_b1_SD1))
	{
		*R_sum_SD = R1_c2_SD2 + R2_b1_SD1;
	}
	else if ((R1_a2_SD2 > R1_c1_SD1) && (R2_d1_SD1 > R2_b2_SD2))
	{
		*R_sum_SD = R1_c1_SD1 + R2_b2_SD2;
	}
	else
	{
		*R_sum_SD = min(R_sum_SD1,R_sum_SD2);
	}


	*R1_max = min(I_U_Y1+I_V_Y1_UX2, I_X1_Y2);
	*R2_max = min(I_X2_Y1_U, I_X2_Y2_X1);

	*R_sum_IAN = I_X1_Y1 + I_X2_Y2;

}


void calc_max_sum_rate_4PAM_2PAM_IAN(double alpha, double P1, double P2, double g11, double g12, double g21, double g22, double *R1_max, double *R2_max, double *R_sum_SND, double *R_sum_SD, double *R1_IAN, double *R2_IAN)
{


	int i,j,k;

	double R1_a1_SND1, R2_b1_SND1, R1_c1_SND1, R2_d1_SND1;
	double R1_a2_SND2, R2_b2_SND2, R1_c2_SND2, R2_d2_SND2;
	double R_sum_SND1, R_sum_SND2;

	double R1_a1_SD1, R2_b1_SD1, R1_c1_SD1, R2_d1_SD1;
	double R1_a2_SD2, R2_b2_SD2, R1_c2_SD2, R2_d2_SD2;
	double R_sum_SD1, R_sum_SD2;

	double I_X1_Y1, I_X2_Y1, I_X1_Y2, I_X2_Y2;
	double I_X1_Y1_X2, I_X2_Y1_X1, I_X1_Y2_X2, I_X2_Y2_X1;
	double I_X1X2_Y1, I_X1X2_Y2;
	double I_U_Y1;
	double I_V_Y1_UX2;
	double I_X2_Y1_U;

	double H_Y1, H_Y2;
	double H_Y1_X1, H_Y1_X2, H_Y2_X1, H_Y2_X2;
	double H_Y1_X1X2, H_Y2_X1X2;
	double H_Y1_U;
	double H_Y1_UX2;


	// H_Y1
	mu = constellation_sum(constellation_sum(PAM_signal(2,sqr(g11)*P1*alpha),PAM_signal(2,sqr(g11)*P1*(1.0-alpha))),PAM_signal(2,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2
	mu = constellation_sum(constellation_sum(PAM_signal(2,sqr(g21)*P1*alpha),PAM_signal(2,sqr(g21)*P1*(1.0-alpha))),PAM_signal(2,sqr(g22)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1
	mu = PAM_signal(2,sqr(g12)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y1_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_X2
	mu = constellation_sum(PAM_signal(2,sqr(g11)*P1*alpha),PAM_signal(2,sqr(g11)*P1*(1.0-alpha)));
	mu_num = mu.size();

	calc_interval();

	H_Y1_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X1
	mu = PAM_signal(2,sqr(g22)*P2);
	mu_num = mu.size();

	calc_interval();

	H_Y2_X1=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X1 += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y2_X2
	mu = constellation_sum(PAM_signal(2,sqr(g21)*P1*alpha),PAM_signal(2,sqr(g21)*P1*(1.0-alpha)));
	mu_num = mu.size();

	calc_interval();

	H_Y2_X2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y2_X2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	// H_Y1_X1X2
	H_Y1_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);

	// H_Y2_X1X2
	H_Y2_X1X2 = 0.5*log2(2.0*pi*exp(1)*sigma2);


	// H_Y1_U
	mu = constellation_sum(PAM_signal(2,sqr(g11)*P1*(1.0-alpha)),PAM_signal(2,sqr(g12)*P2));
	mu_num = mu.size();

	calc_interval();

	H_Y1_U=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_U += quad(etrpy,interval_min(k),interval_max(k));
	}

	// H_Y1_UX2
	mu = PAM_signal(2,sqr(g11)*P1*(1.0-alpha));
	mu_num = mu.size();

	calc_interval();

	H_Y1_UX2=0.0;
	for (k=0; k<interval_min.size(); k++)
	{
		H_Y1_UX2 += quad(etrpy,interval_min(k),interval_max(k));
	}


	I_X1_Y1 = H_Y1 - H_Y1_X1;
	I_X2_Y1 = H_Y1 - H_Y1_X2;
	I_X1_Y2 = H_Y2 - H_Y2_X1;
	I_X2_Y2 = H_Y2 - H_Y2_X2;

	I_X1_Y1_X2 = H_Y1_X2 - H_Y1_X1X2;
	I_X2_Y1_X1 = H_Y1_X1 - H_Y1_X1X2;
	I_X1_Y2_X2 = H_Y2_X2 - H_Y2_X1X2;
	I_X2_Y2_X1 = H_Y2_X1 - H_Y2_X1X2;

	I_X1X2_Y1 = H_Y1 - H_Y1_X1X2;
	I_X1X2_Y2 = H_Y2 - H_Y2_X1X2;

	I_U_Y1 = H_Y1 - H_Y1_U;
	I_X2_Y1_U = H_Y1_U - H_Y1_UX2;
	I_V_Y1_UX2 = H_Y1_UX2 - H_Y1_X1X2;


	// symmetric rate calculation for every scheme
	R1_a1_SND1 = I_X1_Y1;
	R2_b1_SND1 = I_X2_Y1_X1;
	R1_c1_SND1 = I_X1_Y1_X2;	
	R2_d1_SND1 = I_X2_Y1;

	R1_a2_SND2 = I_X1_Y2;
	R2_b2_SND2 = I_X2_Y2_X1;
	R1_c2_SND2 = I_X1_Y2_X2;	
	R2_d2_SND2 = I_X2_Y2;

	R_sum_SND1 = I_X1X2_Y1;
	R_sum_SND2 = I_X1X2_Y2;

	if ((R1_a1_SND1 > R1_c2_SND2) && (R2_d2_SND2 > R2_b1_SND1))
	{
		*R_sum_SND = R1_a1_SND1 + R2_d2_SND2;
	}
	else if ((R1_a2_SND2 > R1_c1_SND1) && (R2_d1_SND1 > R2_b2_SND2))
	{
		*R_sum_SND = R1_c1_SND1 + R2_b2_SND2;
	}
	else if (R_sum_SND1 > R_sum_SND2)
	{
		if (R1_c2_SND2 > R1_c1_SND1)
		{
			*R_sum_SND = R_sum_SND2;
		}
		else if (R2_d1_SND1 > R2_d2_SND2)
		{
			*R_sum_SND = R1_c1_SND1 + R2_d2_SND2;
		}
		else
		{
			*R_sum_SND = R_sum_SND1;
		}
	}
	else if (R_sum_SND2 >= R_sum_SND1)
	{
		if (R2_b1_SND1 > R2_b2_SND2)
		{
			*R_sum_SND = R_sum_SND1;
		}
		else if (R1_a2_SND2 > R1_a1_SND1)
		{
			*R_sum_SND = R1_a1_SND1 + R2_b2_SND2;
		}
		else
		{
			*R_sum_SND = R_sum_SND2;
		}
	}

	R1_a1_SD1 = I_X1_Y1;
	R2_b1_SD1 = I_X2_Y1_X1;
	R1_c1_SD1 = I_X1_Y1_X2;	
	R2_d1_SD1 = I_X2_Y1;

	R1_a2_SD2 = I_X1_Y2;
	R2_b2_SD2 = I_X2_Y2_X1;
	R1_c2_SD2 = I_X1_Y2_X2;	
	R2_d2_SD2 = I_X2_Y2;

	R_sum_SD1 = I_X1X2_Y1;
	R_sum_SD2 = I_X1X2_Y2;

	if ((R1_a1_SD1 > R1_c2_SD2) && (R2_d2_SD2 > R2_b1_SD1))
	{
		*R_sum_SD = R1_c2_SD2 + R2_b1_SD1;
	}
	else if ((R1_a2_SD2 > R1_c1_SD1) && (R2_d1_SD1 > R2_b2_SD2))
	{
		*R_sum_SD = R1_c1_SD1 + R2_b2_SD2;
	}
	else
	{
		*R_sum_SD = min(R_sum_SD1,R_sum_SD2);
	}


	*R1_max = min(I_U_Y1+I_V_Y1_UX2, I_X1_Y2);
	*R2_max = min(I_X2_Y1_U, I_X2_Y2_X1);

	*R1_IAN = I_X1_Y1;
	*R2_IAN = I_X2_Y2;

}




void swsc_decoding_4PAM_2PAM_rx1_soft(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, tx1 = sqrt(alpha)*sqrt(P1)*U + sqrt(1-alpha)*sqrt(P1)*V and tx2 = sqrt(P2)*W where U, V, W are BPSK signals and z~N(0,sigma2)

	int i,j,k;
	double magU, magV, magW;		// magU means the contribution of U for the constellation. e.g. rx = magU * U + magV * V + mag2 * W

	bvec cwd1;
	bvec dec_temp;
	ivec iter_dec_temp;

	vec LLR1_in, LLR1_out, LLR2_in, LLR2_out, LLRW, LLRW_prev, LLRU_prev, LLRV_prev, LLRU, LLRV;

	// calc magnitudes
	magU = sqrt(alpha)*sqrt(P1)*g1;
	magV = sqrt(1.0-alpha)*sqrt(P1)*g1;
	magW = sqrt(P2)*g2;

	// 1. initial processing
	// for the first window, the decoder has to consider the known messages 
	// curr-> block 0

	dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
	
	// decoding for msg2(0)
	cwd1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
	cwd1 = cwd1(interleaver1);
	LLRU = swsc_4PAM_2PAM_LLR_hard(cwd1.right(n));
	LLRV = zeros(n);				// means no information on V
	LLRW = swsc_4PAM_2PAM_LLR(rx.mid(0*n,n),magW,LLRU,magU,LLRV,magV,sigma2);
	LLR2_in = LLRW(deinterleaver2);

	code2.lte_turbo_rate_matching_decode_SISO(LLR2_in, LLR2_out, dec_temp, iter_dec_temp, msg2.mid(0*k2,k2));
	dec2.set_subvector(0*k2,dec_temp);
	LLRW = LLR2_out(interleaver2);


	// 2. normal SWSC decoding
	// current-> i, prev-> i-1
	
	for (i=1; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
	{

		LLRU_prev = LLRU;
		LLRV_prev = LLRV;
		LLRW_prev = LLRW;

		// decoding to recover msg1(i)
		LLRV = zeros(n);
		LLRW = zeros(n);

		LLRV_prev = swsc_4PAM_2PAM_LLR(rx.mid((i-1)*n,n),magV,LLRU_prev,magU,LLRW_prev,magW,sigma2);
		LLRU = swsc_4PAM_2PAM_LLR(rx.mid(i*n,n),magU,LLRV,magV,LLRW,magW,sigma2);
		LLR1_in = (concat(LLRV_prev,LLRU))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_SISO(LLR1_in, LLR1_out, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
		dec1.set_subvector(i*k1,dec_temp);
		LLRU = (LLR1_out(interleaver1)).right(n);

		// decoding to recover msg2(i)
		LLRW = swsc_4PAM_2PAM_LLR(rx.mid(i*n,n),magW,LLRU,magU,LLRV,magV,sigma2);
		LLR2_in = LLRW(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_SISO(LLR2_in, LLR2_out, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
		dec2.set_subvector(i*k2,dec_temp);
		LLRW = LLR2_out(interleaver2);

	}

	//cout << msg2.mid((b-2)*k2,k2) << endl;
	//cout << dec2.mid((b-2)*k2,k2) << endl;
	//cout << LLR2_in << endl;
	//cout << LLR2_out << endl;


	// 3. final processing
	// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
	// current -> b-1, prev-> b-2, next->b

	LLRU_prev = LLRU;
	LLRV_prev = LLRV;
	LLRW_prev = LLRW;

	// decoder knows the last message blocks
	dec1.set_subvector(b*k1,msg1.right(k1));

	// encoding based on the known messages
	cwd1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));			// rate-matching encoding
	cwd1 = cwd1(interleaver1);
	LLRV = swsc_4PAM_2PAM_LLR_hard(cwd1.left(n));

	// decoding to recover msg1(b-1)
	LLRW = zeros(n);
	LLRV_prev = swsc_4PAM_2PAM_LLR(rx.mid((b-2)*n,n),magV,LLRU_prev,magU,LLRW_prev,magW,sigma2);
	LLRU = swsc_4PAM_2PAM_LLR(rx.mid((b-1)*n,n),magU,LLRV,magV,LLRW,magW,sigma2);
	LLR1_in = (concat(LLRV_prev,LLRU))(deinterleaver1);

	code1.lte_turbo_rate_matching_decode_SISO(LLR1_in, LLR1_out, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
	dec1.set_subvector((b-1)*k1,dec_temp);
	LLRU = (LLR1_out(interleaver1)).right(n);

	// decoding to recover msg2(b-1)
	LLRW = swsc_4PAM_2PAM_LLR(rx.mid((b-1)*n,n),magW,LLRU,magU,LLRV,magV,sigma2);
	LLR2_in = LLRW(deinterleaver2);

	code2.lte_turbo_rate_matching_decode_SISO(LLR2_in, LLR2_out, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
	dec2.set_subvector((b-1)*k2,dec_temp);

}



void swsc_decoding_4PAM_2PAM_rx2_soft(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, tx1 = sqrt(alpha)*sqrt(P1)*U + sqrt(1-alpha)*sqrt(P1)*V and tx2 = sqrt(P2)*W where U, V, W are BPSK signals and z~N(0,sigma2)

	int i,j,k;
	double magU, magV, magW;		// magU means the contribution of U for the constellation. e.g. rx = magU * U + magV * V + mag2 * W

	bvec cwd1;
	bvec dec_temp;
	ivec iter_dec_temp;

	vec LLR1_in, LLR1_out, LLR2_in, LLR2_out, LLRW, LLRW_prev, LLRU_prev, LLRV_prev, LLRU, LLRV;

	// calc magnitudes
	magU = sqrt(alpha)*sqrt(P1)*g1;
	magV = sqrt(1.0-alpha)*sqrt(P1)*g1;
	magW = sqrt(P2)*g2;

	// 1. initial processing
	// for the first window, the decoder has to consider the known messages 
	// curr-> block 0

	dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
	cwd1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
	cwd1 = cwd1(interleaver1);
	LLRU = swsc_4PAM_2PAM_LLR_hard(cwd1.right(n));
	LLRV = zeros(n);				// means no information on V
	LLRW = zeros(n);				// means no information on W


	// 2. normal SWSC decoding
	// current-> i, prev-> i-1
	
	for (i=1; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
	{
		LLRU_prev = LLRU;
		LLRV_prev = LLRV;
		LLRW_prev = LLRW;

		// decoding to recover msg1(i)
		LLRV = zeros(n);
		LLRW = zeros(n);

		LLRV_prev = swsc_4PAM_2PAM_LLR(rx.mid((i-1)*n,n),magV,LLRU_prev,magU,LLRW_prev,magW,sigma2);
		LLRU = swsc_4PAM_2PAM_LLR(rx.mid(i*n,n),magU,LLRV,magV,LLRW,magW,sigma2);
		LLR1_in = (concat(LLRV_prev,LLRU))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_SISO(LLR1_in, LLR1_out, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
		dec1.set_subvector(i*k1,dec_temp);
		LLRV_prev = (LLR1_out(interleaver1)).left(n);
		LLRU = (LLR1_out(interleaver1)).right(n);

		// decoding to recover msg2(i-1)
		LLRW_prev = swsc_4PAM_2PAM_LLR(rx.mid((i-1)*n,n),magW,LLRU_prev,magU,LLRV_prev,magV,sigma2);
		LLR2_in = LLRW_prev(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_SISO(LLR2_in, LLR2_out, dec_temp, iter_dec_temp, msg2.mid((i-1)*k2,k2));
		dec2.set_subvector((i-1)*k2,dec_temp);

	}


	// 3. final processing
	// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
	// current -> b-1, prev-> b-2, next->b

	LLRU_prev = LLRU;
	LLRV_prev = LLRV;
	LLRW_prev = LLRW;

	// decoder knows the last message blocks
	dec1.set_subvector(b*k1,msg1.right(k1));

	// encoding based on the known messages
	cwd1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));			// rate-matching encoding
	cwd1 = cwd1(interleaver1);
	LLRV = swsc_4PAM_2PAM_LLR_hard(cwd1.left(n));

	// decoding to recover msg1(b-1)
	LLRW = zeros(n);
	LLRV_prev = swsc_4PAM_2PAM_LLR(rx.mid((b-2)*n,n),magV,LLRU_prev,magU,LLRW_prev,magW,sigma2);
	LLRU = swsc_4PAM_2PAM_LLR(rx.mid((b-1)*n,n),magU,LLRV,magV,LLRW,magW,sigma2);
	LLR1_in = (concat(LLRV_prev,LLRU))(deinterleaver1);

	code1.lte_turbo_rate_matching_decode_SISO(LLR1_in, LLR1_out, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
	dec1.set_subvector((b-1)*k1,dec_temp);
	LLRV_prev = (LLR1_out(interleaver1)).left(n);
	LLRU = (LLR1_out(interleaver1)).right(n);

	// decoding to recover msg2(b-2)
	LLRW_prev = swsc_4PAM_2PAM_LLR(rx.mid((b-2)*n,n),magW,LLRU_prev,magU,LLRV_prev,magV,sigma2);
	LLR2_in = LLRW_prev(deinterleaver2);

	code2.lte_turbo_rate_matching_decode_SISO(LLR2_in, LLR2_out, dec_temp, iter_dec_temp, msg2.mid((b-2)*k2,k2));
	dec2.set_subvector((b-2)*k2,dec_temp);

	// decoding to recover msg2(b-1)
	LLRW = swsc_4PAM_2PAM_LLR(rx.mid((b-1)*n,n),magW,LLRU,magU,LLRV,magV,sigma2);
	LLR2_in = LLRW(deinterleaver2);

	code2.lte_turbo_rate_matching_decode_SISO(LLR2_in, LLR2_out, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
	dec2.set_subvector((b-1)*k2,dec_temp);

}





void swsc_decoding_4PAM_2PAM_rx1_hard(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,BPSK &bpsk,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, tx1 = sqrt(alpha)*sqrt(P1)*U + sqrt(1-alpha)*sqrt(P1)*V and tx2 = sqrt(P2)*W where U, V, W are BPSK signals and z~N(0,sigma2)

	int i,j,k;

	bvec dec_temp;
	ivec iter_dec_temp;
	vec rx_curr_temp, rx_prev_temp;

	// 1. initial processing
	// for the first window, the decoder has to consider the known messages 
	// curr-> block 0

	// decoding for msg2(0)
	dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
	rx_curr_temp = rx.mid(0*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1)))(interleaver1)).right(n));	// rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*{\hat U}
	code2.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_12(rx_curr_temp, alpha, P1, P2, g1, g2, sigma2))(deinterleaver2), dec_temp, iter_dec_temp, msg2.mid(0*k2,k2));	// decoding for msg2
	dec2.set_subvector(0*k2,dec_temp);

	// 2. normal SWSC decoding
	// current-> i, prev-> i-1

	for (i=1; i<b-1; i++)	
	{
		// decoding for msg1(i)
		rx_prev_temp = rx.mid((i-1)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1)))(interleaver1)).right(n)) - g2*sqrt(P2)*bpsk.modulate_bits((code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2)))(interleaver2));		// rx1_prev_temp = rx1_prev - g11*sqrt(alpha)*sqrt(P1)*{\hat U} - g12*sqrt(P2)*{\hat W}
		code1.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_11(rx_prev_temp, rx.mid(i*n,n), alpha, P1, P2, g1, g2, sigma2))(deinterleaver1), dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));	// decoding for msg1
		dec1.set_subvector(i*k1,dec_temp);
		
		// decoding for msg2(i)
		rx_curr_temp = rx.mid(i*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid(i*k1,k1)))(interleaver1)).right(n));		// rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*{\hat U}
		code2.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_12(rx_curr_temp, alpha, P1, P2, g1, g2, sigma2))(deinterleaver2), dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));	// decoding for msg2
		dec2.set_subvector(i*k2,dec_temp);
	}

	// 3. final processing
	// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
	// current -> b-1, prev-> b-2, next->b
	// decoding for msg1(b-1)
	rx_prev_temp = rx.mid((b-2)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1)))(interleaver1)).right(n)) - g2*sqrt(P2)*bpsk.modulate_bits((code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2)))(interleaver2));		// rx1_prev_temp = rx1_prev - g11*sqrt(alpha)*sqrt(P1)*{\hat U} - g12*sqrt(P2)*{\hat W}
	rx_curr_temp = rx.mid((b-1)*n,n) - g1*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(msg1.mid(b*k1,k1)))(interleaver1)).left(n));			// decoder 1 knows msg1_curr at the last block. rx1_curr_temp = rx1_curr - g11*sqrt(1-alpha)*sqrt(P1)*V
	code1.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_11_last(rx_prev_temp, rx_curr_temp, alpha, P1, P2, g1, g2, sigma2))(deinterleaver1), dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));	// decoding for msg1 following LLR calculation based on two rx values
	dec1.set_subvector((b-1)*k1,dec_temp);
	
	// decoding for msg2(b-1)
	rx_curr_temp = rx.mid((b-1)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1)))(interleaver1)).right(n)) - g1*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(msg1.mid(b*k1,k1)))(interleaver1)).left(n));	// rx1_curr_temp = rx1_curr - g11*sqrt(alpha)*sqrt(P1)*{\hat U} - g11*sqrt(1-alpha)*sqrt(P1)*{\hat V}
	rx_curr_temp *= 2.0*g2*sqrt(P2) / sigma2;	// LLR calculation
	code2.lte_turbo_rate_matching_decode_LLR(rx_curr_temp(deinterleaver2), dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));	
	dec2.set_subvector((b-1)*k2,dec_temp);


}



void swsc_decoding_4PAM_2PAM_rx2_hard(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,BPSK &bpsk,int n,int k1, int k2,int b,double alpha,double P1, double P2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, tx1 = sqrt(alpha)*sqrt(P1)*U + sqrt(1-alpha)*sqrt(P1)*V and tx2 = sqrt(P2)*W where U, V, W are BPSK signals and z~N(0,sigma2)

	int i,j,k;

	bvec dec_temp;
	ivec iter_dec_temp;
	vec rx_curr_temp, rx_prev_temp;
	vec rx_prev_temp1, rx_prev_temp2;


	// 1. initial processing
	// for the first window, the decoder has to consider the known messages 
	// curr-> block 0

	dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1

	// 2. normal SWSC decoding
	// current-> i, prev-> i-1
	
	for (i=1; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
	{
		// decoding for msg1(i)
		rx_prev_temp1 = rx.mid((i-1)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1)))(interleaver1)).right(n));		// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U}
		code1.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_21(rx_prev_temp1, rx.mid(i*n,n), alpha, P1, P2, g1, g2, sigma2))(deinterleaver1), dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));	// decoding for msg1
		dec1.set_subvector(i*k1,dec_temp);
		
		// decoding for msg2(i-1)
		rx_prev_temp2 = rx_prev_temp1 - g1*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid(i*k1,k1)))(interleaver1)).left(n));	// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U} - g21*sqrt(1-alpha)*sqrt(P1)*{\hat V}
		code2.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_22(rx_prev_temp2,P2,g2,sigma2))(deinterleaver2), dec_temp, iter_dec_temp, msg2.mid((i-1)*k2,k2));
		dec2.set_subvector((i-1)*k2,dec_temp);

	}


	// 3. final processing
	// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
	// current -> b-1, prev-> b-2, next->b

	// decoding for msg1(b-1)
	rx_prev_temp1 = rx.mid((b-2)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1)))(interleaver1)).right(n));		// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U}
	rx_curr_temp = rx.mid((b-1)*n,n) - g1*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(msg1.mid(b*k1,k1)))(interleaver1)).left(n));	// rx2_curr_temp = rx2_curr - g21*sqrt(1-alpha)*sqrt(P1)*V
	code1.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_21_last(rx_prev_temp1, rx_curr_temp, alpha, P1, P2, g1, g2, sigma2))(deinterleaver1), dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));	// decoding for msg1
	dec1.set_subvector((b-1)*k1,dec_temp);
	
	// decoding for msg2(b-2)
	rx_prev_temp2 = rx.mid((b-2)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1)))(interleaver1)).right(n)) - g1*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1)))(interleaver1)).left(n));		// rx2_prev_temp = rx2_prev - g21*sqrt(alpha)*sqrt(P1)*{\hat U} - g21*sqrt(1-alpha)*sqrt(P1)*{\hat V}
	code2.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_22(rx_prev_temp2,P2,g2,sigma2))(deinterleaver2), dec_temp, iter_dec_temp, msg2.mid((b-2)*k2,k2));		// decoding for msg2_prev
	dec2.set_subvector((b-2)*k2,dec_temp);
	
	// decoding for msg2(b-1)
	rx_curr_temp = rx.mid((b-1)*n,n) - g1*sqrt(alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1)))(interleaver1)).right(n)) - g1*sqrt(1.0-alpha)*sqrt(P1)*bpsk.modulate_bits(((code1.lte_turbo_rate_matching_encode(msg1.mid(b*k1,k1)))(interleaver1)).left(n));	// rx2_curr_temp = rx2_curr - g21*sqrt(alpha)*sqrt(P1)*{\hat U} - g21*sqrt(1-alpha)*sqrt(P1)*V
	code2.lte_turbo_rate_matching_decode_LLR((sw_calc_LLR_22(rx_curr_temp,P2,g2,sigma2))(deinterleaver2), dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));		// decoding for msg2_curr
	dec2.set_subvector((b-1)*k2,dec_temp);

}





vec swsc_4PAM_2PAM_LLR(const vec &rx,const double mag_target, const vec &LLR_other1,const double mag_other1,const vec &LLR_other2,const double mag_other2,const double sigma2)
{
	vec LLR_target;

	LLR_target = log( elem_div(elem_mult(pdf_gaussian(rx,mag_target+mag_other1+mag_other2,sigma2), exp(LLR_other1), exp(LLR_other2)) + elem_mult(pdf_gaussian(rx,mag_target+mag_other1-mag_other2,sigma2), exp(LLR_other1)) + elem_mult(pdf_gaussian(rx,mag_target-mag_other1+mag_other2,sigma2), exp(LLR_other2)) + pdf_gaussian(rx,mag_target-mag_other1-mag_other2,sigma2),
			elem_mult(pdf_gaussian(rx,-mag_target+mag_other1+mag_other2,sigma2), exp(LLR_other1), exp(LLR_other2)) + elem_mult(pdf_gaussian(rx,-mag_target+mag_other1-mag_other2,sigma2), exp(LLR_other1)) + elem_mult(pdf_gaussian(rx,-mag_target-mag_other1+mag_other2,sigma2), exp(LLR_other2)) + pdf_gaussian(rx,-mag_target-mag_other1-mag_other2,sigma2) ) );

	return LLR_target;
}



vec swsc_4PAM_2PAM_LLR_hard(const bvec &cwd)
{
	int i;
	int n = cwd.size();
	vec LLR(n);

	for (i=0; i<n; i++)
	{
		if (cwd(i) == bin(0))
		{
			LLR(i) = LLR_max;
		}
		else
		{
			LLR(i) = -LLR_max;
		}
	}

	return LLR;
}



void swsc_decoding_4PAM_4PAM_hard_block(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,vec &constellation1,vec &constellation2,ivec &map1,ivec &map2,int n,int k1, int k2,int b,int type_dec,int num_null_msg1,int num_null_msg2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, txi is a 4-PAM signal with constelationi and mapi and z~N(0,sigma2)

	int i,j,k;
	int start_normal;		// for each decoding order, the time point after the initial processing

	bvec cwd_prev1, cwd_pprev1, cwd_prev2, cwd_pprev2;
	bvec cwd_curr1, cwd_curr2;
	bvec cwd_next1, cwd_next2;
	bvec dec_temp;
	ivec iter_dec_temp;

	vec LLR, LLR_U, LLR_V;


	/////////////////////  decoding order 0 (IAN for X1) ////////////////////////////
	if (type_dec==0)
	{

		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));		// this decoder is assumed to already know the first message block of tx1

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know the first and second message blocks of tx2
			start_normal = 2;

		}
		else
		{
			start_normal = 1;
		}

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know the first and second message blocks of tx2
			dec2.set_subvector(2*k2,randb((b-2)*k2));	// IAN doesn't decode for tx2. Just do random guessing for msg2
		}
		else
		{
			dec2.set_subvector(1*k2,randb((b-1)*k2));	// IAN doesn't decode for tx2. Just do random guessing for msg2
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);

		// decoding to recover msg1(i)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_V(rx.mid((b-1)*n,n),cwd_next1.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}

	/////////////////////  decoding order 1 (up left corner point) ////////////////////////////
	if (type_dec==1)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages
		// curr-> 2, prev->1, pprev->0

		dec1.set_subvector(0,msg1.left(2*k1));		// this decoder is assumed to already know the first and second message blocks of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decding to recover msg1(2)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid(1*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(2*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(2*k1,k1));
			dec1.set_subvector(2*k1,dec_temp);

			start_normal = 3;

		}
		else
		{
			start_normal = 2;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. The window runs from 2 to b-1. i is actually equal to the index of decoded message block.
		{
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-2)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_pprev1 = cwd_pprev1(interleaver1);

			cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-2)*k2,k2));		// rate-matching encoding
			cwd_pprev2 = cwd_pprev2(interleaver2);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(i*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decoding to recover msg2(i-1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-2)*n,n),cwd_pprev2.right(n),cwd_pprev1.right(n),cwd_prev1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_UV(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((i-1)*k2,k2));
			dec2.set_subvector((i-1)*k2,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, pprev-> b-3, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-3)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_pprev1 = cwd_pprev1(interleaver1);

		cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-3)*k2,k2));		// rate-matching encoding
		cwd_pprev2 = cwd_pprev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

		// encoding based on the decoded messages
		cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1));		// rate-matching encoding
		cwd_curr1 = cwd_curr1(interleaver1);

		// decoding to recover msg2(b-2)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-3)*n,n),cwd_pprev2.right(n),cwd_pprev1.right(n),cwd_prev1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_UV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-2)*k2,k2));
		dec2.set_subvector((b-2)*k2,dec_temp);

		// encoding based on the decoded messages
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_curr1.right(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);


	}



	/////////////////////  decoding order 2 (up left mid-point) ////////////////////////////
	if (type_dec==2)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decding to recover msg2(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(1*k2,k2));
			dec2.set_subvector(1*k2,dec_temp);

			start_normal = 2;

		}
		else if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decding to recover msg1(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(1*k1,k1));
			dec1.set_subvector(1*k1,dec_temp);

			start_normal = 2;		
		}
		else
		{
			start_normal = 1;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(i*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(i*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UU(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

		// encoding based on the decoded messages
		cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1));		// rate-matching encoding
		cwd_curr1 = cwd_curr1(interleaver1);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_curr1.right(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

	}


	/////////////////////  decoding order 3 (down right mid-point) ////////////////////////////
	if (type_dec==3)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decding to recover msg2(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(1*k2,k2));
			dec2.set_subvector(1*k2,dec_temp);

			start_normal = 2;

		}
		else if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decding to recover msg1(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(1*k1,k1));
			dec1.set_subvector(1*k1,dec_temp);

			start_normal = 2;		
		}
		else
		{
			start_normal = 1;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(i*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(i*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UU(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

		// encoding based on the decoded messages
		cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-1)*k2,k2));		// rate-matching encoding
		cwd_curr2 = cwd_curr2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_curr2.right(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}




	/////////////////////  decoding order 4 (down right corner point) ////////////////////////////
	if (type_dec==4)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages
		// curr-> 2, prev->1, pprev->0

		dec2.set_subvector(0,msg2.left(2*k2));		// this decoder is assumed to already know the first and second message blocks of tx1
		dec1.set_subvector(0,msg1.left(k1));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decding to recover msg2(2)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid(1*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(2*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(2*k2,k2));
			dec2.set_subvector(2*k2,dec_temp);

			start_normal = 3;

		}
		else
		{
			start_normal = 2;
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. The window runs from 2 to b-1. i is actually equal to the index of decoded message block.
		{
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);
			
			cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-2)*k1,k1));		// rate-matching encoding
			cwd_pprev1 = cwd_pprev1(interleaver1);
			cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-2)*k2,k2));		// rate-matching encoding
			cwd_pprev2 = cwd_pprev2(interleaver2);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(i*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decoding to recover msg1(i-1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-2)*n,n),cwd_pprev1.right(n),cwd_pprev2.right(n),cwd_prev2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_UV(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((i-1)*k1,k1));
			dec1.set_subvector((i-1)*k1,dec_temp);
		}

		// 3. final processing
		// we can decode for the remaining message block msg1(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, pprev-> b-3, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);
		
		cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-3)*k1,k1));		// rate-matching encoding
		cwd_pprev1 = cwd_pprev1(interleaver1);
		cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-3)*k2,k2));		// rate-matching encoding
		cwd_pprev2 = cwd_pprev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

		// encoding based on the decoded messages
		cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-1)*k2,k2));		// rate-matching encoding
		cwd_curr2 = cwd_curr2(interleaver2);

		// decoding to recover msg1(b-2)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-3)*n,n),cwd_pprev1.right(n),cwd_pprev2.right(n),cwd_prev2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_UV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-2)*k1,k1));
		dec1.set_subvector((b-2)*k1,dec_temp);

		// encoding based on the decoded messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_curr2.right(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}


	/////////////////////  decoding order 5 (IAN for X2) ////////////////////////////
	if (type_dec==5)
	{

		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));		// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know the first and second message blocks of tx2
			start_normal = 2;

		}
		else
		{
			start_normal = 1;
		}

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know the first and second message blocks of tx1
			dec1.set_subvector(2*k1,randb((b-2)*k1));	// IAN doesn't decode for tx1. Just do random guessing for msg1
		}
		else
		{
			dec1.set_subvector(1*k1,randb((b-1)*k1));	// IAN doesn't decode for tx1. Just do random guessing for msg1
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(i)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_V(rx.mid((b-1)*n,n),cwd_next2.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

	}


}

bvec soft_to_hard(vec inLLR)
{
	int i;
	bvec outbits(inLLR.size());

	for (i=0; i<inLLR.size(); i++)
	{
		if (inLLR(i) >=0)
		{
			outbits(i) = bin(0);
		}
		else
		{
			outbits(i) = bin(1);
		}
	}

	return outbits;
}


void swsc_decoding_4PAM_4PAM_hard_bit(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,vec &constellation1,vec &constellation2,ivec &map1,ivec &map2,int n,int k1, int k2,int b,int type_dec,int num_null_msg1,int num_null_msg2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, txi is a 4-PAM signal with constelationi and mapi and z~N(0,sigma2)

	int i,j,k;
	int start_normal;		// for each decoding order, the time point after the initial processing

	bvec cwd_prev1, cwd_pprev1, cwd_prev2, cwd_pprev2;
	bvec cwd_curr1, cwd_curr2;
	bvec cwd_next1, cwd_next2;
	bvec dec_temp;
	ivec iter_dec_temp;

	vec LLR, LLR_U, LLR_V;
	vec LLR_out;


	/////////////////////  decoding order 0 (IAN for X1) ////////////////////////////
	if (type_dec==0)
	{

		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));		// this decoder is assumed to already know the first message block of tx1

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know the first and second message blocks of tx2
			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			start_normal = 2;

		}
		else
		{
			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			start_normal = 1;
		}

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know the first and second message blocks of tx2
			dec2.set_subvector(2*k2,randb((b-2)*k2));	// IAN doesn't decode for tx2. Just do random guessing for msg2
		}
		else
		{
			dec2.set_subvector(1*k2,randb((b-1)*k2));	// IAN doesn't decode for tx2. Just do random guessing for msg2
		}



		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{
			cwd_prev1 = cwd_curr1;
	
			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);

		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		cwd_prev1 = cwd_curr1;								// rate-matching encoding
		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);

		// decoding to recover msg1(i)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_V(rx.mid((b-1)*n,n),cwd_next1.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}

	/////////////////////  decoding order 1 (up left corner point) ////////////////////////////
	if (type_dec==1)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages
		// curr-> 2, prev->1, pprev->0

		dec1.set_subvector(0,msg1.left(2*k1));		// this decoder is assumed to already know the first and second message blocks of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decding to recover msg1(2)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid(1*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(2*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(2*k1,k1));
			dec1.set_subvector(2*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);

			start_normal = 3;

		}
		else
		{
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			start_normal = 2;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. The window runs from 2 to b-1. i is actually equal to the index of decoded message block.
		{
			cwd_pprev1 = cwd_prev1;
			cwd_prev1 = cwd_curr1;
			cwd_pprev2 = cwd_prev2;

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);

			// decoding to recover msg2(i-1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-2)*n,n),cwd_pprev2.right(n),cwd_pprev1.right(n),cwd_prev1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_UV(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid((i-1)*k2,k2));
			dec2.set_subvector((i-1)*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_prev2 = soft_to_hard(LLR_out);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, pprev-> b-3, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_pprev1 = cwd_prev1;
		cwd_prev1 = cwd_curr1;
		cwd_pprev2 = cwd_prev2;

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);
		LLR_out = LLR_out(interleaver1);
		cwd_curr1 = soft_to_hard(LLR_out);

		// decoding to recover msg2(b-2)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-3)*n,n),cwd_pprev2.right(n),cwd_pprev1.right(n),cwd_prev1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_UV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid((b-2)*k2,k2));
		dec2.set_subvector((b-2)*k2,dec_temp);
		LLR_out = LLR_out(interleaver2);
		cwd_prev2 = soft_to_hard(LLR_out);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_curr1.right(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);


	}



	/////////////////////  decoding order 2 (up left mid-point) ////////////////////////////
	if (type_dec==2)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decding to recover msg2(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(1*k2,k2));
			dec2.set_subvector(1*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);

			start_normal = 2;

		}
		else if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decding to recover msg1(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(1*k1,k1));
			dec1.set_subvector(1*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);

			start_normal = 2;		
		}
		else
		{
			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);
			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			start_normal = 1;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{

			cwd_prev1 = cwd_curr1;		// rate-matching encoding
			cwd_prev2 = cwd_curr2;		// rate-matching encoding

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(i*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = cwd_curr1;
		cwd_prev2 = cwd_curr2;

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UU(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);
		LLR_out = LLR_out(interleaver1);
		cwd_curr1 = soft_to_hard(LLR_out);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_curr1.right(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

	}


	/////////////////////  decoding order 3 (down right mid-point) ////////////////////////////
	if (type_dec==3)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decding to recover msg2(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(1*k2,k2));
			dec2.set_subvector(1*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);

			start_normal = 2;

		}
		else if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decding to recover msg1(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(1*k1,k1));
			dec1.set_subvector(1*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);

			start_normal = 2;		
		}
		else
		{
			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);
			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			start_normal = 1;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{

			cwd_prev1 = cwd_curr1;
			cwd_prev2 = cwd_curr2;

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(i*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_curr1 = soft_to_hard(LLR_out);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = cwd_curr1;
		cwd_prev2 = cwd_curr2;

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UU(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);
		LLR_out = LLR_out(interleaver2);
		cwd_curr2 = soft_to_hard(LLR_out);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_curr2.right(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}




	/////////////////////  decoding order 4 (down right corner point) ////////////////////////////
	if (type_dec==4)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages
		// curr-> 2, prev->1, pprev->0

		dec2.set_subvector(0,msg2.left(2*k2));		// this decoder is assumed to already know the first and second message blocks of tx1
		dec1.set_subvector(0,msg1.left(k1));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decding to recover msg2(2)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid(1*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(2*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(2*k2,k2));
			dec2.set_subvector(2*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);

			start_normal = 3;

		}
		else
		{
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			start_normal = 2;
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. The window runs from 2 to b-1. i is actually equal to the index of decoded message block.
		{
			
			cwd_pprev1 = cwd_prev1;
			cwd_pprev2 = cwd_prev2;
			cwd_prev2 = cwd_curr2;

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);

			// decoding to recover msg1(i-1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-2)*n,n),cwd_pprev1.right(n),cwd_pprev2.right(n),cwd_prev2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_UV(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid((i-1)*k1,k1));
			dec1.set_subvector((i-1)*k1,dec_temp);
			LLR_out = LLR_out(interleaver1);
			cwd_prev1 = soft_to_hard(LLR_out);
		}

		// 3. final processing
		// we can decode for the remaining message block msg1(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, pprev-> b-3, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_pprev1 = cwd_prev1;
		cwd_pprev2 = cwd_prev2;
		cwd_prev2 = cwd_curr2;

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);
		LLR_out = LLR_out(interleaver2);
		cwd_curr2 = soft_to_hard(LLR_out);

		// decoding to recover msg1(b-2)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-3)*n,n),cwd_pprev1.right(n),cwd_pprev2.right(n),cwd_prev2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_UV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg1.mid((b-2)*k1,k1));
		dec1.set_subvector((b-2)*k1,dec_temp);
		LLR_out = LLR_out(interleaver1);
		cwd_prev1 = soft_to_hard(LLR_out);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_curr2.right(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}


	/////////////////////  decoding order 5 (IAN for X2) ////////////////////////////
	if (type_dec==5)
	{

		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));		// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know the first and second message blocks of tx2
			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			start_normal = 2;

		}
		else
		{
			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			start_normal = 1;
		}

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know the first and second message blocks of tx1
			dec1.set_subvector(2*k1,randb((b-2)*k1));	// IAN doesn't decode for tx1. Just do random guessing for msg1
		}
		else
		{
			dec1.set_subvector(1*k1,randb((b-1)*k1));	// IAN doesn't decode for tx1. Just do random guessing for msg1
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{
			cwd_prev2 = cwd_curr2;

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_SISO(LLR, LLR_out, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
			LLR_out = LLR_out(interleaver2);
			cwd_curr2 = soft_to_hard(LLR_out);

		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		cwd_prev2 = cwd_curr2;
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(i)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_V(rx.mid((b-1)*n,n),cwd_next2.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

	}

}



void swsc_decoding_4PAM_4PAM_soft(vec &rx,bvec &msg1,bvec &msg2,Punctured_Turbo_Codec_rev &code1,Punctured_Turbo_Codec_rev &code2,ivec &interleaver1,ivec &deinterleaver1,ivec &interleaver2,ivec &deinterleaver2,vec &constellation1,vec &constellation2,ivec &map1,ivec &map2,int n,int k1, int k2,int b,int type_dec,int num_null_msg1,int num_null_msg2,double g1,double g2,double sigma2,bvec &dec1,bvec &dec2)
{

	// rx = g1*tx1 + g2*tx2 + z
	// here, txi is a 4-PAM signal with constelationi and mapi and z~N(0,sigma2)

	int i,j,k;
	int start_normal;		// for each decoding order, the time point after the initial processing

	bvec cwd_prev1, cwd_pprev1, cwd_prev2, cwd_pprev2;
	bvec cwd_curr1, cwd_curr2;
	bvec cwd_next1, cwd_next2;
	bvec dec_temp;
	ivec iter_dec_temp;

	vec LLR, LLR_U, LLR_V;


	/////////////////////  decoding order 0 (IAN for X1) ////////////////////////////
	if (type_dec==0)
	{

		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));		// this decoder is assumed to already know the first message block of tx1

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know the first and second message blocks of tx2
			start_normal = 2;

		}
		else
		{
			start_normal = 1;
		}

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know the first and second message blocks of tx2
			dec2.set_subvector(2*k2,randb((b-2)*k2));	// IAN doesn't decode for tx2. Just do random guessing for msg2
		}
		else
		{
			dec2.set_subvector(1*k2,randb((b-1)*k2));	// IAN doesn't decode for tx2. Just do random guessing for msg2
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);

		// decoding to recover msg1(i)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_V(rx.mid((b-1)*n,n),cwd_next1.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}

	/////////////////////  decoding order 1 (up left corner point) ////////////////////////////
	if (type_dec==1)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages
		// curr-> 2, prev->1, pprev->0

		dec1.set_subvector(0,msg1.left(2*k1));		// this decoder is assumed to already know the first and second message blocks of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decding to recover msg1(2)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid(1*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(2*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(2*k1,k1));
			dec1.set_subvector(2*k1,dec_temp);

			start_normal = 3;

		}
		else
		{
			start_normal = 2;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. The window runs from 2 to b-1. i is actually equal to the index of decoded message block.
		{
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-2)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_pprev1 = cwd_pprev1(interleaver1);

			cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-2)*k2,k2));		// rate-matching encoding
			cwd_pprev2 = cwd_pprev2(interleaver2);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(i*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decoding to recover msg2(i-1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-2)*n,n),cwd_pprev2.right(n),cwd_pprev1.right(n),cwd_prev1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_UV(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((i-1)*k2,k2));
			dec2.set_subvector((i-1)*k2,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, pprev-> b-3, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-3)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_pprev1 = cwd_pprev1(interleaver1);

		cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-3)*k2,k2));		// rate-matching encoding
		cwd_pprev2 = cwd_pprev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev1.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

		// encoding based on the decoded messages
		cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1));		// rate-matching encoding
		cwd_curr1 = cwd_curr1(interleaver1);

		// decoding to recover msg2(b-2)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-3)*n,n),cwd_pprev2.right(n),cwd_pprev1.right(n),cwd_prev1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_UV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-2)*k2,k2));
		dec2.set_subvector((b-2)*k2,dec_temp);

		// encoding based on the decoded messages
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_curr1.right(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);


	}



	/////////////////////  decoding order 2 (up left mid-point) ////////////////////////////
	if (type_dec==2)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decding to recover msg2(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(1*k2,k2));
			dec2.set_subvector(1*k2,dec_temp);

			start_normal = 2;

		}
		else if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decding to recover msg1(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(1*k1,k1));
			dec1.set_subvector(1*k1,dec_temp);

			start_normal = 2;		
		}
		else
		{
			start_normal = 1;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(i*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(i*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UU(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

		// encoding based on the decoded messages
		cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-1)*k1,k1));		// rate-matching encoding
		cwd_curr1 = cwd_curr1(interleaver1);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_curr1.right(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

	}


	/////////////////////  decoding order 3 (down right mid-point) ////////////////////////////
	if (type_dec==3)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_curr1 = cwd_curr1(interleaver1);

			// decding to recover msg2(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev2.right(n),cwd_prev1.right(n),cwd_curr1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(1*k2,k2));
			dec2.set_subvector(1*k2,dec_temp);

			start_normal = 2;

		}
		else if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know even the second message block of tx2

			// encoding for the current decodings
			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(0*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(0*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decding to recover msg1(1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid(0*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(1*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(1*k1,k1));
			dec1.set_subvector(1*k1,dec_temp);

			start_normal = 2;		
		}
		else
		{
			start_normal = 1;
		}

		
		// 2. normal SWSC decoding
		// current-> i, prev-> i-1
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-1)*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(i*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decoding to recover msg1(i)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-1)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_U(rx.mid(i*n,n),cwd_curr2.right(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid(i*k1,k1));
			dec1.set_subvector(i*k1,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_UU(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

		// encoding based on the decoded messages
		cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-1)*k2,k2));		// rate-matching encoding
		cwd_curr2 = cwd_curr2(interleaver2);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_curr2.right(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}




	/////////////////////  decoding order 4 (down right corner point) ////////////////////////////
	if (type_dec==4)
	{
		
		// 1. initial processing
		// for the first window, the decoder has to consider the known messages
		// curr-> 2, prev->1, pprev->0

		dec2.set_subvector(0,msg2.left(2*k2));		// this decoder is assumed to already know the first and second message blocks of tx1
		dec1.set_subvector(0,msg1.left(k1));	// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know even the second message block of tx1

			cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid(1*k1,k1));		// rate-matching encoding
			cwd_prev1 = cwd_prev1(interleaver1);
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid(1*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decding to recover msg2(2)
			LLR_V = swsc_calc_LLR_V_UU(rx.mid(1*n,n),cwd_prev2.right(n),cwd_prev1.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(2*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(2*k2,k2));
			dec2.set_subvector(2*k2,dec_temp);

			start_normal = 3;

		}
		else
		{
			start_normal = 2;
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. The window runs from 2 to b-1. i is actually equal to the index of decoded message block.
		{
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);
			
			cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((i-2)*k1,k1));		// rate-matching encoding
			cwd_pprev1 = cwd_pprev1(interleaver1);
			cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-2)*k2,k2));		// rate-matching encoding
			cwd_pprev2 = cwd_pprev2(interleaver2);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);

			cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid(i*k2,k2));		// rate-matching encoding
			cwd_curr2 = cwd_curr2(interleaver2);

			// decoding to recover msg1(i-1)
			LLR_V = swsc_calc_LLR_V_UUV(rx.mid((i-2)*n,n),cwd_pprev1.right(n),cwd_pprev2.right(n),cwd_prev2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR_U = swsc_calc_LLR_U_UV(rx.mid((i-1)*n,n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

			code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((i-1)*k1,k1));
			dec1.set_subvector((i-1)*k1,dec_temp);
		}

		// 3. final processing
		// we can decode for the remaining message block msg1(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, pprev-> b-3, next->b

		// decoder knows the last message blocks
		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		// encoding based on the known or estimated messages
		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);
		
		cwd_pprev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-3)*k1,k1));		// rate-matching encoding
		cwd_pprev1 = cwd_pprev1(interleaver1);
		cwd_pprev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-3)*k2,k2));		// rate-matching encoding
		cwd_pprev2 = cwd_pprev2(interleaver2);

		cwd_next1 = code1.lte_turbo_rate_matching_encode(dec1.mid(b*k1,k1));		// rate-matching encoding
		cwd_next1 = cwd_next1(interleaver1);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(b-1)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_VV(rx.mid((b-1)*n,n),cwd_next2.left(n),cwd_next1.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

		// encoding based on the decoded messages
		cwd_curr2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-1)*k2,k2));		// rate-matching encoding
		cwd_curr2 = cwd_curr2(interleaver2);

		// decoding to recover msg1(b-2)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-3)*n,n),cwd_pprev1.right(n),cwd_pprev2.right(n),cwd_prev2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_UV(rx.mid((b-2)*n,n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-2)*k1,k1));
		dec1.set_subvector((b-2)*k1,dec_temp);

		// encoding based on the decoded messages
		cwd_prev1 = code1.lte_turbo_rate_matching_encode(dec1.mid((b-2)*k1,k1));		// rate-matching encoding
		cwd_prev1 = cwd_prev1(interleaver1);

		// decoding to recover msg1(b-1)
		LLR_V = swsc_calc_LLR_V_UUV(rx.mid((b-2)*n,n),cwd_prev1.right(n),cwd_prev2.right(n),cwd_curr2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR_U = swsc_calc_LLR_U_VUV(rx.mid((b-1)*n,n),cwd_next1.left(n),cwd_curr2.right(n),cwd_next2.left(n),g1,g2,sigma2,constellation1,map1,constellation2,map2);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver1);

		code1.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg1.mid((b-1)*k1,k1));
		dec1.set_subvector((b-1)*k1,dec_temp);

	}


	/////////////////////  decoding order 5 (IAN for X2) ////////////////////////////
	if (type_dec==5)
	{

		// 1. initial processing
		// for the first window, the decoder has to consider the known messages 
		// curr-> 1, prev->0

		dec1.set_subvector(0,msg1.left(k1));		// this decoder is assumed to already know the first message block of tx1
		dec2.set_subvector(0,msg2.left(k2));		// this decoder is assumed to already know the first message block of tx2

		if (num_null_msg2==2)
		{
			dec2.set_subvector(1*k2,msg2.mid(1*k2,k2));	// this decoder is assumed to already know the first and second message blocks of tx2
			start_normal = 2;

		}
		else
		{
			start_normal = 1;
		}

		if (num_null_msg1==2)
		{
			dec1.set_subvector(1*k1,msg1.mid(1*k1,k1));	// this decoder is assumed to already know the first and second message blocks of tx1
			dec1.set_subvector(2*k1,randb((b-2)*k1));	// IAN doesn't decode for tx1. Just do random guessing for msg1
		}
		else
		{
			dec1.set_subvector(1*k1,randb((b-1)*k1));	// IAN doesn't decode for tx1. Just do random guessing for msg1
		}

		// 2. normal SWSC decoding
		// current-> i, prev-> i-1, pprev-> i-2
		for (i=start_normal; i<b-1; i++)			// i represents the index of the last block in the window. i is actually equal to the index of decoded message block.
		{
			cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((i-1)*k2,k2));		// rate-matching encoding
			cwd_prev2 = cwd_prev2(interleaver2);

			// decoding to recover msg2(i)
			LLR_V = swsc_calc_LLR_V_U(rx.mid((i-1)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR_U = swsc_calc_LLR_U(rx.mid(i*n,n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
			LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

			code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid(i*k2,k2));
			dec2.set_subvector(i*k2,dec_temp);
		}


		// 3. final processing
		// we can decode for the remaining message block msg2(b-1). Assume that we already know msg1(b) and msg2(b).
		// current -> b-1, prev-> b-2, next->b

		dec1.set_subvector(b*k1,msg1.right(k1));
		dec2.set_subvector(b*k2,msg2.right(k2));

		cwd_prev2 = code2.lte_turbo_rate_matching_encode(dec2.mid((b-2)*k2,k2));		// rate-matching encoding
		cwd_prev2 = cwd_prev2(interleaver2);
		cwd_next2 = code2.lte_turbo_rate_matching_encode(dec2.mid(b*k2,k2));		// rate-matching encoding
		cwd_next2 = cwd_next2(interleaver2);

		// decoding to recover msg2(i)
		LLR_V = swsc_calc_LLR_V_U(rx.mid((b-2)*n,n),cwd_prev2.right(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR_U = swsc_calc_LLR_U_V(rx.mid((b-1)*n,n),cwd_next2.left(n),g2,g1,sigma2,constellation2,map2,constellation1,map1);
		LLR = (concat(LLR_V,LLR_U))(deinterleaver2);

		code2.lte_turbo_rate_matching_decode_LLR(LLR, dec_temp, iter_dec_temp, msg2.mid((b-1)*k2,k2));
		dec2.set_subvector((b-1)*k2,dec_temp);

	}


}


vec swsc_calc_LLR_U(vec rx, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		for (i=0; i<map.size()/2; i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}

		// calc pr1
		for (i=map.size()/2; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}


vec swsc_calc_LLR_U_U(vec rx, bvec cwd_U_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		for (i=0; i<map.size()/2; i++)
		{
			if (cwd_U_other(k)==bin(0))
			{
				for (j=0; j<map_other.size()/2; j++)
				{
					pr0 += metric(i,j);
				}
			}
			else
			{
				for (j=map_other.size()/2; j<map_other.size(); j++)
				{
					pr0 += metric(i,j);
				}
			}
		}

		// calc pr1
		for (i=map.size()/2; i<map.size(); i++)
		{
			if (cwd_U_other(k)==bin(0))
			{
				for (j=0; j<map_other.size()/2; j++)
				{
					pr1 += metric(i,j);
				}
			}
			else
			{
				for (j=map_other.size()/2; j<map_other.size(); j++)
				{
					pr1 += metric(i,j);
				}
			}
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}

vec swsc_calc_LLR_U_V(vec rx, bvec cwd_V, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		if (cwd_V(k)==bin(0))
		{
			i=0;	// binary 00
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}
		else
		{
			i=1;	// binary 01
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}

		// calc pr1
		if (cwd_V(k)==bin(0))
		{
			i=2;		// binary 10
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}
		else
		{
			i=3;		// binary 11
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}




vec swsc_calc_LLR_U_UV(vec rx, bvec cwd_U_other, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		for (i=0; i<map.size()/2; i++)
		{
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}	

			pr0 += metric(i,j);
		}

		// calc pr1
		for (i=map.size()/2; i<map.size(); i++)
		{
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}

				pr1 += metric(i,j);
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}




vec swsc_calc_LLR_U_VV(vec rx, bvec cwd_V, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		if (cwd_V(k)==bin(0))
		{
			i=0;	// binary 00
			if (cwd_V_other(k)==bin(0))
			{
				for (j=0; j<map_other.size(); j+=2)
				{
					pr0 += metric(i,j);
				}
			}
			else
			{
				for (j=1; j<map_other.size(); j+=2)
				{
					pr0 += metric(i,j);
				}
			}
		}
		else
		{
			i=1;	// binary 01
			if (cwd_V_other(k)==bin(0))
			{
				for (j=0; j<map_other.size(); j+=2)
				{
					pr0 += metric(i,j);
				}
			}
			else
			{
				for (j=1; j<map_other.size(); j+=2)
				{
					pr0 += metric(i,j);
				}
			}
		}

		// calc pr1
		if (cwd_V(k)==bin(0))
		{
			i=2;		// binary 10
			if (cwd_V_other(k)==bin(0))
			{
				for (j=0; j<map_other.size(); j+=2)
				{
					pr1 += metric(i,j);
				}
			}
			else
			{
				for (j=1; j<map_other.size(); j+=2)
				{
					pr1 += metric(i,j);
				}
			}
		}
		else
		{
			i=3;		// binary 11
			if (cwd_V_other(k)==bin(0))
			{
				for (j=0; j<map_other.size(); j+=2)
				{
					pr1 += metric(i,j);
				}
			}
			else
			{
				for (j=1; j<map_other.size(); j+=2)
				{
					pr1 += metric(i,j);
				}
			}
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}




vec swsc_calc_LLR_U_VUV(vec rx, bvec cwd_V, bvec cwd_U_other, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{

	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		if (cwd_V(k)==bin(0))
		{
			i=0;		// binary 00
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}	

			pr0 += metric(i,j);
		}
		else
		{
			i=1;		// binary 01
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}	

			pr0 += metric(i,j);
		}

		// calc pr1
		if (cwd_V(k)==bin(0))
		{
			i=2;		// binary 10
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}

			pr1 += metric(i,j);
		}
		else
		{
			i=3;		// binary 11
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}

			pr1 += metric(i,j);
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;

}




vec swsc_calc_LLR_V_U(vec rx, bvec cwd_U, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		if (cwd_U(k)==bin(0))
		{
			i=0;	// binary 00
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}
		else
		{
			i=2;	// binary 10
			for (j=0; j<map_other.size(); j++)
			{
				pr0 += metric(i,j);
			}
		}

		// calc pr1
		if (cwd_U(k)==bin(0))
		{
			i=1;		// binary 01
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}
		else
		{
			i=3;		// binary 11
			for (j=0; j<map_other.size(); j++)
			{
				pr1 += metric(i,j);
			}
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}



vec swsc_calc_LLR_V_UU(vec rx, bvec cwd_U, bvec cwd_U_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{
	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		if (cwd_U(k)==bin(0))
		{
			i=0;	// binary 00
			if (cwd_U_other(k)==bin(0))
			{
				for (j=0; j<map_other.size()/2; j++)
				{
					pr0 += metric(i,j);
				}
			}
			else
			{
				for (j=map_other.size()/2; j<map_other.size(); j++)
				{
					pr0 += metric(i,j);
				}
			}
		}
		else
		{
			i=2;	// binary 10
			if (cwd_U_other(k)==bin(0))
			{
				for (j=0; j<map_other.size()/2; j++)
				{
					pr0 += metric(i,j);
				}
			}
			else
			{
				for (j=map_other.size()/2; j<map_other.size(); j++)
				{
					pr0 += metric(i,j);
				}
			}
		}

		// calc pr1
		if (cwd_U(k)==bin(0))
		{
			i=1;		// binary 01
			if (cwd_U_other(k)==bin(0))
			{
				for (j=0; j<map_other.size()/2; j++)
				{
					pr1 += metric(i,j);
				}
			}
			else
			{
				for (j=map_other.size()/2; j<map_other.size(); j++)
				{
					pr1 += metric(i,j);
				}
			}
		}
		else
		{
			i=3;		// binary 11
			if (cwd_U_other(k)==bin(0))
			{
				for (j=0; j<map_other.size()/2; j++)
				{
					pr1 += metric(i,j);
				}
			}
			else
			{
				for (j=map_other.size()/2; j<map_other.size(); j++)
				{
					pr1 += metric(i,j);
				}
			}
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;
}


vec swsc_calc_LLR_V_UUV(vec rx, bvec cwd_U, bvec cwd_U_other, bvec cwd_V_other, double g, double g_other, double sigma2, vec &constellation, ivec &map, vec &constellation_other, ivec &map_other)
{

	int i,j,k;
	double pr0, pr1;
	vec LLR(rx.size());
	mat metric(map.size(),map_other.size());

	// for each received bit, calculate LLR
	for (k=0; k<rx.size(); k++)
	{
		pr0=0; pr1=0;
		// calculate the Gaussian pdf value in every case
		for (i=0; i<map.size(); i++)
		{
			for (j=0; j<map_other.size(); j++)
			{
				metric(i,j) = exp(-1.0*sqr(rx(k) - g*constellation(map(i)) - g_other*constellation_other(map_other(j)))/(2.0*sigma2));
			}
		}

		// calc pr0
		if (cwd_U(k)==bin(0))
		{
			i=0;		// binary 00
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}	

			pr0 += metric(i,j);
		}
		else
		{
			i=2;		// binary 10
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}	

			pr0 += metric(i,j);
		}

		// calc pr1
		if (cwd_U(k)==bin(0))
		{
			i=1;		// binary 01
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}

			pr1 += metric(i,j);
		}
		else
		{
			i=3;		// binary 11
			if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(0)))
			{
				j=0;
			}
			else if ((cwd_U_other(k)==bin(0))&&(cwd_V_other(k)==bin(1)))
			{
				j=1;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(0)))
			{
				j=2;
			}
			else if ((cwd_U_other(k)==bin(1))&&(cwd_V_other(k)==bin(1)))
			{
				j=3;
			}

			pr1 += metric(i,j);
		}

		LLR(k) = log(pr0/pr1);
	}

	return LLR;

}

